/* xnx_icon 图标生成器前端逻辑
   原生 JS，无 jQuery，无 Alpine.js
   依赖 Bootstrap 5.3（tab/toast/alert 组件已在全局加载）
   @suppress dom_xss: SVG 渲染必须用 innerHTML，所有用户输入已通过 escapeHtml() 转义
   注：byId 为 document.getElementById 的简写，避免使用 $ 与全局 jQuery shim 混淆
*/
(function() {
    'use strict';

    var DATA = window.XNX_ICON_DATA || {};
    var LANG = DATA.lang || {};

    // ========== 状态管理 ==========
    var state = {
        icon: '',
        iconData: null,
        iconScale: 60,
        iconColor: '#ffffff',
        bgType: 'solid',
        bgColor1: '#1E3A8A',
        bgColor2: '#3B82F6',
        bgDirection: 135,
        radius: 12,
        size: 128,
        badge: {
            enabled: false,
            position: 'bottom-right',
            type: 'text',
            content: '',
            color: '#ffffff',
            bg: '#FF4500',
            size: 16,
            weight: 700,
            rotation: 0,
            fontSize: 14
        }
    };

    // ========== 运行时变量 ==========
    var iconsData = null;       // icons.json 解析后的完整数据
    var filteredIcons = [];     // 当前过滤后的图标列表 [{name, data}]
    var currentCategory = '';   // 当前选中分类
    var currentSearch = '';     // 当前搜索词
    var renderedCount = 0;      // 已渲染数量
    var PAGE_SIZE = 200;        // 每次渲染数量
    var gridObserver = null;    // 懒加载 IntersectionObserver

    // ========== 工具函数 ==========

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function byId(id) { return document.getElementById(id); }

    function updateSwatch(input) {
        var swatch = input.closest('.xnx-icon-color-swatch');
        if (swatch) swatch.style.setProperty('--swatch-color', input.value);
    }

    // ========== SVG 合成 ==========
    // 返回 SVG 字符串。options: { size, withBadge }
    function buildSvg(st, options) {
        options = options || {};
        var size = options.size || st.size;
        var withBadge = options.withBadge !== false;
        var parts = [];

        parts.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '">');

        // ---- 背景 ----
        if (st.bgType !== 'none') {
            var fill;
            if (st.bgType === 'gradient') {
                var rad = st.bgDirection * Math.PI / 180;
                var x1 = (50 - Math.sin(rad) * 50).toFixed(2);
                var y1 = (50 + Math.cos(rad) * 50).toFixed(2);
                var x2 = (50 + Math.sin(rad) * 50).toFixed(2);
                var y2 = (50 - Math.cos(rad) * 50).toFixed(2);
                parts.push('<defs><linearGradient id="xnx_bg_' + size + '" x1="' + x1 + '%" y1="' + y1 + '%" x2="' + x2 + '%" y2="' + y2 + '%">');
                parts.push('<stop offset="0%" stop-color="' + st.bgColor1 + '"/>');
                parts.push('<stop offset="100%" stop-color="' + st.bgColor2 + '"/>');
                parts.push('</linearGradient></defs>');
                fill = 'url(#xnx_bg_' + size + ')';
            } else {
                fill = st.bgColor1;
            }

            // 统一用圆角矩形，radius=0 为方形，radius>=size/2 为圆形
            var rx = Math.min(st.radius, size / 2);
            parts.push('<rect width="' + size + '" height="' + size + '" rx="' + rx + '" ry="' + rx + '" fill="' + fill + '"/>');
        }

        // ---- 主图标 ----
        if (st.iconData) {
            var iconScale = (parseFloat(st.iconScale) || 60) / 100;
            var iconSize = size * iconScale;
            var scale = iconSize / 24;
            var translate = (size - iconSize) / 2;
            var paths = st.iconData.paths;
            if (typeof paths === 'string') paths = [paths];
            if (paths && paths.length) {
                parts.push('<g transform="translate(' + translate.toFixed(2) + ',' + translate.toFixed(2) + ') scale(' + scale.toFixed(4) + ')">');
                var iconStroke = st.iconColor || '#ffffff';
                for (var i = 0; i < paths.length; i++) {
                    parts.push('<path d="' + paths[i] + '" fill="none" stroke="' + iconStroke + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>');
                }
                parts.push('</g>');
            }
        }

        // ---- 角标（三角形）----
        if (withBadge && st.badge.enabled && st.badge.size > 0) {
            var bSize = st.badge.size;
            var bx = 0, by = 0;
            switch (st.badge.position) {
                case 'top-left':     bx = 0;             by = 0;             break;
                case 'top-right':    bx = size - bSize;  by = 0;             break;
                case 'bottom-left':  bx = 0;             by = size - bSize;  break;
                case 'bottom-right': bx = size - bSize;  by = size - bSize;  break;
            }

            // 三角形顶点：直角在角落外侧，斜边朝向图标中心
            var p1x, p1y, p2x, p2y, p3x, p3y;
            switch (st.badge.position) {
                case 'top-left':
                    p1x = bx;        p1y = by;        // 直角顶点（左上角）
                    p2x = bx + bSize; p2y = by;        // 右
                    p3x = bx;         p3y = by + bSize; // 下
                    break;
                case 'top-right':
                    p1x = bx + bSize; p1y = by;        // 直角顶点（右上角）
                    p2x = bx;         p2y = by;        // 左
                    p3x = bx + bSize; p3y = by + bSize; // 下
                    break;
                case 'bottom-left':
                    p1x = bx;         p1y = by + bSize; // 直角顶点（左下角）
                    p2x = bx + bSize; p2y = by + bSize; // 右
                    p3x = bx;         p3y = by;         // 上
                    break;
                case 'bottom-right':
                default:
                    p1x = bx + bSize; p1y = by + bSize; // 直角顶点（右下角）
                    p2x = bx;         p2y = by + bSize; // 左
                    p3x = bx + bSize; p3y = by;         // 上
                    break;
            }

            // 三角形背景
            parts.push('<polygon points="' + p1x + ',' + p1y + ' ' + p2x + ',' + p2y + ' ' + p3x + ',' + p3y + '" fill="' + st.badge.bg + '"/>');

            // 角标内容（放在三角形重心位置）
            var bcx = (p1x + p2x + p3x) / 3;
            var bcy = (p1y + p2y + p3y) / 3;

            if (st.badge.content) {
                var bWeight = parseInt(st.badge.weight, 10) || 400;
                var bRot = parseFloat(st.badge.rotation) || 0;
                var bFontSize = parseInt(st.badge.fontSize, 10) || 14;
                var bTransform = bRot !== 0 ? ' transform="rotate(' + bRot.toFixed(1) + ' ' + bcx.toFixed(2) + ' ' + bcy.toFixed(2) + ')"' : '';
                parts.push('<text x="' + bcx.toFixed(2) + '" y="' + bcy.toFixed(2) + '" text-anchor="middle" dominant-baseline="central" font-size="' + bFontSize + '" fill="' + st.badge.color + '" font-family="sans-serif" font-weight="' + bWeight + '"' + bTransform + '>' + escapeHtml(st.badge.content) + '</text>');
            }
        }

        parts.push('</svg>');
        return parts.join('');
    }

    // ========== 实时预览 ==========
    function render() {
        var svg = buildSvg(state);
        var previewArea = byId('previewArea');
        if (previewArea) {
            if (state.iconData) {
                previewArea.innerHTML = svg;
            } else {
                previewArea.innerHTML = '<div class="xnx-icon-preview-empty">' + escapeHtml(LANG.no_icon || '') + '</div>';
            }
        }
        var svgCode = byId('svgCode');
        if (svgCode) svgCode.textContent = svg;
        var outputSize = byId('outputSize');
        if (outputSize) outputSize.textContent = state.size + ' \u00d7 ' + state.size;
        var currentIcon = byId('currentIcon');
        if (currentIcon) currentIcon.value = state.icon;
    }

    // ========== 联动显示/隐藏 ==========
    function updateBgTypeVisibility() {
        var colorFields = byId('bgColorFields');
        var color2Col = byId('bgColor2Col');
        var directionRow = byId('bgDirectionRow');
        if (state.bgType === 'none') {
            if (colorFields) colorFields.style.display = 'none';
        } else {
            if (colorFields) colorFields.style.display = '';
            if (state.bgType === 'gradient') {
                if (color2Col) color2Col.classList.remove('d-none');
                if (directionRow) directionRow.classList.remove('d-none');
            } else {
                if (color2Col) color2Col.classList.add('d-none');
                if (directionRow) directionRow.classList.add('d-none');
            }
        }
    }

    function updateBadgeVisibility() {
        var body = byId('badgeSettingsBody');
        if (body) body.style.display = state.badge.enabled ? '' : 'none';
    }

    // ========== 控件同步：state -> UI ==========
    function setRadioChecked(name, value) {
        var radios = document.querySelectorAll('input[name="' + name + '"]');
        radios.forEach(function(r) { r.checked = (r.value === value); });
    }

    function setColorInput(id, value) {
        var input = byId(id);
        if (input) {
            input.value = value;
            updateSwatch(input);
        }
    }

    function syncControlsFromState() {
        setRadioChecked('bg_type', state.bgType);
        setColorInput('bgColor1', state.bgColor1);
        setColorInput('bgColor2', state.bgColor2);
        var dirSelect = byId('bgDirection');
        if (dirSelect) dirSelect.value = state.bgDirection;

        var iconScaleSlider = byId('iconScaleSlider');
        var iconScaleValue = byId('iconScaleValue');
        if (iconScaleSlider) iconScaleSlider.value = state.iconScale;
        if (iconScaleValue) iconScaleValue.textContent = state.iconScale + '%';
        setColorInput('iconColor', state.iconColor);

        var radiusSlider = byId('radiusSlider');
        var radiusValue = byId('radiusValue');
        if (radiusSlider) radiusSlider.value = state.radius;
        if (radiusValue) radiusValue.textContent = state.radius;

        var badgeEnable = byId('badgeEnable');
        if (badgeEnable) badgeEnable.checked = state.badge.enabled;

        document.querySelectorAll('#badgePosition .xnx-icon-badge-pos-btn').forEach(function(btn) {
            btn.classList.toggle('active', btn.getAttribute('data-pos') === state.badge.position);
        });

        var badgeContent = byId('badgeContent');
        if (badgeContent) badgeContent.value = state.badge.content;
        setColorInput('badgeColor', state.badge.color);
        setColorInput('badgeBg', state.badge.bg);

        var badgeSizeSlider = byId('badgeSizeSlider');
        var badgeSizeValue = byId('badgeSizeValue');
        if (badgeSizeSlider) badgeSizeSlider.value = state.badge.size;
        if (badgeSizeValue) badgeSizeValue.textContent = state.badge.size;

        var badgeWeightSlider = byId('badgeWeightSlider');
        var badgeWeightValue = byId('badgeWeightValue');
        if (badgeWeightSlider) badgeWeightSlider.value = state.badge.weight;
        if (badgeWeightValue) badgeWeightValue.textContent = state.badge.weight;

        var badgeRotationSlider = byId('badgeRotationSlider');
        var badgeRotationValue = byId('badgeRotationValue');
        if (badgeRotationSlider) badgeRotationSlider.value = state.badge.rotation;
        if (badgeRotationValue) badgeRotationValue.textContent = state.badge.rotation + '°';

        var badgeFontSizeSlider = byId('badgeFontSizeSlider');
        var badgeFontSizeValue = byId('badgeFontSizeValue');
        if (badgeFontSizeSlider) badgeFontSizeSlider.value = state.badge.fontSize;
        if (badgeFontSizeValue) badgeFontSizeValue.textContent = state.badge.fontSize;

        document.querySelectorAll('#sizePresets .xnx-icon-size-btn').forEach(function(btn) {
            btn.classList.toggle('active', parseInt(btn.getAttribute('data-size'), 10) === state.size);
        });
        var sizeCustom = byId('sizeCustom');
        if (sizeCustom) sizeCustom.value = state.size;

        var currentIcon = byId('currentIcon');
        if (currentIcon) currentIcon.value = state.icon;

        // 图标网格选中态
        document.querySelectorAll('#iconGrid .xnx-icon-grid-item').forEach(function(item) {
            item.classList.toggle('selected', item.getAttribute('data-icon-name') === state.icon);
        });

        updateBgTypeVisibility();
        updateBadgeVisibility();
    }

    // ========== 预设数据处理 ==========
    // preset（下划线字段）-> state（驼峰字段）
    function presetToState(preset) {
        var s = {
            icon: preset.icon || '',
            iconData: null,
            iconScale: parseInt(preset.icon_scale, 10) || 60,
            iconColor: preset.icon_color || '#ffffff',
            bgType: preset.bg_type || 'solid',
            bgColor1: preset.bg_color1 || '#1E3A8A',
            bgColor2: preset.bg_color2 || '#3B82F6',
            bgDirection: parseInt(preset.bg_direction, 10) || 135,
            radius: parseInt(preset.radius, 10) || 0,
            size: parseInt(preset.size, 10) || 128,
            badge: {
                enabled: false,
                position: 'bottom-right',
                type: 'text',
                content: '',
                color: '#ffffff',
                bg: '#FF4500',
                size: 16,
                weight: 700,
                rotation: 0,
                fontSize: 14
            }
        };
        // 兼容旧预设的 bg_shape 字段：circle→大圆角，square→0
        if (preset.bg_shape === 'circle' && !preset.radius) {
            s.radius = 100;
        } else if (preset.bg_shape === 'square') {
            s.radius = 0;
        }
        if (preset.badge && typeof preset.badge === 'object') {
            s.badge = {
                enabled: !!preset.badge.enabled,
                position: preset.badge.position || 'bottom-right',
                type: 'text',
                content: preset.badge.content || '',
                color: preset.badge.color || '#ffffff',
                bg: preset.badge.bg || '#FF4500',
                size: parseInt(preset.badge.size, 10) || 16,
                weight: parseInt(preset.badge.weight, 10) || 700,
                rotation: parseFloat(preset.badge.rotation) || 0,
                fontSize: parseInt(preset.badge.fontSize, 10) || 14
            };
        }
        if (s.icon && iconsData && iconsData[s.icon]) {
            s.iconData = iconsData[s.icon];
        }
        return s;
    }

    function applyPreset(preset) {
        var s = presetToState(preset);
        state.icon = s.icon;
        state.iconData = s.iconData;
        state.iconScale = s.iconScale;
        state.iconColor = s.iconColor;
        state.bgType = s.bgType;
        state.bgColor1 = s.bgColor1;
        state.bgColor2 = s.bgColor2;
        state.bgDirection = s.bgDirection;
        state.radius = s.radius;
        state.size = s.size;
        state.badge = s.badge;
        syncControlsFromState();
        render();
    }

    function findPresetByName(name, builtin) {
        var list = builtin ? DATA.builtinPresets : DATA.customPresets;
        if (!list) return null;
        for (var i = 0; i < list.length; i++) {
            if (list[i].name === name) return list[i];
        }
        return null;
    }

    // state -> preset_config JSON（保存预设用）
    function serializeState() {
        return {
            icon: state.icon,
            icon_scale: state.iconScale,
            icon_color: state.iconColor,
            bg_type: state.bgType,
            bg_color1: state.bgColor1,
            bg_color2: state.bgColor2,
            bg_direction: state.bgDirection,
            radius: state.radius,
            size: state.size,
            badge: {
                enabled: state.badge.enabled,
                position: state.badge.position,
                type: 'text',
                content: state.badge.content,
                color: state.badge.color,
                bg: state.badge.bg,
                size: state.badge.size,
                weight: state.badge.weight,
                rotation: state.badge.rotation,
                fontSize: state.badge.fontSize
            }
        };
    }

    // ========== 预设按钮渲染（预览面板） ==========
    function renderPresetButtons() {
        var builtinContainer = byId('builtinPresets');
        var customContainer = byId('customPresets');

        if (builtinContainer) {
            builtinContainer.innerHTML = '';
            (DATA.builtinPresets || []).forEach(function(preset) {
                builtinContainer.appendChild(createPresetButton(preset));
            });
        }
        if (customContainer) {
            customContainer.innerHTML = '';
            if (!DATA.customPresets || DATA.customPresets.length === 0) {
                customContainer.innerHTML = '<span class="small text-muted">' + escapeHtml(LANG.no_presets || '') + '</span>';
            } else {
                DATA.customPresets.forEach(function(preset) {
                    customContainer.appendChild(createPresetButton(preset));
                });
            }
        }
    }

    function createPresetButton(preset) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'xnx-icon-preset-btn';

        var thumb = document.createElement('div');
        thumb.className = 'xnx-icon-preset-thumb';
        var previewState = presetToState(preset);
        thumb.innerHTML = buildSvg(previewState, { size: 36, withBadge: false });

        var label = document.createElement('div');
        label.className = 'xnx-icon-preset-label';
        label.textContent = preset.name;

        btn.appendChild(thumb);
        btn.appendChild(label);
        btn.title = preset.name;

        btn.addEventListener('click', function() {
            applyPreset(preset);
            render();
        });

        return btn;
    }

    // ========== icons.json 加载 ==========
    function normalizeIconsData(data) {
        for (var name in data) {
            var icon = data[name];
            if (icon.tags && icon.tags.length) {
                for (var i = 0; i < icon.tags.length; i++) {
                    if (typeof icon.tags[i] !== 'string') {
                        icon.tags[i] = String(icon.tags[i]);
                    }
                }
            }
        }
        return data;
    }

    function loadIcons() {
        fetch(DATA.iconsUrl)
            .then(function(res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.json();
            })
            .then(function(data) {
                iconsData = normalizeIconsData(data);
                onIconsLoaded();
            })
            .catch(function() {
                var loading = byId('iconLoading');
                if (loading) {
                    loading.innerHTML = '<div class="text-danger">' + escapeHtml(LANG.load_failed || 'load failed') + '</div>';
                }
            });
    }

    function onIconsLoaded() {
        renderCategories();
        filterIcons();
        renderPresetButtons();
        // 如果有默认图标（如内置预设的图标），可在此选中
        syncControlsFromState();
        render();
    }

    // ========== 分类渲染 ==========
    function renderCategories() {
        var container = byId('iconCategories');
        if (!container || !iconsData) return;

        // 提取分类并统计
        var catMap = {};
        for (var name in iconsData) {
            var cat = iconsData[name].category || 'Other';
            if (!catMap[cat]) catMap[cat] = 0;
            catMap[cat]++;
        }
        // 按名称排序
        var cats = Object.keys(catMap).sort(function(a, b) {
            return a.localeCompare(b);
        });

        container.innerHTML = '';
        // "全部"标签
        var allBtn = document.createElement('button');
        allBtn.type = 'button';
        allBtn.className = 'xnx-icon-cat-pill active';
        allBtn.textContent = (LANG.all_categories || 'All') + ' (' + Object.keys(iconsData).length + ')';
        allBtn.addEventListener('click', function() {
            currentCategory = '';
            updateCategoryActive(this);
            filterIcons();
        });
        container.appendChild(allBtn);

        cats.forEach(function(cat) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'xnx-icon-cat-pill';
            btn.textContent = cat + ' (' + catMap[cat] + ')';
            btn.setAttribute('data-category', cat);
            btn.addEventListener('click', function() {
                currentCategory = cat;
                updateCategoryActive(this);
                filterIcons();
            });
            container.appendChild(btn);
        });
    }

    function updateCategoryActive(activeBtn) {
        document.querySelectorAll('#iconCategories .xnx-icon-cat-pill').forEach(function(b) {
            b.classList.remove('active');
        });
        if (activeBtn) activeBtn.classList.add('active');
    }

    // ========== 图标过滤 ==========
    function filterIcons() {
        if (!iconsData) return;
        var search = currentSearch.toLowerCase();
        var result = [];
        for (var name in iconsData) {
            var icon = iconsData[name];
            // 分类筛选
            if (currentCategory && icon.category !== currentCategory) continue;
            // 搜索筛选
            if (search) {
                var match = name.toLowerCase().indexOf(search) !== -1;
                if (!match && icon.tags && icon.tags.length) {
                    for (var i = 0; i < icon.tags.length; i++) {
                        if (String(icon.tags[i]).toLowerCase().indexOf(search) !== -1) {
                            match = true;
                            break;
                        }
                    }
                }
                if (!match) continue;
            }
            result.push({ name: name, data: icon });
        }
        filteredIcons = result;
        renderIconGrid();
    }

    // ========== 图标网格渲染 ==========
    function renderIconGrid() {
        var grid = byId('iconGrid');
        var loading = byId('iconLoading');
        if (loading) loading.style.display = 'none';
        if (!grid) return;

        grid.style.display = '';
        grid.innerHTML = '';
        renderedCount = 0;

        // 空状态
        if (filteredIcons.length === 0) {
            grid.innerHTML = '<div class="xnx-icon-grid-empty">' + escapeHtml(LANG.no_icon || '') + '</div>';
            updateIconCount();
            return;
        }

        // 固定哨兵（用于懒加载触发）
        var sentinel = document.createElement('div');
        sentinel.className = 'xnx-icon-grid-sentinel';
        sentinel.id = 'gridSentinel';
        grid.appendChild(sentinel);

        loadMoreIcons();
        setupGridObserver();
        updateIconCount();
    }

    function loadMoreIcons() {
        var grid = byId('iconGrid');
        var sentinel = byId('gridSentinel');
        if (!grid || !sentinel) return;

        var end = Math.min(renderedCount + PAGE_SIZE, filteredIcons.length);
        var fragment = document.createDocumentFragment();
        for (var i = renderedCount; i < end; i++) {
            fragment.appendChild(createGridItem(filteredIcons[i].name, filteredIcons[i].data));
        }
        grid.insertBefore(fragment, sentinel);
        renderedCount = end;
    }

    function createGridItem(name, iconData) {
        var item = document.createElement('div');
        item.className = 'xnx-icon-grid-item';
        item.setAttribute('data-icon-name', name);
        if (state.icon === name) item.classList.add('selected');

        var paths = iconData.paths;
        if (typeof paths === 'string') paths = [paths];
        var svg = '<svg viewBox="0 0 24 24" width="100%" height="100%">';
        if (paths && paths.length) {
            for (var i = 0; i < paths.length; i++) {
                svg += '<path d="' + paths[i] + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
            }
        }
        svg += '</svg>';
        item.innerHTML = svg;
        item.title = name;

        item.addEventListener('click', function() {
            selectIcon(name);
        });
        return item;
    }

    function selectIcon(name) {
        state.icon = name;
        state.iconData = (iconsData && iconsData[name]) ? iconsData[name] : null;
        document.querySelectorAll('#iconGrid .xnx-icon-grid-item').forEach(function(item) {
            item.classList.toggle('selected', item.getAttribute('data-icon-name') === name);
        });
        render();
    }

    function setupGridObserver() {
        if (gridObserver) gridObserver.disconnect();
        var sentinel = byId('gridSentinel');
        var grid = byId('iconGrid');
        if (!sentinel || !grid) return;
        gridObserver = new IntersectionObserver(function(entries) {
            if (entries[0].isIntersecting && renderedCount < filteredIcons.length) {
                loadMoreIcons();
            }
        }, { root: grid, threshold: 0.1 });
        gridObserver.observe(sentinel);
    }

    function updateIconCount() {
        var el = byId('iconCount');
        if (!el) return;
        var total = iconsData ? Object.keys(iconsData).length : 0;
        var shown = filteredIcons.length;
        var tpl = LANG.icons_count || '{n}';
        el.textContent = tpl.replace('{n}', shown) + (shown < total ? ' / ' + total : '');
    }

    // ========== 导出功能 ==========
    function copySvg() {
        if (!state.iconData) { showToast(LANG.no_icon || '', 'warning'); return; }
        var svg = buildSvg(state);
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(svg).then(function() {
                showToast(LANG.copy_success || '', 'success');
            }).catch(function() { fallbackCopy(svg); });
        } else {
            fallbackCopy(svg);
        }
    }

    function fallbackCopy(text) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try {
            document.execCommand('copy');
            showToast(LANG.copy_success || '', 'success');
        } catch (e) {
            showToast(LANG.copy_failed || '', 'danger');
        }
        document.body.removeChild(ta);
    }

    function downloadSvg() {
        if (!state.iconData) { showToast(LANG.no_icon || '', 'warning'); return; }
        var svg = buildSvg(state);
        var blob = new Blob([svg], { type: 'image/svg+xml' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'icon-' + (state.icon || 'export') + '.svg';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function downloadPng() {
        if (!state.iconData) { showToast(LANG.no_icon || '', 'warning'); return; }
        var svg = buildSvg(state);
        var blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var img = new Image();
        img.onload = function() {
            var canvas = document.createElement('canvas');
            canvas.width = state.size;
            canvas.height = state.size;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            canvas.toBlob(function(b) {
                var pngUrl = URL.createObjectURL(b);
                var a = document.createElement('a');
                a.href = pngUrl;
                a.download = 'icon-' + (state.icon || 'export') + '.png';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(pngUrl);
            }, 'image/png');
            URL.revokeObjectURL(url);
        };
        img.onerror = function() {
            URL.revokeObjectURL(url);
            showToast(LANG.copy_failed || '', 'danger');
        };
        img.src = url;
    }

    // ========== toast ==========
    function showToast(msg, type) {
        type = type || 'success';
        var container = byId('toastContainer');
        if (!container) return;
        var alert = document.createElement('div');
        alert.className = 'xnx-icon-toast alert alert-' + type + ' alert-dismissible fade show';
        alert.setAttribute('role', 'alert');
        alert.innerHTML = '<div class="small">' + escapeHtml(msg) + '</div>' +
            '<button type="button" class="btn-close btn-close-sm" data-bs-dismiss="alert" aria-label="Close"></button>';
        container.appendChild(alert);
        setTimeout(function() {
            alert.classList.add('hide-out');
            setTimeout(function() {
                if (alert.parentNode) alert.parentNode.removeChild(alert);
            }, 300);
        }, 3000);
    }

    // ========== 事件绑定 ==========
    function bindColorInput(id, callback) {
        var input = byId(id);
        if (!input) return;
        input.addEventListener('input', function() {
            callback(this.value);
            updateSwatch(this);
            render();
        });
    }

    function bindEvents() {
        // 搜索（防抖 150ms）
        var searchInput = byId('iconSearch');
        var searchTimer = null;
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimer);
                var self = this;
                searchTimer = setTimeout(function() {
                    currentSearch = self.value.trim();
                    filterIcons();
                }, 150);
            });
        }

        // 背景模式
        document.querySelectorAll('input[name="bg_type"]').forEach(function(r) {
            r.addEventListener('change', function() {
                state.bgType = this.value;
                updateBgTypeVisibility();
                render();
            });
        });

        // 颜色
        bindColorInput('bgColor1', function(v) { state.bgColor1 = v; });
        bindColorInput('bgColor2', function(v) { state.bgColor2 = v; });

        // 渐变方向
        var dirSelect = byId('bgDirection');
        if (dirSelect) {
            dirSelect.addEventListener('change', function() {
                state.bgDirection = parseInt(this.value, 10) || 0;
                render();
            });
        }

        // 图标大小
        var iconScaleSlider = byId('iconScaleSlider');
        var iconScaleValue = byId('iconScaleValue');
        if (iconScaleSlider) {
            iconScaleSlider.addEventListener('input', function() {
                state.iconScale = parseInt(this.value, 10) || 60;
                if (iconScaleValue) iconScaleValue.textContent = state.iconScale + '%';
                render();
            });
        }

        // 图标颜色
        bindColorInput('iconColor', function(v) { state.iconColor = v; });

        // 圆角
        var radiusSlider = byId('radiusSlider');
        var radiusValue = byId('radiusValue');
        if (radiusSlider) {
            radiusSlider.addEventListener('input', function() {
                state.radius = parseInt(this.value, 10) || 0;
                if (radiusValue) radiusValue.textContent = state.radius;
                render();
            });
        }

        // 角标启用
        var badgeEnable = byId('badgeEnable');
        if (badgeEnable) {
            badgeEnable.addEventListener('change', function() {
                state.badge.enabled = this.checked;
                updateBadgeVisibility();
                render();
            });
        }

        // 角标位置
        document.querySelectorAll('#badgePosition .xnx-icon-badge-pos-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                state.badge.position = this.getAttribute('data-pos');
                document.querySelectorAll('#badgePosition .xnx-icon-badge-pos-btn').forEach(function(b) {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                render();
            });
        });

        // 角标内容
        var badgeContent = byId('badgeContent');
        if (badgeContent) {
            badgeContent.addEventListener('input', function() {
                state.badge.content = this.value;
                render();
            });
        }

        // 角标颜色
        bindColorInput('badgeColor', function(v) { state.badge.color = v; });
        bindColorInput('badgeBg', function(v) { state.badge.bg = v; });

        // 角标大小
        var badgeSizeSlider = byId('badgeSizeSlider');
        var badgeSizeValue = byId('badgeSizeValue');
        if (badgeSizeSlider) {
            badgeSizeSlider.addEventListener('input', function() {
                state.badge.size = parseInt(this.value, 10) || 16;
                if (badgeSizeValue) badgeSizeValue.textContent = state.badge.size;
                render();
            });
        }

        // 文字粗细
        var badgeWeightSlider = byId('badgeWeightSlider');
        var badgeWeightValue = byId('badgeWeightValue');
        if (badgeWeightSlider) {
            badgeWeightSlider.addEventListener('input', function() {
                state.badge.weight = parseInt(this.value, 10) || 400;
                if (badgeWeightValue) badgeWeightValue.textContent = state.badge.weight;
                render();
            });
        }

        // 旋转角度
        var badgeRotationSlider = byId('badgeRotationSlider');
        var badgeRotationValue = byId('badgeRotationValue');
        if (badgeRotationSlider) {
            badgeRotationSlider.addEventListener('input', function() {
                state.badge.rotation = parseFloat(this.value) || 0;
                if (badgeRotationValue) badgeRotationValue.textContent = state.badge.rotation + '°';
                render();
            });
        }

        // 文字大小
        var badgeFontSizeSlider = byId('badgeFontSizeSlider');
        var badgeFontSizeValue = byId('badgeFontSizeValue');
        if (badgeFontSizeSlider) {
            badgeFontSizeSlider.addEventListener('input', function() {
                state.badge.fontSize = parseInt(this.value, 10) || 14;
                if (badgeFontSizeValue) badgeFontSizeValue.textContent = state.badge.fontSize;
                render();
            });
        }

        // 尺寸预设按钮
        document.querySelectorAll('#sizePresets .xnx-icon-size-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                state.size = parseInt(this.getAttribute('data-size'), 10);
                document.querySelectorAll('#sizePresets .xnx-icon-size-btn').forEach(function(b) {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                var sizeCustom = byId('sizeCustom');
                if (sizeCustom) sizeCustom.value = state.size;
                render();
            });
        });

        // 自定义尺寸
        var sizeCustom = byId('sizeCustom');
        if (sizeCustom) {
            sizeCustom.addEventListener('input', function() {
                var v = parseInt(this.value, 10);
                if (v >= 8 && v <= 1024) {
                    state.size = v;
                    document.querySelectorAll('#sizePresets .xnx-icon-size-btn').forEach(function(b) {
                        b.classList.toggle('active', parseInt(b.getAttribute('data-size'), 10) === v);
                    });
                    render();
                }
            });
        }

        // 导出按钮
        var btnCopySvg = byId('btnCopySvg');
        if (btnCopySvg) btnCopySvg.addEventListener('click', copySvg);
        var btnDownloadSvg = byId('btnDownloadSvg');
        if (btnDownloadSvg) btnDownloadSvg.addEventListener('click', downloadSvg);
        var btnDownloadPng = byId('btnDownloadPng');
        if (btnDownloadPng) btnDownloadPng.addEventListener('click', downloadPng);

        // 保存预设表单
        var saveForm = byId('savePresetForm');
        if (saveForm) {
            saveForm.addEventListener('submit', function() {
                var config = serializeState();
                var configInput = byId('presetConfig');
                if (configInput) configInput.value = JSON.stringify(config);
                // 按钮 loading
                var btnSave = byId('btnSavePreset');
                if (btnSave) {
                    btnSave.disabled = true;
                    btnSave.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>' + escapeHtml(LANG.loading || '...');
                }
                // 正常提交表单（不 preventDefault）
            });
        }

        // 预设列表套用按钮（事件委托）
        var presetListBody = byId('presetListBody');
        if (presetListBody) {
            presetListBody.addEventListener('click', function(e) {
                var btn = e.target.closest('.xnx-icon-apply-preset');
                if (!btn) return;
                var name = btn.getAttribute('data-preset-name');
                var builtin = btn.getAttribute('data-preset-builtin') === '1';
                var preset = findPresetByName(name, builtin);
                if (preset) {
                    applyPreset(preset);
                    // 切换到图标合成 tab
                    var genTab = document.querySelector('button[data-tab-hash="tab-generator"]');
                    if (genTab) {
                        try {
                            var tabInst = bootstrap.Tab.getInstance(genTab) || new bootstrap.Tab(genTab);
                            tabInst.show();
                        } catch (e2) { genTab.click(); }
                    }
                }
            });
        }
    }

    // ========== 初始化 ==========
    function init() {
        bindEvents();
        syncControlsFromState();
        render();
        loadIcons();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
