<?php
/*
    xnx_icon 插件 - 前台路由
    URL 格式：
      /icon.htm          - 图标生成器页面（GET）
      /icon.htm          - 保存预设（POST，icon_action=save_preset）

    访问权限由后台 access_gids 配置控制：
      空数组  = 所有用户组可访问（含游客）
      非空数组 = 仅数组中的 gid 可访问
*/
!defined('DEBUG') AND exit('Access Denied');

if (!class_exists('IconPresetService', false)) {
    include_once APP_PATH . 'plugin/xnx_icon/model/IconPresetService.php';
}

// ==================== 权限检查 ====================
global $gid, $uid;
$settings = IconPresetService::getSettings();
$access_gids = isset($settings['access_gids']) && is_array($settings['access_gids']) ? $settings['access_gids'] : array();
// 空数组 = 所有用户组可访问（默认全开）
if (!empty($access_gids) && !in_array(intval($gid), $access_gids, true)) {
    message(-1, lang('xnx_icon_no_permission'));
}

// ==================== icons.json 数据输出（GET，供前端 fetch）====================
// 静态 .json 文件在某些服务器配置下会 404，改由 PHP 路由 readfile 输出更稳健
if ($method == 'GET' && param('icon_action') === 'icons_data') {
    $_icons_file = APP_PATH . 'plugin/xnx_icon/static/data/icons.json';
    if (!is_file($_icons_file)) {
        http_response_code(404);
        header('Content-Type: application/json; charset=utf-8');
        exit('{}');
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: public, max-age=86400');
    readfile($_icons_file);
    exit;
}

// ==================== POST 操作 ====================
if ($method == 'POST') {
    CsrfService::check();
    $icon_action = param('icon_action', '');

    // ---------- 保存自定义预设（仅登录用户）----------
    if ($icon_action == 'save_preset') {
        if (empty($uid)) {
            message(-1, lang('xnx_icon_login_required'));
        }
        $name = trim(param('preset_name', ''));
        if ($name === '') {
            message(-1, lang('xnx_icon_preset_name_required'));
        }
        // config 由前端序列化为 JSON 字符串提交，关闭 htmlspecialchars 避免破坏 JSON
        $config_json = param('preset_config', '', FALSE);
        $config = $config_json !== '' ? json_decode($config_json, true) : array();
        if (!is_array($config)) {
            $config = array();
        }
        $data = $config;
        $data['name'] = $name;
        // 管理员可选择保存为全局预设（uid=0），普通用户强制 uid=当前用户
        $is_admin = (!empty($gid) && ($gid == 1 || $gid == 2));
        $is_global = $is_admin && param('is_global', 0);
        $save_uid = $is_global ? 0 : intval($uid);
        // 先检查重名，区分"已存在"和"写入失败"
        if (IconPresetService::getPresetByName($name, $save_uid) !== null) {
            message(-1, lang('xnx_icon_preset_exists'));
        }
        $ok = IconPresetService::savePreset($data, $save_uid);
        if (!$ok) {
            message(-1, lang('xnx_icon_preset_save_failed'));
        }
        message(0, lang('xnx_icon_preset_saved'), array('redirect_url' => url('icon')));
    }

    // 未知 action
    message(-1, lang('xnx_icon_invalid_param'));
}

// ==================== GET：图标生成器页面 ====================
$builtin_presets = IconPresetService::listBuiltinPresets();
$custom_presets  = IconPresetService::listCustomPresets(intval($uid));

// 登录用户可保存预设（前端用于显示/隐藏保存表单）
$can_save_preset = !empty($uid);

$header['title']        = lang('xnx_icon_title');
$header['mobile_title']  = lang('xnx_icon_title');

include _include(APP_PATH.'view/htm/header.inc.htm');
include _include(APP_PATH.'plugin/xnx_icon/view/htm/icon.htm');
include _include(APP_PATH.'view/htm/footer.inc.htm');
