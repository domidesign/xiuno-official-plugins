# xnx_icon 图标生成器

## 功能
- 可视化图标合成器，基于 Tabler Icons 图标库实时预览
- 背景设置：纯色 / 渐变 / 无，渐变方向可调，形状支持圆形 / 圆角 / 方形
- 角标系统：文字或图标角标，4 个角位置，可配置颜色、背景、大小、旋转
- 导出 SVG / PNG，支持一键复制 SVG
- 4 个内置预设（勋章风 / 科技感 / 清风 / 复古风）+ 用户自定义预设
- 自定义预设按 uid 隔离，管理员可保存全局预设（uid=0，所有用户可见）
- 后台访问权限配置（access_gids 控制用户组，空数组=全部可访问含游客）
- 接入发现页（DiscoverService）配置

## 文件结构
```
plugin/xnx_icon/
├── conf.json
├── install.php / uninstall.php / upgrade.php
├── setting.php + view/htm/setting.htm
├── model/IconPresetService.php
├── route/icon.php
├── hook/
│   ├── model_inc_file.php
│   ├── model_route_table_end.php
│   ├── index_route_case_end.php
│   ├── lang_zh_cn_bbs.php
│   ├── lang_zh_tw_bbs.php
│   └── lang_en_us_bbs.php
├── view/htm/
│   ├── icon.htm
│   └── setting.htm
├── static/
│   ├── js/icon_generator.js
│   ├── css/icon_generator.css
│   └── data/icons.json
└── lang/
    ├── zh-cn.php
    ├── zh-tw.php
    └── en-us.php
```

## 配置流程
1. 后台启用插件
2. 进入「插件设置」→「访问权限」→ 勾选可访问前台生成器的用户组（不勾选任何组=全部可访问，含游客）
3. 测试：访问 `/icon.htm` 前台生成器，选择图标、配置背景与角标，导出 SVG/PNG；登录用户可「保存为预设」，管理员可勾选「保存为全局预设」
