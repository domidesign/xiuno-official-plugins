<?php
!defined('DEBUG') AND exit('Access Denied');

// xnx_icon 升级脚本（幂等，可重复执行）
// v1.1：内置预设改为运行时返回，清理配置表中旧版本写入的内置预设
//       新增 access_gids 配置项（前端访问权限控制）

global $db;

// v1.1 迁移：清理配置表 xnx_icon_presets 中的内置预设
// 旧版本 install.php 把 listBuiltinPresets() 返回值写入配置表，
// 导致切换语言后内置预设名称错乱（配置表存的是旧语言名称，运行时 lang() 解析的是新语言名称）
$presets = setting_get('xnx_icon_presets');
if (is_array($presets) && !empty($presets)) {
    $remaining = array();
    $changed = false;
    foreach ($presets as $p) {
        if (!empty($p['builtin'])) {
            $changed = true;
            continue;
        }
        $remaining[] = $p;
    }
    if ($changed) {
        setting_set('xnx_icon_presets', $remaining);
    }
}

// v1.1：补充 access_gids 默认配置（空数组=所有用户组可访问）
$settings = setting_get('xnx_icon');
if (is_array($settings) && !isset($settings['access_gids'])) {
    $settings['access_gids'] = array();
    setting_set('xnx_icon', $settings);
}

// 清理 tmp 缓存（确保新代码生效）
plugin_clear_tmp_dir();
