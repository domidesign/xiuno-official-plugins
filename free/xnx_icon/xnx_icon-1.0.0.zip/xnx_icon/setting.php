<?php
!defined('DEBUG') AND exit('Access Denied');

// 权限检查：仅管理员组（gid=1,2）可访问
$gid != 1 && $gid != 2 AND message(-1, lang('xnx_icon_login_required'));

if (!class_exists('IconPresetService', false)) {
    include_once APP_PATH . 'plugin/xnx_icon/model/IconPresetService.php';
}

// ========== POST 操作统一处理（必须在 include header.inc.htm 之前，message() 会发送 303 header）==========
if ($method == 'POST') {
    CsrfService::check();
    $icon_action = param('icon_action', '');
    $redirect_url = admin_plugin_setting_url('xnx_icon');

    // ---------- 删除自定义预设 ----------
    if ($icon_action == 'delete_preset') {
        $name = trim(param('preset_name', ''));
        if ($name === '') {
            message(-1, lang('xnx_icon_invalid_param'));
        }
        $ok = IconPresetService::deletePreset($name, null);
        if (!$ok) {
            message(-1, lang('xnx_icon_invalid_param'));
        }
        message(0, lang('xnx_icon_preset_deleted'), array('redirect_url' => $redirect_url));
    }

    // ---------- 编辑自定义预设 ----------
    if ($icon_action == 'edit_preset') {
        $old_name = trim(param('old_preset_name', ''));
        $new_name = trim(param('preset_name', ''));
        if ($old_name === '' || $new_name === '') {
            message(-1, lang('xnx_icon_preset_name_required'));
        }
        $config_json = param('preset_config', '', FALSE);
        $config = $config_json !== '' ? json_decode($config_json, true) : array();
        if (!is_array($config)) {
            $config = array();
        }
        $data = $config;
        $data['name'] = $new_name;
        // 先检查重名（排除自身）
        if ($new_name !== $old_name) {
            $existing = IconPresetService::getPresetByName($new_name, null);
            if ($existing !== null) {
                message(-1, lang('xnx_icon_preset_exists'));
            }
        }
        $ok = IconPresetService::updatePreset($old_name, $data, null);
        if (!$ok) {
            message(-1, lang('xnx_icon_preset_save_failed'));
        }
        message(0, lang('xnx_icon_preset_saved'), array('redirect_url' => $redirect_url));
    }

    // ---------- 保存访问权限设置 ----------
    if ($icon_action == 'save_settings') {
        // access_gids：勾选的用户组 gid 数组，空数组=所有用户组可访问
        $access_gids_raw = param('access_gids', array());
        if (!is_array($access_gids_raw)) {
            $access_gids_raw = array();
        }
        $access_gids = array();
        foreach ($access_gids_raw as $g) {
            $gid_val = intval($g);
            if ($gid_val >= 0) {
                $access_gids[] = $gid_val;
            }
        }
        $settings = IconPresetService::getSettings();
        $settings['access_gids'] = $access_gids;
        IconPresetService::saveSettings($settings);
        // 发现页设置（独立存储到 plugin_discover_items）
        include APP_PATH . 'lib/DiscoverService.php';
        DiscoverService::savePluginDiscoverConfig('xnx_icon', array(
            'enabled' => intval(param('discover_enabled', 0)),
            'icon'    => trim(param('discover_icon', '')),
            'name'    => trim(param('discover_name', '')),
            'rank'    => intval(param('discover_rank', 0)),
        ));
        message(0, lang('xnx_icon_settings_saved'), array('redirect_url' => $redirect_url));
    }

    // 未知 action
    message(-1, lang('xnx_icon_invalid_param'));
}

// ========== GET 数据准备 ==========

$settings        = IconPresetService::getSettings();

// 读取发现页配置
include APP_PATH . 'lib/DiscoverService.php';
$discover_config = DiscoverService::getPluginDiscoverConfig('xnx_icon');
$builtin_presets = IconPresetService::listBuiltinPresets();
$custom_presets  = IconPresetService::listCustomPresets(null);

// 当前已勾选的访问用户组（空数组=全部可访问）
$access_gids = isset($settings['access_gids']) && is_array($settings['access_gids']) ? $settings['access_gids'] : array();

// 用户组列表（供权限设置勾选），手动加入游客组 gid=0
$groups_raw = group_find();
$groups_list = array();
// 游客组
$groups_list[] = array('gid' => 0, 'name' => lang('xnx_icon_guest_group'));
if (!empty($groups_raw)) {
    foreach ($groups_raw as $g) {
        $groups_list[] = array('gid' => intval($g['gid']), 'name' => $g['name']);
    }
}

// 前端生成器 URL（供后台「访问前端」链接）
$frontend_url = url('icon');

$header['title']        = lang('xnx_icon_title');
$header['mobile_title']  = lang('xnx_icon_title');

include _include(APP_PATH . 'plugin/xnx_icon/view/htm/setting.htm');
