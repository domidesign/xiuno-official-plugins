<?php
!defined('DEBUG') AND exit('Access Denied');

// xnx_icon 安装脚本
// 本插件不建表，仅写入默认配置到 setting 表
// 内置预设由 IconPresetService::listBuiltinPresets() 运行时返回，不写入配置表
// 配置表 xnx_icon_presets 仅存储用户自定义预设

// 初始化自定义预设存储（空数组，用户在前端保存预设时追加）
if (setting_get('xnx_icon_presets') === null) {
    setting_set('xnx_icon_presets', array());
}

// 写入插件默认配置
if (setting_get('xnx_icon') === null) {
    setting_set('xnx_icon', array(
        'enabled' => 1,
        // 访问权限：空数组=所有用户组可访问（含游客）
        'access_gids' => array(),
    ));
}
