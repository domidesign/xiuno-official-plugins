// xnx_icon 语言包（zh-cn）- 必须使用 $lang['key'] = 'value'; 格式
// Xiuno 编译器对语言 hook 有安全检查：只允许 $lang['key']='value'; 赋值，不能用 include/array_merge

// ========== 基础信息 ==========
$lang['xnx_icon_menu'] = '图标生成器';
$lang['xnx_icon_name'] = '图标生成器';
$lang['xnx_icon_brief'] = '可视化图标合成器，支持背景/圆角/角标，导出 SVG/PNG';
$lang['xnx_icon_title'] = '图标生成器';

// ========== 后台 Tab ==========
$lang['xnx_icon_tab_presets'] = '预设管理';
$lang['xnx_icon_tab_access'] = '访问权限';

// ========== 预设管理 ==========
$lang['xnx_icon_preset_list'] = '预设列表';
$lang['xnx_icon_preset_name'] = '预设名称';
$lang['xnx_icon_preset_type'] = '类型';
$lang['xnx_icon_badge'] = '角标';
$lang['xnx_icon_builtin_presets'] = '内置';
$lang['xnx_icon_custom_presets'] = '自定义';
$lang['xnx_icon_builtin_no_delete'] = '内置不可删除';
$lang['xnx_icon_delete_preset'] = '删除预设';
$lang['xnx_icon_confirm_delete'] = '确认删除该预设吗？';
$lang['xnx_icon_no_presets'] = '暂无预设';
$lang['xnx_icon_edit_preset'] = '编辑预设';
$lang['xnx_icon_edit_preset_config'] = '预设配置';
$lang['xnx_icon_edit_preset_tip'] = '如需修改图标/背景/角标等配置，请到前端生成器调整后重新保存为新预设';

// ========== 内置预设名称 ==========
$lang['xnx_icon_preset_award'] = '勋章风';
$lang['xnx_icon_preset_tech'] = '科技感';
$lang['xnx_icon_preset_fresh'] = '清风';
$lang['xnx_icon_preset_retro'] = '复古风';

// ========== 访问权限 ==========
$lang['xnx_icon_access_settings'] = '访问权限设置';
$lang['xnx_icon_access_gids'] = '可访问的用户组';
$lang['xnx_icon_access_gids_help'] = '不勾选任何用户组则所有用户组可访问（含游客）';
$lang['xnx_icon_guest_group'] = '游客';
$lang['xnx_icon_settings_saved'] = '设置已保存';

// ========== 操作消息 ==========
$lang['xnx_icon_preset_saved'] = '预设已保存';
$lang['xnx_icon_preset_deleted'] = '预设已删除';
$lang['xnx_icon_preset_exists'] = '预设名称已存在';
$lang['xnx_icon_preset_save_failed'] = '预设保存失败，请重试';
$lang['xnx_icon_preset_global'] = '保存为全局预设（所有用户可见）';
$lang['xnx_icon_preset_name_required'] = '请输入预设名称';
$lang['xnx_icon_no_permission'] = '无权访问图标生成器';
$lang['xnx_icon_login_required'] = '请先登录';
$lang['xnx_icon_invalid_param'] = '参数错误';
$lang['xnx_icon_visit_frontend'] = '访问前端';
$lang['xnx_icon_admin_manage'] = '后台管理';
$lang['xnx_icon_save_preset_login_required'] = '后可保存预设';

// ========== 生成器界面 ==========
$lang['xnx_icon_select_icon'] = '选择图标';
$lang['xnx_icon_search'] = '搜索图标...';
$lang['xnx_icon_loading'] = '加载中...';
$lang['xnx_icon_background'] = '背景设置';
$lang['xnx_icon_bg_solid'] = '纯色';
$lang['xnx_icon_bg_gradient'] = '渐变';
$lang['xnx_icon_bg_none'] = '无';
$lang['xnx_icon_bg_color1'] = '颜色 1';
$lang['xnx_icon_bg_color2'] = '颜色 2';
$lang['xnx_icon_bg_direction'] = '渐变方向';
$lang['xnx_icon_bg_shape'] = '背景形状';
$lang['xnx_icon_shape_circle'] = '圆形';
$lang['xnx_icon_shape_rounded'] = '圆角';
$lang['xnx_icon_shape_square'] = '方形';
$lang['xnx_icon_radius'] = '圆角半径';
$lang['xnx_icon_radius_tip'] = '0=方形，100=圆形，滑动调整圆角大小';
$lang['xnx_icon_icon_size'] = '图标大小';
$lang['xnx_icon_icon_size_tip'] = '主图标占画布的百分比';
$lang['xnx_icon_icon_color'] = '图标颜色';
$lang['xnx_icon_presets'] = '预设模板';
$lang['xnx_icon_preview'] = '实时预览';
$lang['xnx_icon_no_icon_selected'] = '请选择图标';
$lang['xnx_icon_copy_svg'] = '复制 SVG';
$lang['xnx_icon_download_svg'] = '下载 SVG';
$lang['xnx_icon_download_png'] = '下载 PNG';
$lang['xnx_icon_export'] = '导出';
$lang['xnx_icon_save_as_preset'] = '保存为预设';

// ========== 角标 ==========
$lang['xnx_icon_badge_enable'] = '启用角标';
$lang['xnx_icon_badge_position'] = '角标位置';
$lang['xnx_icon_pos_top_left'] = '左上';
$lang['xnx_icon_pos_top_right'] = '右上';
$lang['xnx_icon_pos_bottom_left'] = '左下';
$lang['xnx_icon_pos_bottom_right'] = '右下';
$lang['xnx_icon_badge_type'] = '角标类型';
$lang['xnx_icon_badge_type_text'] = '文字';
$lang['xnx_icon_badge_type_icon'] = '图标';
$lang['xnx_icon_badge_content'] = '角标内容';
$lang['xnx_icon_badge_color'] = '角标颜色';
$lang['xnx_icon_badge_bg'] = '角标背景';
$lang['xnx_icon_badge_size'] = '角标大小';
$lang['xnx_icon_badge_weight'] = '文字粗细';
$lang['xnx_icon_badge_rotation'] = '旋转角度';
$lang['xnx_icon_badge_font_size'] = '文字大小';

// ========== 尺寸 ==========
$lang['xnx_icon_size'] = '尺寸';
$lang['xnx_icon_size_custom'] = '自定义尺寸';

// ========== JS 消息 ==========
$lang['xnx_icon_copy_success'] = '已复制到剪贴板';
$lang['xnx_icon_copy_failed'] = '复制失败';
$lang['xnx_icon_load_icons_failed'] = '图标库加载失败';
$lang['xnx_icon_icons_count'] = '共 {count} 个图标';
$lang['xnx_icon_all_categories'] = '全部分类';
