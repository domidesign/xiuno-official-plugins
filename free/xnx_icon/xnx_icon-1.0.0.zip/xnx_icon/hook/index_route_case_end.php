<?php exit;
// 注册图标生成器前台路由 case 分发
// 编译后此 case 会拼接到 index.inc.php 的 switch($route) 中
// URL: /icon.htm -> 图标生成器页面（GET）+ 保存预设（POST）
case 'icon': include _include(APP_PATH.'plugin/xnx_icon/route/icon.php'); break;
