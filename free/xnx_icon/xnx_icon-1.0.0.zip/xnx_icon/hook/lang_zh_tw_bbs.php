// xnx_icon 語言包（zh-tw）- 必須使用 $lang['key'] = 'value'; 格式
// Xiuno 編譯器對語言 hook 有安全檢查：只允許 $lang['key']='value'; 賦值，不能用 include/array_merge

// ========== 基礎資訊 ==========
$lang['xnx_icon_menu'] = '圖示產生器';
$lang['xnx_icon_name'] = '圖示產生器';
$lang['xnx_icon_brief'] = '視覺化圖示合成器，支援背景/圓角/角標，匯出 SVG/PNG';
$lang['xnx_icon_title'] = '圖示產生器';

// ========== 後台 Tab ==========
$lang['xnx_icon_tab_presets'] = '預設管理';
$lang['xnx_icon_tab_access'] = '存取權限';

// ========== 預設管理 ==========
$lang['xnx_icon_preset_list'] = '預設列表';
$lang['xnx_icon_preset_name'] = '預設名稱';
$lang['xnx_icon_preset_type'] = '類型';
$lang['xnx_icon_badge'] = '角標';
$lang['xnx_icon_builtin_presets'] = '內建';
$lang['xnx_icon_custom_presets'] = '自訂';
$lang['xnx_icon_builtin_no_delete'] = '內建不可刪除';
$lang['xnx_icon_delete_preset'] = '刪除預設';
$lang['xnx_icon_confirm_delete'] = '確認刪除該預設嗎？';
$lang['xnx_icon_no_presets'] = '暫無預設';
$lang['xnx_icon_edit_preset'] = '編輯預設';
$lang['xnx_icon_edit_preset_config'] = '預設配置';
$lang['xnx_icon_edit_preset_tip'] = '如需修改圖示/背景/角標等配置，請到前端產生器調整後重新儲存為新預設';

// ========== 內建預設名稱 ==========
$lang['xnx_icon_preset_award'] = '勳章風';
$lang['xnx_icon_preset_tech'] = '科技感';
$lang['xnx_icon_preset_fresh'] = '清風';
$lang['xnx_icon_preset_retro'] = '復古風';

// ========== 存取權限 ==========
$lang['xnx_icon_access_settings'] = '存取權限設定';
$lang['xnx_icon_access_gids'] = '可存取的使用者群組';
$lang['xnx_icon_access_gids_help'] = '不勾選任何使用者群組則所有使用者群組可存取（含遊客）';
$lang['xnx_icon_guest_group'] = '遊客';
$lang['xnx_icon_settings_saved'] = '設定已儲存';

// ========== 操作訊息 ==========
$lang['xnx_icon_preset_saved'] = '預設已儲存';
$lang['xnx_icon_preset_deleted'] = '預設已刪除';
$lang['xnx_icon_preset_exists'] = '預設名稱已存在';
$lang['xnx_icon_preset_save_failed'] = '預設儲存失敗，請重試';
$lang['xnx_icon_preset_global'] = '儲存為全域預設（所有使用者可見）';
$lang['xnx_icon_preset_name_required'] = '請輸入預設名稱';
$lang['xnx_icon_no_permission'] = '無權存取圖示產生器';
$lang['xnx_icon_login_required'] = '請先登入';
$lang['xnx_icon_invalid_param'] = '參數錯誤';
$lang['xnx_icon_visit_frontend'] = '訪問前端';
$lang['xnx_icon_admin_manage'] = '後台管理';
$lang['xnx_icon_save_preset_login_required'] = '後可儲存預設';

// ========== 產生器介面 ==========
$lang['xnx_icon_select_icon'] = '選擇圖示';
$lang['xnx_icon_search'] = '搜尋圖示...';
$lang['xnx_icon_loading'] = '載入中...';
$lang['xnx_icon_background'] = '背景設定';
$lang['xnx_icon_bg_solid'] = '純色';
$lang['xnx_icon_bg_gradient'] = '漸層';
$lang['xnx_icon_bg_none'] = '無';
$lang['xnx_icon_bg_color1'] = '顏色 1';
$lang['xnx_icon_bg_color2'] = '顏色 2';
$lang['xnx_icon_bg_direction'] = '漸層方向';
$lang['xnx_icon_bg_shape'] = '背景形狀';
$lang['xnx_icon_shape_circle'] = '圓形';
$lang['xnx_icon_shape_rounded'] = '圓角';
$lang['xnx_icon_shape_square'] = '方形';
$lang['xnx_icon_radius'] = '圓角半徑';
$lang['xnx_icon_radius_tip'] = '0=方形，100=圓形，滑動調整圓角大小';
$lang['xnx_icon_icon_size'] = '圖示大小';
$lang['xnx_icon_icon_size_tip'] = '主圖示佔畫布的百分比';
$lang['xnx_icon_icon_color'] = '圖示顏色';
$lang['xnx_icon_presets'] = '預設範本';
$lang['xnx_icon_preview'] = '即時預覽';
$lang['xnx_icon_no_icon_selected'] = '請選擇圖示';
$lang['xnx_icon_copy_svg'] = '複製 SVG';
$lang['xnx_icon_download_svg'] = '下載 SVG';
$lang['xnx_icon_download_png'] = '下載 PNG';
$lang['xnx_icon_export'] = '匯出';
$lang['xnx_icon_save_as_preset'] = '儲存為預設';

// ========== 角標 ==========
$lang['xnx_icon_badge_enable'] = '啟用角標';
$lang['xnx_icon_badge_position'] = '角標位置';
$lang['xnx_icon_pos_top_left'] = '左上';
$lang['xnx_icon_pos_top_right'] = '右上';
$lang['xnx_icon_pos_bottom_left'] = '左下';
$lang['xnx_icon_pos_bottom_right'] = '右下';
$lang['xnx_icon_badge_type'] = '角標類型';
$lang['xnx_icon_badge_type_text'] = '文字';
$lang['xnx_icon_badge_type_icon'] = '圖示';
$lang['xnx_icon_badge_content'] = '角標內容';
$lang['xnx_icon_badge_color'] = '角標顏色';
$lang['xnx_icon_badge_bg'] = '角標背景';
$lang['xnx_icon_badge_size'] = '角標大小';
$lang['xnx_icon_badge_weight'] = '文字粗細';
$lang['xnx_icon_badge_rotation'] = '旋轉角度';
$lang['xnx_icon_badge_font_size'] = '文字大小';

// ========== 尺寸 ==========
$lang['xnx_icon_size'] = '尺寸';
$lang['xnx_icon_size_custom'] = '自訂尺寸';

// ========== JS 訊息 ==========
$lang['xnx_icon_copy_success'] = '已複製到剪貼簿';
$lang['xnx_icon_copy_failed'] = '複製失敗';
$lang['xnx_icon_load_icons_failed'] = '圖示庫載入失敗';
$lang['xnx_icon_icons_count'] = '共 {count} 個圖示';
$lang['xnx_icon_all_categories'] = '全部分類';
