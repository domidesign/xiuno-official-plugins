// xnx_icon language pack (en-us) - must use $lang['key'] = 'value'; format
// Xiuno compiler safety check: only $lang['key']='value'; assignments allowed

// ========== Basic ==========
$lang['xnx_icon_menu'] = 'Icon Generator';
$lang['xnx_icon_name'] = 'Icon Generator';
$lang['xnx_icon_brief'] = 'Visual icon composer with background/radius/badge, export SVG/PNG';
$lang['xnx_icon_title'] = 'Icon Generator';

// ========== Admin Tabs ==========
$lang['xnx_icon_tab_presets'] = 'Presets';
$lang['xnx_icon_tab_access'] = 'Access';

// ========== Preset Management ==========
$lang['xnx_icon_preset_list'] = 'Preset List';
$lang['xnx_icon_preset_name'] = 'Preset Name';
$lang['xnx_icon_preset_type'] = 'Type';
$lang['xnx_icon_badge'] = 'Badge';
$lang['xnx_icon_builtin_presets'] = 'Built-in';
$lang['xnx_icon_custom_presets'] = 'Custom';
$lang['xnx_icon_builtin_no_delete'] = 'Built-in, cannot delete';
$lang['xnx_icon_delete_preset'] = 'Delete Preset';
$lang['xnx_icon_confirm_delete'] = 'Delete this preset?';
$lang['xnx_icon_no_presets'] = 'No presets';
$lang['xnx_icon_edit_preset'] = 'Edit Preset';
$lang['xnx_icon_edit_preset_config'] = 'Preset Config';
$lang['xnx_icon_edit_preset_tip'] = 'To modify icon/background/badge config, use the frontend generator and save as a new preset';

// ========== Built-in Preset Names ==========
$lang['xnx_icon_preset_award'] = 'Medal';
$lang['xnx_icon_preset_tech'] = 'Tech';
$lang['xnx_icon_preset_fresh'] = 'Fresh';
$lang['xnx_icon_preset_retro'] = 'Retro';

// ========== Access Control ==========
$lang['xnx_icon_access_settings'] = 'Access Settings';
$lang['xnx_icon_access_gids'] = 'Allowed User Groups';
$lang['xnx_icon_access_gids_help'] = 'Leave unchecked to allow all user groups (including guests)';
$lang['xnx_icon_guest_group'] = 'Guest';
$lang['xnx_icon_settings_saved'] = 'Settings saved';

// ========== Messages ==========
$lang['xnx_icon_preset_saved'] = 'Preset saved';
$lang['xnx_icon_preset_deleted'] = 'Preset deleted';
$lang['xnx_icon_preset_exists'] = 'Preset name already exists';
$lang['xnx_icon_preset_save_failed'] = 'Failed to save preset, please retry';
$lang['xnx_icon_preset_global'] = 'Save as global preset (visible to all users)';
$lang['xnx_icon_preset_name_required'] = 'Please enter a preset name';
$lang['xnx_icon_no_permission'] = 'No permission to access the icon generator';
$lang['xnx_icon_login_required'] = 'Please log in first';
$lang['xnx_icon_invalid_param'] = 'Invalid parameter';
$lang['xnx_icon_visit_frontend'] = 'Open Frontend';
$lang['xnx_icon_admin_manage'] = 'Admin';
$lang['xnx_icon_save_preset_login_required'] = ' to save presets';

// ========== Generator UI ==========
$lang['xnx_icon_select_icon'] = 'Select Icon';
$lang['xnx_icon_search'] = 'Search icons...';
$lang['xnx_icon_loading'] = 'Loading...';
$lang['xnx_icon_background'] = 'Background';
$lang['xnx_icon_bg_solid'] = 'Solid';
$lang['xnx_icon_bg_gradient'] = 'Gradient';
$lang['xnx_icon_bg_none'] = 'None';
$lang['xnx_icon_bg_color1'] = 'Color 1';
$lang['xnx_icon_bg_color2'] = 'Color 2';
$lang['xnx_icon_bg_direction'] = 'Gradient Direction';
$lang['xnx_icon_bg_shape'] = 'Background Shape';
$lang['xnx_icon_shape_circle'] = 'Circle';
$lang['xnx_icon_shape_rounded'] = 'Rounded';
$lang['xnx_icon_shape_square'] = 'Square';
$lang['xnx_icon_radius'] = 'Corner Radius';
$lang['xnx_icon_radius_tip'] = '0=square, 100=circle, slide to adjust';
$lang['xnx_icon_icon_size'] = 'Icon Size';
$lang['xnx_icon_icon_size_tip'] = 'Percentage of canvas occupied by main icon';
$lang['xnx_icon_icon_color'] = 'Icon Color';
$lang['xnx_icon_presets'] = 'Presets';
$lang['xnx_icon_preview'] = 'Live Preview';
$lang['xnx_icon_no_icon_selected'] = 'Please select an icon';
$lang['xnx_icon_copy_svg'] = 'Copy SVG';
$lang['xnx_icon_download_svg'] = 'Download SVG';
$lang['xnx_icon_download_png'] = 'Download PNG';
$lang['xnx_icon_export'] = 'Export';
$lang['xnx_icon_save_as_preset'] = 'Save as Preset';

// ========== Badge ==========
$lang['xnx_icon_badge_enable'] = 'Enable Badge';
$lang['xnx_icon_badge_position'] = 'Badge Position';
$lang['xnx_icon_pos_top_left'] = 'Top Left';
$lang['xnx_icon_pos_top_right'] = 'Top Right';
$lang['xnx_icon_pos_bottom_left'] = 'Bottom Left';
$lang['xnx_icon_pos_bottom_right'] = 'Bottom Right';
$lang['xnx_icon_badge_type'] = 'Badge Type';
$lang['xnx_icon_badge_type_text'] = 'Text';
$lang['xnx_icon_badge_type_icon'] = 'Icon';
$lang['xnx_icon_badge_content'] = 'Badge Content';
$lang['xnx_icon_badge_color'] = 'Badge Color';
$lang['xnx_icon_badge_bg'] = 'Badge Background';
$lang['xnx_icon_badge_size'] = 'Badge Size';
$lang['xnx_icon_badge_weight'] = 'Font Weight';
$lang['xnx_icon_badge_rotation'] = 'Rotation';
$lang['xnx_icon_badge_font_size'] = 'Font Size';

// ========== Size ==========
$lang['xnx_icon_size'] = 'Size';
$lang['xnx_icon_size_custom'] = 'Custom Size';

// ========== JS Messages ==========
$lang['xnx_icon_copy_success'] = 'Copied to clipboard';
$lang['xnx_icon_copy_failed'] = 'Copy failed';
$lang['xnx_icon_load_icons_failed'] = 'Failed to load icons';
$lang['xnx_icon_icons_count'] = '{count} icons';
$lang['xnx_icon_all_categories'] = 'All Categories';
