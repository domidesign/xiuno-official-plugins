<?php exit;
// 注册图标生成器前台路由到 $routes 数组
// 编译后此行会拼接到 route_table() 函数内，可直接修改 $routes
// url('icon') 生成 /icon.htm 伪静态 URL
$routes['icon'] = 'icon';
