<?php exit;
// 注册 IconPresetService 到 model.inc.php 包含列表
// 编译后拼进 model.inc.php 的 include 数组，框架启动时自动加载
APP_PATH.'plugin/xnx_icon/model/IconPresetService.php',
