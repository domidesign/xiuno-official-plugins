<?php
!defined('DEBUG') AND exit('Access Denied');

// ponytail: 由 DiscoverService::ensureRegistered() 在首次访问注册表前 include
// 插件自注册到发现页，避免修改系统核心文件 lib/DiscoverService.php
DiscoverService::register('xnx_icon', array(
    'url'       => 'icon',
    'icon'      => 'ti-icons',
    'name_lang' => 'discover_plugin_name_icon',
    'rank'      => 110,
));
