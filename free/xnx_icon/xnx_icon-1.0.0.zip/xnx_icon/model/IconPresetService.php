<?php
!defined('DEBUG') AND exit('Access Denied');

/**
 * IconPresetService 图标预设服务
 *
 * 管理图标生成器的预设模板：
 * - 4 个内置硬编码预设（勋章风/科技感/清风/复古风）
 * - 用户自定义预设（存储在 setting 表的 xnx_icon_presets 键）
 *
 * 预设数据结构：
 *   name       预设名称
 *   builtin    是否内置预设（true=内置，不可删除）
 *   icon       图标名称（Tabler Icons）
 *   bg_type    背景类型 solid/gradient/none
 *   bg_color1  起始色
 *   bg_color2  结束色
 *   bg_direction 渐变方向（0-360）
 *   bg_shape   背景形状 circle/rounded/square
 *   radius     圆角半径
 *   size       输出尺寸
 *   badge      角标配置 {enabled,position,type,content,color,bg,size}
 *   created    创建时间戳（仅自定义预设）
 *
 * 数据量小，不使用缓存（CacheHelper），直接读写 setting 表。
 */
class IconPresetService {

    /**
     * 内置预设名称的 lang 键（运行时解析，避免硬编码中文）
     */
    const PRESET_LANG_KEY_AWARD = 'xnx_icon_preset_award';
    const PRESET_LANG_KEY_TECH  = 'xnx_icon_preset_tech';
    const PRESET_LANG_KEY_FRESH = 'xnx_icon_preset_fresh';
    const PRESET_LANG_KEY_RETRO = 'xnx_icon_preset_retro';

    /**
     * 默认插件配置（与 install.php 保持一致）
     * @var array
     */
    private static $defaultSettings = array(
        'enabled' => 1,
    );

    // ============ 设置相关 ============

    /**
     * 获取插件配置（合并默认值）
     * @return array
     */
    public static function getSettings() {
        $s = setting_get('xnx_icon');
        if (empty($s) || !is_array($s)) {
            return self::$defaultSettings;
        }
        return array_merge(self::$defaultSettings, $s);
    }

    /**
     * 保存插件配置
     * @param array $arr
     * @return bool
     */
    public static function saveSettings($arr) {
        return setting_set('xnx_icon', $arr);
    }

    // ============ 预设管理 ============

    /**
     * 返回全部预设（内置 + 自定义合并）
     * @return array
     */
    public static function listPresets() {
        $builtin = self::listBuiltinPresets();
        $custom  = self::listCustomPresets();
        return array_merge($builtin, $custom);
    }

    /**
     * 返回 4 个硬编码内置预设
     * 名称通过 lang() 解析，避免硬编码中文
     * @return array
     */
    public static function listBuiltinPresets() {
        return array(
            array(
                'name'         => lang(self::PRESET_LANG_KEY_AWARD),
                'builtin'       => true,
                'icon'          => 'award',
                'bg_type'       => 'gradient',
                'bg_color1'     => '#FFD700',
                'bg_color2'     => '#FFA500',
                'bg_direction'  => 135,
                'radius'        => 100,
                'size'          => 128,
                'badge'         => array(
                    'enabled'  => true,
                    'position' => 'bottom-right',
                    'type'     => 'icon',
                    'content'  => 'star',
                    'color'    => '#fff',
                    'bg'       => '#FF4500',
                    'size'     => 16,
                ),
            ),
            array(
                'name'         => lang(self::PRESET_LANG_KEY_TECH),
                'builtin'       => true,
                'icon'          => 'cpu',
                'bg_type'       => 'solid',
                'bg_color1'     => '#1E3A8A',
                'bg_color2'     => '#1E3A8A',
                'bg_direction'  => 135,
                'radius'        => 12,
                'size'          => 128,
                'badge'         => array(
                    'enabled'  => true,
                    'position' => 'top-right',
                    'type'     => 'text',
                    'content'  => 'NEW',
                    'color'    => '#fff',
                    'bg'       => '#10B981',
                    'size'     => 12,
                ),
            ),
            array(
                'name'         => lang(self::PRESET_LANG_KEY_FRESH),
                'builtin'       => true,
                'icon'          => 'leaf',
                'bg_type'       => 'solid',
                'bg_color1'     => '#86EFAC',
                'bg_color2'     => '#86EFAC',
                'bg_direction'  => 135,
                'radius'        => 100,
                'size'          => 128,
                'badge'         => array(
                    'enabled'  => false,
                    'position' => 'bottom-right',
                    'type'     => 'text',
                    'content'  => '',
                    'color'    => '#fff',
                    'bg'       => '#000',
                    'size'     => 12,
                ),
            ),
            array(
                'name'         => lang(self::PRESET_LANG_KEY_RETRO),
                'builtin'       => true,
                'icon'          => 'archive',
                'bg_type'       => 'gradient',
                'bg_color1'     => '#92400E',
                'bg_color2'     => '#D97706',
                'bg_direction'  => 180,
                'radius'        => 0,
                'size'          => 128,
                'badge'         => array(
                    'enabled'  => false,
                    'position' => 'bottom-right',
                    'type'     => 'text',
                    'content'  => '',
                    'color'    => '#fff',
                    'bg'       => '#000',
                    'size'     => 12,
                ),
            ),
        );
    }

    /**
     * 返回用户自定义预设列表
     * setting_set/get 原生支持数组存取，无需 JSON 中转
     * 过滤掉 builtin=true 的项：旧版本 install.php 曾把内置预设写入配置表，
     * 现在内置预设由 listBuiltinPresets() 运行时返回，配置表只存自定义预设
     * @return array
     */
    public static function listCustomPresets($uid = null) {
        $presets = setting_get('xnx_icon_presets');
        if (empty($presets) || !is_array($presets)) {
            return array();
        }
        $custom = array();
        foreach ($presets as $p) {
            if (!empty($p['builtin'])) {
                continue;
            }
            if ($uid === null) {
                // 后台管理：返回全部
                $custom[] = $p;
            } else {
                $uid_int = intval($uid);
                $p_uid = isset($p['uid']) ? intval($p['uid']) : 0;
                // uid=0 的预设是管理员全局预设，所有人可见
                // 其他 uid 的预设仅该用户可见
                if ($p_uid === 0 || $p_uid === $uid_int) {
                    $custom[] = $p;
                }
            }
        }
        return $custom;
    }

    /**
     * 保存（追加）一个自定义预设
     * 检查名称唯一性（含内置预设名称），重名返回 false
     * @param array $data 预设数据（含 name 字段）
     * @return bool
     */
    public static function savePreset($data, $uid = 0) {
        if (empty($data['name'])) {
            return false;
        }
        $name = trim($data['name']);
        if ($name === '') {
            return false;
        }
        $uid = intval($uid);
        // 名称唯一性校验（含内置 + 当前用户可见的自定义）
        if (self::getPresetByName($name, $uid) !== null) {
            return false;
        }
        $data['name']   = $name;
        $data['builtin'] = false;
        $data['uid']     = $uid;
        $data['created'] = time();
        // 读取全部预设（不过滤 uid），追加后写回
        $all = setting_get('xnx_icon_presets');
        if (empty($all) || !is_array($all)) {
            $all = array();
        }
        // 过滤掉 builtin（旧版本可能残留）
        $custom = array();
        foreach ($all as $p) {
            if (!empty($p['builtin'])) continue;
            $custom[] = $p;
        }
        $custom[] = $data;
        // setting_set 对 bbs_kv 表 REPLACE 返回 last_insert_id，kv 表无自增主键恒为 0（falsy），
        // 不能用 !$ok 判断；失败时返回 FALSE，用 !== false 区分（已违反 1 次：前台保存提示失败但实际成功）
        return setting_set('xnx_icon_presets', $custom) !== false;
    }

    /**
     * 更新已有自定义预设（按原名称查找，替换为新数据）
     * @param string $oldName 原预设名称
     * @param array $data 新预设数据（含 name 字段）
     * @return bool
     */
    public static function updatePreset($oldName, $data, $uid = null) {
        $oldName = trim($oldName);
        if ($oldName === '' || empty($data['name'])) {
            return false;
        }
        $newName = trim($data['name']);
        // 如果改名，检查新名称不与已有预设冲突（排除自身）
        if ($newName !== $oldName) {
            $existing = self::getPresetByName($newName, $uid);
            if ($existing !== null) {
                return false;
            }
        }
        // 读取全部预设（不过滤 uid）
        $all = setting_get('xnx_icon_presets');
        if (empty($all) || !is_array($all)) {
            $all = array();
        }
        $custom = array();
        foreach ($all as $p) {
            if (!empty($p['builtin'])) continue;
            $custom[] = $p;
        }
        $found = false;
        foreach ($custom as $i => $p) {
            if (isset($p['name']) && $p['name'] === $oldName) {
                if ($uid !== null) {
                    $p_uid = isset($p['uid']) ? intval($p['uid']) : 0;
                    if ($p_uid !== intval($uid)) continue; // 只能改自己的
                }
                $data['name'] = $newName;
                $data['builtin'] = false;
                $data['uid'] = $uid !== null ? intval($uid) : (isset($p['uid']) ? intval($p['uid']) : 0);
                $data['created'] = isset($p['created']) ? $p['created'] : time();
                $custom[$i] = $data;
                $found = true;
                break;
            }
        }
        if (!$found) {
            return false;
        }
        return setting_set('xnx_icon_presets', $custom) !== false;
    }

    /**
     * 按名称删除一个自定义预设
     * 内置预设不可删除，仅删除自定义中名称匹配的项
     * @param string $name
     * @return bool
     */
    public static function deletePreset($name, $uid = null) {
        $name = trim($name);
        if ($name === '') {
            return false;
        }
        // 读取全部预设（不过滤 uid）
        $all = setting_get('xnx_icon_presets');
        if (empty($all) || !is_array($all)) {
            return false;
        }
        $custom = array();
        foreach ($all as $p) {
            if (!empty($p['builtin'])) continue;
            $custom[] = $p;
        }
        $found = false;
        $remaining = array();
        foreach ($custom as $p) {
            if (isset($p['name']) && $p['name'] === $name) {
                if ($uid === null) {
                    // 后台：删除任意
                    $found = true;
                    continue;
                }
                $p_uid = isset($p['uid']) ? intval($p['uid']) : 0;
                $uid_int = intval($uid);
                if ($p_uid === $uid_int) {
                    $found = true;
                    continue;
                }
            }
            $remaining[] = $p;
        }
        if (!$found) {
            return false;
        }
        return setting_set('xnx_icon_presets', $remaining) !== false;
    }

    /**
     * 按名称查找预设（内置 + 自定义）
     * @param string $name
     * @return array|null 未找到返回 null
     */
    public static function getPresetByName($name, $uid = null) {
        $name = trim($name);
        if ($name === '') {
            return null;
        }
        // 内置预设始终参与查重
        foreach (self::listBuiltinPresets() as $p) {
            if (isset($p['name']) && $p['name'] === $name) {
                return $p;
            }
        }
        // 自定义预设：传 uid 则只查该用户可见的，不传则查全部
        if ($uid === null) {
            $all = setting_get('xnx_icon_presets');
            if (empty($all) || !is_array($all)) return null;
            foreach ($all as $p) {
                if (!empty($p['builtin'])) continue;
                if (isset($p['name']) && $p['name'] === $name) {
                    return $p;
                }
            }
        } else {
            foreach (self::listCustomPresets(intval($uid)) as $p) {
                if (isset($p['name']) && $p['name'] === $name) {
                    return $p;
                }
            }
        }
        return null;
    }
}
