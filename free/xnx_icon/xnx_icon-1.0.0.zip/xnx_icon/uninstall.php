<?php
!defined('DEBUG') AND exit('Access Denied');

// xnx_icon 卸载脚本
// 本插件不建表，仅清理 setting 表中的配置与自定义预设

setting_delete('xnx_icon');
setting_delete('xnx_icon_presets');
