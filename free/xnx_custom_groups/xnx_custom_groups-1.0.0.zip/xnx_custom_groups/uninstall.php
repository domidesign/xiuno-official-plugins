<?php
!defined('DEBUG') AND exit('Access Denied.');

// ponytail: 卸载时删除插件创建的 3 个用户组
// 注意：gid=3 在 $system_group 白名单内，但 system_group 只控制"后台列表不可删除按钮"
// 直接调用 group_delete() 仍可删除（绕过 UI 限制）
// 为安全起见，只删除本插件创建的 gid，且删除前检查是否还有用户在使用

$gids_to_remove = array(3, 200, 201);

foreach ($gids_to_remove as $gid) {
    $group = group_read($gid);
    if (empty($group)) continue;

    // 安全检查：如果还有用户属于该组，跳过删除（避免用户被孤立）
    $user_count = db_count('user', array('gid' => $gid));
    if ($user_count > 0) {
        // 记录日志，不删除
        xn_log("xnx_custom_groups uninstall: gid={$gid} 仍有 {$user_count} 个用户，跳过删除", 'plugin_uninstall');
        continue;
    }

    // group_delete() 内部会调用 forum_access_padding($gid, FALSE) 清理 forum_access 关联
    group_delete($gid);
}

// 清用户组缓存
group_list_cache_delete();

// 清安装标记
kv_delete('xnx_custom_groups_installed');

?>
