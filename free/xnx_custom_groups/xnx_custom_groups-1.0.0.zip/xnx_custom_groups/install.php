<?php
!defined('DEBUG') AND exit('Access Denied.');

// ponytail: 示例插件 - 创建 3 个自定义 gid 的用户组
// 演示三种典型场景：
//   gid=3   - 占用系统组预留空缺位（install.sql 中 gid=3 未被使用，4 才是版主组）
//   gid=200 - 扩展区间自定义组（避开 101-105 的等级用户组）
//   gid=201 - 扩展区间自定义组
//
// group_create() 内部会自动调用 forum_access_padding($gid, TRUE)
// 因此这些组会自动出现在【后台 - 版块编辑 - 权限矩阵】中
// 同时 bbs_group 表中的所有组都会被 $grouplist 读取
// 因此也会自动出现在【后台 - 用户组编辑 - 核心权限矩阵】和其他插件的权限设置中

$custom_groups = array(
    array(
        'gid'         => 3,
        'name'        => '副版主组',
        'creditsfrom' => 0,
        'creditsto'   => 0,
        'color'       => '#fd7e14',
        'icon'        => 'ti ti-user-shield',
        // 核心权限字段（直接写入 bbs_group 表）
        'allowread'   => 1,
        'allowthread' => 1,
        'allowpost'   => 1,
        'allowattach' => 1,
        'allowdown'   => 1,
        // 管理权限（gid 1-5 才生效，gid=3 命中）
        'allowtop'    => 1,
        'allowupdate' => 1,
        'allowdelete' => 0, // 副版主不能删帖
        'allowmove'   => 1,
        'allowbanuser'=> 0, // 副版主不能封禁用户
    ),
    array(
        'gid'         => 200,
        'name'        => 'VIP 会员组',
        'creditsfrom' => 1000,
        'creditsto'   => 9999,
        'color'       => '#ffc107',
        'icon'        => 'ti ti-crown',
        'allowread'   => 1,
        'allowthread' => 1,
        'allowpost'   => 1,
        'allowattach' => 1,
        'allowdown'   => 1,
    ),
    array(
        'gid'         => 201,
        'name'        => '荣誉会员组',
        'creditsfrom' => 0,
        'creditsto'   => 0,
        'color'       => '#198754',
        'icon'        => 'ti ti-award',
        'allowread'   => 1,
        'allowthread' => 1,
        'allowpost'   => 1,
        'allowattach' => 1,
        'allowdown'   => 1,
    ),
);

foreach ($custom_groups as $g) {
    $exist = group_read($g['gid']);
    if ($exist) {
        // 已存在则只更新基础字段（不覆盖管理员后期调整的权限）
        group_update($g['gid'], array(
            'name'        => $g['name'],
            'creditsfrom' => $g['creditsfrom'],
            'creditsto'   => $g['creditsto'],
            'color'       => $g['color'],
            'icon'        => $g['icon'],
        ));
    } else {
        group_create($g);
    }
}

// 清用户组缓存，让前台立即生效
group_list_cache_delete();

// 记录安装日志
kv_set('xnx_custom_groups_installed', array(
    'gids'    => array(3, 200, 201),
    'version' => '1.0.0',
    'time'    => $time,
));

?>
