// xnx_custom_groups language pack

$lang['xnx_custom_groups_perm_demo_access'] = 'Demo Feature Access';
$lang['xnx_custom_groups_perm_vip_feature'] = 'VIP Exclusive Feature';
