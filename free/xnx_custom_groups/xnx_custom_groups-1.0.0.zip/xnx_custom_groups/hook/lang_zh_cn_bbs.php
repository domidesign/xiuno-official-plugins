// xnx_custom_groups 语言包

$lang['xnx_custom_groups_perm_demo_access'] = '示例功能访问权';
$lang['xnx_custom_groups_perm_vip_feature'] = 'VIP 专属功能';
