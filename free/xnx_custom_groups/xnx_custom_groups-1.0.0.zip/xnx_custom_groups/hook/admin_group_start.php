<?php
// ponytail: 注册本插件的示例权限项
// PermissionService::register() 是运行时静态注册，需要在每次进入用户组管理页时执行
// 注册后，【后台 - 用户组编辑】页的"插件权限"分组会自动显示这些权限项
// 所有用户组（包括本插件创建的 gid=3/200/201）都会显示对应的权限勾选框

if (class_exists('PermissionService', false)) {
    PermissionService::register(
        'xnx_custom_groups',
        'xnx_custom_groups_demo_access',
        lang('xnx_custom_groups_perm_demo_access'),
        'plugin'
    );
    PermissionService::register(
        'xnx_custom_groups',
        'xnx_custom_groups_vip_feature',
        lang('xnx_custom_groups_perm_vip_feature'),
        'plugin'
    );
}
