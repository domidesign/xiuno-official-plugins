// xnx_custom_groups 語言包

$lang['xnx_custom_groups_perm_demo_access'] = '示例功能訪問權';
$lang['xnx_custom_groups_perm_vip_feature'] = 'VIP 專屬功能';
