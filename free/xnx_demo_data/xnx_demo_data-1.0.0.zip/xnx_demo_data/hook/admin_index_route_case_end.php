<?php exit;
// 路由名不能含连字符（xn_url_parse 会按 - 拆分），改用 xnx_demo_data
case 'xnx_demo_data': include APP_PATH.'plugin/xnx_demo_data/route/admin.php'; break;
// setting 页面走标准机制：plugin-setting-xnx_demo_data（在 admin/route/plugin.php 里处理）
