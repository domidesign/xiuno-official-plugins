<?php
!defined('DEBUG') AND exit('Access Denied');

// 仅删除插件配置，不删除已生成的演示数据
setting_delete('xnx_demo_data');
