/**
 * demo_data.js — 演示数据批量导入前端逻辑（原生 JS，禁止 jQuery）
 *
 * 依赖：
 *   - XN.ajax(method, url, data, options)  返回 Promise，resolve {code, message, data}，reject {code, message}
 *   - XN.confirm(message, okCallback, options)  Bootstrap 5 模态确认框
 *   - XN.toast(message, type)  轻提示
 *
 * DOM 约定（admin.htm 提供的 data-* 配置容器 #demo-data-config）：
 *   data-cleanup / data-user-count / data-thread-count / data-reply-count
 *   data-import-url   AJAX 端点 url('plugin-xnx_demo_data')
 *   data-text-*       语言文案（避免在 JS 中硬编码中文）
 */
(function () {
    'use strict';

    var cfgNode = document.getElementById('demo-data-config');
    if (!cfgNode) return;

    var cfg = {
        cleanup: parseInt(cfgNode.dataset.cleanup, 10) || 0,
        userCount: parseInt(cfgNode.dataset.userCount, 10) || 0,
        threadCount: parseInt(cfgNode.dataset.threadCount, 10) || 0,
        replyCount: parseInt(cfgNode.dataset.replyCount, 10) || 0,
        importUrl: cfgNode.dataset.importUrl || '',
        text: {
            cleanup: cfgNode.dataset.textCleanup || '清空数据中...',
            user: cfgNode.dataset.textUser || '生成用户中...',
            thread: cfgNode.dataset.textThread || '生成主题中...',
            reply: cfgNode.dataset.textReply || '生成回复中...',
            done: cfgNode.dataset.textDone || '导入完成',
            confirmCleanup: cfgNode.dataset.textConfirmCleanup || '确定要清空所有演示数据吗？',
            importing: cfgNode.dataset.textImporting || '导入中...',
            start: cfgNode.dataset.textStart || '开始导入'
        }
    };

    var BATCH_SIZE = 100;

    var btnStart = document.getElementById('btn-start-import');
    var progressArea = document.getElementById('progress-area');
    var progressBar = document.getElementById('progress-bar');
    var progressText = document.getElementById('progress-text');
    var stageText = document.getElementById('stage-text');
    var statsArea = document.getElementById('stats-area');
    var errorArea = document.getElementById('error-area');
    var errorMessage = document.getElementById('error-message');

    var statUsers = document.getElementById('stat-users');
    var statThreads = document.getElementById('stat-threads');
    var statReplies = document.getElementById('stat-replies');
    var statElapsed = document.getElementById('stat-elapsed');
    var statSpeed = document.getElementById('stat-speed');

    var startTime = 0;
    var stats = { users: 0, threads: 0, replies: 0 };

    // ========== 启动按钮 ==========

    if (btnStart) {
        btnStart.addEventListener('click', function () {
            if (cfg.cleanup) {
                XN.confirm(cfg.text.confirmCleanup, function () {
                    runImport();
                }, { type: 'danger' });
            } else {
                runImport();
            }
        });
    }

    // ========== 主流程 ==========

    function runImport() {
        startTime = Date.now();
        stats = { users: 0, threads: 0, replies: 0 };

        // 重置 UI
        setButtonLoading(true);
        hideEl(errorArea);
        hideEl(statsArea);
        showEl(progressArea);
        updateStage('cleanup');
        updateProgress('cleanup', 0, 1);

        // L1+L2 修复：先获取锁，再执行各阶段；finally 中释放锁（无论成功失败）
        XN.ajax('POST', cfg.importUrl, { action: 'acquire_lock' })
            .then(function () {
                return runStage('cleanup', 0);
            })
            .then(function () { return runStage('user', 0); })
            .then(function () { return runStage('thread', 0); })
            .then(function () { return runStage('reply', 0); })
            .then(function () { showStats(); })
            .catch(function (err) {
                showError(err);
            })
            .then(function () {
                // finally：无论成功失败都释放锁（ignore release 错误）
                return XN.ajax('POST', cfg.importUrl, { action: 'release_lock' })
                    .catch(function () { /* 锁可能已过期，忽略 */ });
            })
            .then(function () {
                setButtonLoading(false);
            });
    }

    // ========== 单阶段递归（按 BATCH_SIZE 分批） ==========

    function runStage(stage, batchIndex) {
        var total = stageTotal(stage);

        // 跳过条件：cleanup 未启用 / 该阶段总数为 0
        if (stage === 'cleanup' && !cfg.cleanup) return Promise.resolve();
        if (total === 0) return Promise.resolve();

        // 阶段切换时更新文案 + 重置进度
        if (batchIndex === 0) {
            updateStage(stage);
            updateProgress(stage, 0, total);
        }

        return sendBatch(stage, batchIndex).then(function (res) {
            // res = {code:0, message:'', data:{stage, current, total, message, stats}}
            var data = (res && res.data) || {};
            var current = parseInt(data.current, 10) || 0;
            var totalResp = parseInt(data.total, 10) || total;
            updateProgress(stage, current, totalResp);

            if (data.stats) {
                if (typeof data.stats.users !== 'undefined') stats.users = data.stats.users;
                if (typeof data.stats.threads !== 'undefined') stats.threads = data.stats.threads;
                if (typeof data.stats.replies !== 'undefined') stats.replies = data.stats.replies;
            }

            if (current < totalResp) {
                // 继续下一批
                return runStage(stage, batchIndex + 1);
            }
            // 阶段完成，固化统计（避免后端没返回 stats 时缺失）
            if (stage === 'user') stats.users = totalResp;
            else if (stage === 'thread') stats.threads = totalResp;
            else if (stage === 'reply') stats.replies = totalResp;
            return Promise.resolve();
        });
    }

    function sendBatch(stage, batchIndex) {
        return XN.ajax('POST', cfg.importUrl, {
            action: 'run_batch',
            stage: stage,
            batch_index: batchIndex,
            batch_size: BATCH_SIZE
        });
    }

    // ========== 辅助函数 ==========

    function stageTotal(stage) {
        if (stage === 'cleanup') return 1;
        if (stage === 'user') return cfg.userCount;
        if (stage === 'thread') return cfg.threadCount;
        if (stage === 'reply') return cfg.replyCount;
        return 0;
    }

    function updateStage(stage) {
        var text = cfg.text[stage] || cfg.text.importing;
        if (stageText) stageText.textContent = text;
    }

    function updateProgress(stage, current, total) {
        var pct = total > 0 ? Math.min(100, Math.floor((current / total) * 100)) : 0;
        if (progressBar) {
            progressBar.style.width = pct + '%';
            progressBar.setAttribute('aria-valuenow', pct);
        }
        if (progressText) {
            progressText.textContent = current + ' / ' + total + '  (' + pct + '%)';
        }
    }

    function showStats() {
        hideEl(progressArea);
        var elapsedMs = Date.now() - startTime;
        var elapsedSec = elapsedMs / 1000;
        var totalRows = stats.users + stats.threads + stats.replies;
        var speed = elapsedSec > 0 ? (totalRows / elapsedSec).toFixed(2) : '0';

        if (statUsers) statUsers.textContent = stats.users;
        if (statThreads) statThreads.textContent = stats.threads;
        if (statReplies) statReplies.textContent = stats.replies;
        if (statElapsed) statElapsed.textContent = elapsedSec.toFixed(2);
        if (statSpeed) statSpeed.textContent = speed;
        showEl(statsArea);

        updateStage('done');
        if (typeof XN.toast === 'function') {
            XN.toast(cfg.text.done, 'success');
        }
    }

    function showError(err) {
        hideEl(progressArea);
        // Xiuno message() 返回 code 为字符串，前端比较需 parseInt
        var errCode = (err && err.code !== undefined) ? parseInt(err.code, 10) : -1;
        var msg = (err && err.message) ? err.message : ('错误码 ' + (isNaN(errCode) ? 'unknown' : errCode));
        if (errorMessage) errorMessage.textContent = msg;
        showEl(errorArea);
        if (typeof XN.toast === 'function') {
            XN.toast(msg, 'danger');
        }
        // 错误时恢复按钮（导入中断，允许重试）
        setButtonLoading(false);
    }

    // 存储按钮原始子节点，恢复时克隆回去（避免 innerHTML 解析外部文本导致 XSS）
    var btnStartOriginalNodes = [];
    function setButtonLoading(loading) {
        if (!btnStart) return;
        if (loading) {
            btnStart.disabled = true;
            btnStartOriginalNodes = Array.prototype.slice.call(btnStart.childNodes);
            btnStart.replaceChildren();
            var icon = document.createElement('i');
            icon.className = 'ti ti-loader-2 me-1';
            btnStart.appendChild(icon);
            btnStart.appendChild(document.createTextNode(cfg.text.importing));
            btnStart.classList.add('disabled');
        } else {
            btnStart.disabled = false;
            btnStart.replaceChildren();
            if (btnStartOriginalNodes.length) {
                btnStartOriginalNodes.forEach(function(n) {
                    btnStart.appendChild(n.cloneNode(true));
                });
            } else {
                var icon = document.createElement('i');
                icon.className = 'ti ti-player-play-filled me-1';
                btnStart.appendChild(icon);
                btnStart.appendChild(document.createTextNode(cfg.text.start));
            }
            btnStart.classList.remove('disabled');
        }
    }

    function showEl(el) { if (el) el.classList.remove('d-none'); }
    function hideEl(el) { if (el) el.classList.add('d-none'); }
})();
