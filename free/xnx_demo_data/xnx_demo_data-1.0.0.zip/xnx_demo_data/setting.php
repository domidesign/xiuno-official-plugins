<?php
/**
 * XIUNOX 演示数据导入插件 - 后台配置页
 * 通过 admin/?plugin-xnx_demo_data-setting 访问
 */
!defined('DEBUG') AND exit('Access Denied');

// 管理员权限检查（必须）
$gid != 1 && $gid != 2 AND message(-1, lang('xnx_demo_data_no_permission'));

// 处理 POST 保存
if ($method == 'POST') {
    CsrfService::check();

    $forum_ids = param('forum_ids', array());
    if (!is_array($forum_ids)) {
        $forum_ids = array();
    }
    $forum_ids = array_map('intval', $forum_ids);

    // 校验：积分范围
    $credits_min = intval(param('credits_min', 0));
    $credits_max = intval(param('credits_max', 100));
    if ($credits_min > $credits_max) {
        message(-1, lang('xnx_demo_data_credits_range_error'));
    }

    $settings = array(
        'user_count'            => max(0, min(10000, intval(param('user_count', 50)))),
        'thread_count'          => max(0, min(50000, intval(param('thread_count', 200)))),
        'reply_count'           => max(0, min(100000, intval(param('reply_count', 500)))),
        'time_range_days'       => intval(param('time_range_days', 180)),
        'forum_ids'             => $forum_ids,
        'create_preset_forums'  => intval(param('create_preset_forums', 0)),
        'gid'                   => intval(param('gid', 101)),
        'enable_random_credits' => intval(param('enable_random_credits', 1)),
        'credits_min'           => $credits_min,
        'credits_max'           => $credits_max,
        'cleanup_before'        => intval(param('cleanup_before', 0)),
    );

    DemoDataService::saveSettings($settings);
    message(0, lang('xnx_demo_data_save_ok'));
}

// 加载配置与版块列表
$settings = DemoDataService::getSettings();
$forums = DemoDataService::getForumList();

// 引入模板（后台模板需 include header/footer）
include _include(ADMIN_PATH . 'view/htm/header.inc.htm');
include _include(APP_PATH . 'plugin/xnx_demo_data/view/htm/setting.htm');
include _include(ADMIN_PATH . 'view/htm/footer.inc.htm');
