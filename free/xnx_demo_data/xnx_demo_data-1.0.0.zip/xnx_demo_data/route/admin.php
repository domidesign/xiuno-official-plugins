<?php
/**
 * XIUNOX 演示数据导入插件 - 管理页入口 + AJAX 批量执行接口
 * 通过 admin/?xnx_demo_data 访问（路由名不能含连字符，否则被 xn_url_parse 拆分）
 */
!defined('DEBUG') AND exit('Access Denied');

// 管理员权限检查
$gid != 1 && $gid != 2 AND message(-1, lang('xnx_demo_data_no_permission'));

// 独立的锁操作（在 runImport 开始/结束时调用，避免阶段跳过导致锁时机错乱）
// L1+L2 修复：原来锁绑死在 cleanup 获取 / reply 释放，若阶段被跳过则锁永不获取或永不释放
$action = param('action', '');
if ($action == 'acquire_lock') {
    CsrfService::check();
    if (!DemoDataService::acquireLock()) {
        message(-1, lang('xnx_demo_data_lock_busy'));
    }
    message(0, '');
}
if ($action == 'release_lock') {
    CsrfService::check();
    DemoDataService::releaseLock();
    message(0, '');
}

// 处理 AJAX 批量执行
if ($action == 'run_batch') {
    CsrfService::check();

    $stage = param('stage', '');
    $batchIndex = intval(param('batch_index', 0));
    $batchSize = 100; // 固定每批 100 条

    $config = DemoDataService::getSettings();

    // 根据 stage 执行对应批次
    // L1+L2 修复：锁由前端 acquire_lock/release_lock 独立管理，run_batch 不操作锁
    // 前端在 catch/finally 中发 release_lock，确保异常时也能释放
    if ($stage == 'cleanup') {
        $result = DemoDataService::cleanupDemoData();
        if (isset($result['error'])) {
            message(-1, $result['error']);
        }
        message(0, '', array(
            'stage'   => 'cleanup',
            'current' => 1,
            'total'   => 1,
            'stats'   => $result,
        ));
    }

    if ($stage == 'user') {
        $total = intval($config['user_count']);
        $start = $batchIndex * $batchSize;
        $count = min($batchSize, $total - $start);
        if ($count <= 0) {
            message(0, '', array(
                'stage'   => 'user',
                'current' => $total,
                'total'   => $total,
                'stats'   => array('users' => $total),
            ));
        }
        $result = DemoDataService::generateUsers($count, $config);
        if (isset($result['error'])) {
            message(-1, '生成用户第 ' . ($batchIndex + 1) . ' 批失败：' . $result['error']);
        }
        $current = $start + $result['count'];
        message(0, '', array(
            'stage'   => 'user',
            'current' => $current,
            'total'   => $total,
            'stats'   => array('users' => $current),
        ));
    }

    if ($stage == 'thread') {
        $total = intval($config['thread_count']);
        $start = $batchIndex * $batchSize;
        $count = min($batchSize, $total - $start);
        if ($count <= 0) {
            message(0, '', array(
                'stage'   => 'thread',
                'current' => $total,
                'total'   => $total,
                'stats'   => array('threads' => $total),
            ));
        }
        // 获取演示用户 ID 与版块 ID
        $userIds = DemoDataService::getDemoUserIds();
        if (empty($userIds)) {
            message(-1, '没有演示用户，请先生成用户');
        }
        // 版块池：如果开启预设版块，调用 createPresetForums（幂等）后合并
        $forumIds = array();
        if ($config['create_preset_forums']) {
            $preset = DemoDataService::createPresetForums();
            $forumIds = $preset['forumIds'];
        }
        // 合并用户选择的版块
        if (!empty($config['forum_ids'])) {
            $forumIds = array_merge($forumIds, $config['forum_ids']);
        } else {
            // 空表示全选
            $allForums = DemoDataService::getForumList();
            foreach ($allForums as $f) {
                $forumIds[] = $f['fid'];
            }
        }
        $forumIds = array_unique($forumIds);
        if (empty($forumIds)) {
            message(-1, '没有可用版块');
        }

        $result = DemoDataService::generateThreads($count, $config, $userIds, $forumIds);
        if (isset($result['error'])) {
            message(-1, '生成主题第 ' . ($batchIndex + 1) . ' 批失败：' . $result['error']);
        }
        $current = $start + $result['count'];
        message(0, '', array(
            'stage'   => 'thread',
            'current' => $current,
            'total'   => $total,
            'stats'   => array('threads' => $current),
        ));
    }

    if ($stage == 'reply') {
        $total = intval($config['reply_count']);
        $start = $batchIndex * $batchSize;
        $count = min($batchSize, $total - $start);
        if ($count <= 0) {
            message(0, '', array(
                'stage'   => 'reply',
                'current' => $total,
                'total'   => $total,
                'stats'   => array('replies' => $total),
            ));
        }
        $userIds = DemoDataService::getDemoUserIds();
        $threadIds = DemoDataService::getDemoThreadIds();
        if (empty($userIds) || empty($threadIds)) {
            message(-1, '没有演示用户或主题，请先生成');
        }

        $result = DemoDataService::generateReplies($count, $config, $userIds, $threadIds);
        if (isset($result['error'])) {
            message(-1, '生成回复第 ' . ($batchIndex + 1) . ' 批失败：' . $result['error']);
        }
        $current = $start + $result['count'];
        message(0, '', array(
            'stage'   => 'reply',
            'current' => $current,
            'total'   => $total,
            'stats'   => array('replies' => $current),
        ));
    }

    message(-1, '未知的 stage: ' . $stage);
}

// 非 AJAX 请求：渲染管理页
$settings = DemoDataService::getSettings();
$forums = DemoDataService::getForumList();

// 引入模板
include _include(ADMIN_PATH . 'view/htm/header.inc.htm');
include _include(APP_PATH . 'plugin/xnx_demo_data/view/htm/admin.htm');
include _include(ADMIN_PATH . 'view/htm/footer.inc.htm');
