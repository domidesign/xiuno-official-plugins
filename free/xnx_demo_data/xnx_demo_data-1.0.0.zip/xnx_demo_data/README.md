# xnx_demo_data 演示数据导入

## 功能
- 一键批量生成演示用户 / 主题 / 回复，用于新站填充数据或测试性能
- 内置中文姓名 / 标题 / 段落 / 短回复数据池，不依赖外部文件
- 帕累托分布：少数用户产生多数主题/回复，模拟真实社区活跃度
- AJAX 批量执行：每批 100 条，前端串行调用 `run_batch` 接口，实时反馈进度
- 4 个阶段：`cleanup`（清空旧数据）→ `user`（生成用户）→ `thread`（生成主题）→ `reply`（生成回复）
- 并发锁：`acquireLock` / `releaseLock` 防止多标签页/双击重复导入，锁 TTL 10 分钟防僵尸锁；前端在 `catch/finally` 释放锁，异常时也能恢复
- 跨批次缓存：用户 ID 池 / 主题 ID 池 / 主题信息 / 版块列表等通过 `cache_get/cache_set` 共享给后续批次
- 清空数据：按邮箱前缀 `demo_` 标识识别演示数据，安全清理（不删除真实用户）；清理后重建版块统计计数
- 配置项：用户数（≤10000）/ 主题数（≤50000）/ 回复数（≤100000）/ 时间范围（30/90/180/365 天）/ 版块白名单 / 是否创建预设版块 / 用户组（101/102）/ 随机积分范围 / 导入前是否清空
- 安全：每个用户独立 16 位随机密码，不写入日志；管理员权限（gid=1/2）限制

## 文件结构
```
plugin/xnx_demo_data/
├── conf.json
├── install.php / uninstall.php
├── setting.php              (后台配置页 POST 处理)
├── model/DemoDataService.php
├── route/admin.php          (后台入口 + AJAX 批量接口 acquire_lock/release_lock/run_batch)
├── hook/
│   ├── model_inc_file.php
│   ├── admin_index_route_case_end.php
│   ├── lang_zh_cn_bbs.php
│   ├── lang_zh_tw_bbs.php
│   └── lang_en_us_bbs.php
├── view/htm/
│   ├── setting.htm          (配置表单)
│   └── admin.htm            (执行面板 + 进度条)
├── static/
│   ├── css/demo_data.css
│   └── js/demo_data.js      (AJAX 批量调度 + 进度反馈)
```

## 配置流程
1. 后台启用插件（写入默认配置：50 用户 / 200 主题 / 500 回复 / 180 天范围）
2. 进入「插件设置」配置数量上限、时间范围、版块白名单、是否创建预设版块、用户组、积分范围、是否清空旧数据
3. 切换到「执行面板」点击「开始导入」→ 前端依次执行 cleanup → user → thread → reply 四阶段，每阶段分批 100 条
4. 测试：导入完成后访问前台首页查看新用户/主题；后台用户列表筛选 `demo_` 前缀邮箱查看演示用户；点击「清空数据」可一键还原
