<?php
!defined('DEBUG') AND exit('Access Denied');

// 写入默认配置到 bbs_setting（setting_set 原生支持数组，无需 JSON 中转）
setting_set('xnx_demo_data', [
    'user_count' => 50,
    'thread_count' => 200,
    'reply_count' => 500,
    'time_range_days' => 180,
    'forum_ids' => [],  // 空数组表示全选
    'create_preset_forums' => 0,
    'gid' => 101,
    'enable_random_credits' => 1,
    'credits_min' => 0,
    'credits_max' => 100,
    'cleanup_before' => 0,
]);
