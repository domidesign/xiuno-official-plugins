<?php
!defined('DEBUG') AND exit('Access Denied');

/**
 * XIUNOX 演示数据生成服务
 *
 * 功能：
 * - 批量生成演示用户 / 主题 / 回复（帕累托分布）
 * - 内置中文姓名 / 标题 / 段落 / 短回复数据池，不依赖外部文件
 * - 清空演示数据（按 email 前缀 demo_ 标识）并重建版块计数器
 * - 并发锁防止重复导入
 *
 * 标识约定：
 * - 邮箱格式：demo_{uid}@example.com
 * - 默认密码：每个用户独立 16 位随机密码（不写入日志，避免明文泄露）
 *
 * 注意：
 * - user_create 不处理密码哈希，调用方必须自行 password_hash() 后写入 password_hash 字段
 * - thread_create 第二参数是引用 (&$pid)，键名用 time / longip
 * - post_create 需要额外 $fid / $gid 参数，键名用 create_date / userip
 * - thread_create 不写 views 字段，需事后 db_update 单独设置
 */
class DemoDataService {

	const LOCK_KEY = 'xnx_demo_data_lock';
	const LOCK_TTL = 600; // 锁过期 10 分钟，防止僵尸锁

	// P2-P5 修复：跨批次缓存（cache_get/cache_set），避免同一轮导入的批次间重复查询
	// AJAX 批次是独立 PHP 请求，静态变量无法跨请求复用，必须用共享缓存
	// 缓存 key 约定：xnx_demo_data_{type}，TTL = LOCK_TTL
	// 写后失效：generateUsers 末尾清 demouids；generateThreads 末尾清 demotids + threadsinfo
	private static $cacheKeys = array(
		'demo_user_ids'   => 'xnx_demo_data_demouids',
		'demo_thread_ids' => 'xnx_demo_data_demotids',
		'preset_forums'   => 'xnx_demo_data_presetforums',
		'forum_list'      => 'xnx_demo_data_forumlist',
		'user_reg_dates'  => 'xnx_demo_data_userregdates',
		'threads_info'    => 'xnx_demo_data_threadsinfo',
	);

	// ==================== 配置读写 ====================

	/**
	 * 读取插件配置，不存在时返回与 install.php 一致的默认值
	 */
	public static function getSettings() {
		$settings = setting_get('xnx_demo_data');
		if(empty($settings)) {
			$settings = array(
				'user_count' => 50,
				'thread_count' => 200,
				'reply_count' => 500,
				'time_range_days' => 180,
				'forum_ids' => array(),
				'create_preset_forums' => 0,
				'gid' => 101,
				'enable_random_credits' => 1,
				'credits_min' => 0,
				'credits_max' => 100,
				'cleanup_before' => 0,
			);
		}
		return $settings;
	}

	/**
	 * 保存插件配置（强制类型转换 + 白名单校验）
	 */
	public static function saveSettings($arr) {
		// time_range_days 白名单
		$allowedRanges = array(30, 90, 180, 365);
		$timeRange = intval(isset($arr['time_range_days']) ? $arr['time_range_days'] : 180);
		if(!in_array($timeRange, $allowedRanges, true)) {
			$timeRange = 180;
		}

		// gid 白名单（仅普通用户和版主）
		$allowedGids = array(101, 102);
		$gid = intval(isset($arr['gid']) ? $arr['gid'] : 101);
		if(!in_array($gid, $allowedGids, true)) {
			$gid = 101;
		}

		$settings = array(
			'user_count' => max(0, min(10000, intval(isset($arr['user_count']) ? $arr['user_count'] : 50))),
			'thread_count' => max(0, min(50000, intval(isset($arr['thread_count']) ? $arr['thread_count'] : 200))),
			'reply_count' => max(0, min(100000, intval(isset($arr['reply_count']) ? $arr['reply_count'] : 500))),
			'time_range_days' => $timeRange,
			'forum_ids' => isset($arr['forum_ids']) ? array_map('intval', (array)$arr['forum_ids']) : array(),
			'create_preset_forums' => intval(isset($arr['create_preset_forums']) ? $arr['create_preset_forums'] : 0),
			'gid' => $gid,
			'enable_random_credits' => intval(isset($arr['enable_random_credits']) ? $arr['enable_random_credits'] : 1),
			'credits_min' => intval(isset($arr['credits_min']) ? $arr['credits_min'] : 0),
			'credits_max' => intval(isset($arr['credits_max']) ? $arr['credits_max'] : 100),
			'cleanup_before' => intval(isset($arr['cleanup_before']) ? $arr['cleanup_before'] : 0),
		);
		setting_set('xnx_demo_data', $settings);
		return $settings;
	}

	// ==================== 并发锁 ====================

	/**
	 * 尝试获取导入锁（防止多标签页/双击重复导入）
	 *
	 * @return bool true=获取成功可执行，false=已有任务在执行
	 */
	public static function acquireLock() {
		$existing = cache_get(self::LOCK_KEY);
		if($existing !== null && $existing !== false) {
			return false;
		}
		cache_set(self::LOCK_KEY, time(), self::LOCK_TTL);
		return true;
	}

	/**
	 * 释放导入锁，并清理所有跨批次缓存
	 */
	public static function releaseLock() {
		cache_delete(self::LOCK_KEY);
		// P2-P5: 清理导入期间的所有缓存，防止下次导入读到旧数据
		foreach(self::$cacheKeys as $key) {
			cache_delete($key);
		}
	}

	// ==================== 数据生成 ====================

	/**
	 * 批量生成演示用户
	 *
	 * @param int $count 本次生成的数量
	 * @param array $config 配置数组（gid / time_range_days / enable_random_credits / credits_min / credits_max）
	 * @return array array('count'=>N, 'userIds'=>array(), 'error'=>string|null)
	 */
	public static function generateUsers($count, $config) {
		$pools = self::getDataPools();
		$now = time();
		$range = intval($config['time_range_days']) * 86400;
		$gid = intval($config['gid']);
		$enableCredits = intval($config['enable_random_credits']);
		$creditsMin = intval($config['credits_min']);
		$creditsMax = intval($config['credits_max']);
		$longip = ip2long('127.0.0.1');
		$userIds = array();
		$created = 0;

		// 预取所有已存在的用户名做内存集合（避免循环内 N+1 查询去重）
		// ponytail: 演示场景用户量不会太大，50000 上限足够；超大规模需改为布隆过滤器
		$existingUsernames = array();
		$allUsers = db_find('user', array(), array(), 1, 50000, 'username');
		foreach($allUsers as $u) {
			$existingUsernames[$u['username']] = 1;
		}

		// P1 修复：演示用户密码用统一 bcrypt 哈希（每用户独立密码无业务价值）
		// 演示账户本就不应被真实登录，统一密码既满足 password_hash 字段非空约束，
		// 又将 100 用户的哈希开销从 5-10 秒降到 ~100ms（仅哈希 1 次）
		// ponytail: 已知限制——所有演示用户密码相同，可被字典爆破，但演示数据无敏感价值
		$demoPasswordHash = password_hash(self::randomPassword(16), PASSWORD_DEFAULT);

		db_exec('BEGIN'); // 保留 db_exec（事务控制，无用户输入）
		try {
			for($i = 0; $i < $count; $i++) {
				// 用户名生成 + 去重（内存集合，O(1) 查找）
				$username = self::randomUsername($pools);
				$suffix = 0;
				while(isset($existingUsernames[$username])) {
					$suffix++;
					$username = self::randomUsername($pools) . $suffix;
				}
				$existingUsernames[$username] = 1;

				// 注册时间分布：越接近当前时间密度越高（sqrt 曲线模拟增长）
				$ratio = 1 - sqrt(mt_rand(0, 10000) / 10000); // 0~1，越接近1越靠后
				$createDate = $now - intval($range * (1 - $ratio));

				// 积分
				$credits = 0;
				if($enableCredits) {
					$credits = mt_rand($creditsMin, $creditsMax);
				}

				// 邮箱占位（user_create 后用 lastInsertId 更新为标准格式）
				$email = 'demo_pending_' . uniqid() . '@example.com';

				$uid = user_create(array(
					'gid' => $gid,
					'email' => $email,
					'username' => $username,
					'nickname' => $username,
					'password' => '',
					'salt' => '',
					'password_hash' => $demoPasswordHash, // P1: 循环外预计算，循环内复用
					'create_ip' => $longip,
					'create_date' => $createDate,
					'login_ip' => $longip,
					'login_date' => $createDate,
					'logins' => mt_rand(1, 50),
					'credits' => $credits,
					'avatar' => 0, // 保持系统默认头像
					'signature' => '',
				));

				if(!$uid) {
					throw new Exception("user_create failed at iteration $i");
				}

				// 更新邮箱为标准格式 demo_{uid}@example.com
				$realEmail = 'demo_' . $uid . '@example.com';
				db_update('user', array('uid' => $uid), array('email' => $realEmail));

				$userIds[] = $uid;
				$created++;
			}
			db_exec('COMMIT'); // 保留 db_exec（事务控制，无用户输入）
		} catch(Exception $e) {
			db_exec('ROLLBACK'); // 保留 db_exec（事务控制，无用户输入）
			return array('count' => 0, 'userIds' => array(), 'error' => $e->getMessage());
		}

		// P5: user 阶段每批新增用户，使 demouids / userregdates 缓存失效
		cache_delete(self::$cacheKeys['demo_user_ids']);
		cache_delete(self::$cacheKeys['user_reg_dates']);

		return array('count' => $created, 'userIds' => $userIds);
	}

	/**
	 * 批量生成演示主题
	 *
	 * @param int $count 本次生成的数量
	 * @param array $config 配置数组（time_range_days）
	 * @param array $userIds 演示用户 uid 列表
	 * @param array $forumIds 目标版块 fid 列表
	 * @return array array('count'=>N, 'threadIds'=>array(), 'error'=>string|null)
	 */
	public static function generateThreads($count, $config, $userIds, $forumIds) {
		if(empty($userIds) || empty($forumIds)) {
			return array('count' => 0, 'threadIds' => array(), 'error' => '用户或版块为空');
		}
		$pools = self::getDataPools();
		$now = time();
		$range = intval($config['time_range_days']) * 86400;
		$longip = ip2long('127.0.0.1');
		$threadIds = array();
		$created = 0;

		// 预取用户注册时间（避免循环内查库 N+1）
		// P3 修复：跨批次缓存，thread 阶段每批的 $userIds 相同
		$userRegDates = cache_get(self::$cacheKeys['user_reg_dates']);
		if($userRegDates === null || $userRegDates === false) {
			$userRegDates = array();
			$users = db_find('user', array('uid' => $userIds), array(), 1, count($userIds), 'uid');
			foreach($users as $u) {
				$userRegDates[$u['uid']] = $u['create_date'];
			}
			cache_set(self::$cacheKeys['user_reg_dates'], $userRegDates, self::LOCK_TTL);
		}

		db_exec('BEGIN'); // 保留 db_exec（事务控制，无用户输入）
		try {
			for($i = 0; $i < $count; $i++) {
				$uid = $userIds[array_rand($userIds)];
				$fid = $forumIds[array_rand($forumIds)];
				$subject = $pools['titles'][array_rand($pools['titles'])];
				// 标题去重：随机追加数字后缀
				if(mt_rand(0, 1)) {
					$subject .= '（' . mt_rand(1, 999) . '）';
				}
				$message = self::randomContent($pools);

				// 发布时间：晚于作者注册时间
				$userRegDate = isset($userRegDates[$uid]) ? $userRegDates[$uid] : ($now - $range);
				$minTime = max($userRegDate, $now - $range);
				$time = mt_rand($minTime, $now);

				$pid = 0; // thread_create 第二参数是引用
				$tid = thread_create(array(
					'fid' => $fid,
					'uid' => $uid,
					'subject' => $subject,
					'message' => $message,
					'time' => $time,
					'longip' => $longip,
					'doctype' => 0, // html
					'audit_status' => 1,
				), $pid);

				if(!$tid) {
					throw new Exception("thread_create failed at iteration $i");
				}

				// 设置随机 views（thread_create 不写 views 字段，默认为 0）
				$views = mt_rand(0, 500);
				db_update('thread', array('tid' => $tid), array('views' => $views));

				$threadIds[] = $tid;
				$created++;
			}
			db_exec('COMMIT'); // 保留 db_exec（事务控制，无用户输入）
		} catch(Exception $e) {
			db_exec('ROLLBACK'); // 保留 db_exec（事务控制，无用户输入）
			return array('count' => 0, 'threadIds' => array(), 'error' => $e->getMessage());
		}

		// P5: thread 阶段每批新增主题，使 demotids / threadsinfo 缓存失效
		cache_delete(self::$cacheKeys['demo_thread_ids']);
		cache_delete(self::$cacheKeys['threads_info']);

		return array('count' => $created, 'threadIds' => $threadIds);
	}

	/**
	 * 批量生成演示回复（帕累托分布：20% 主题获得 80% 回复）
	 *
	 * @param int $count 本次生成的数量
	 * @param array $config 配置数组（gid）
	 * @param array $userIds 演示用户 uid 列表
	 * @param array $threadIds 目标主题 tid 列表
	 * @return array array('count'=>N, 'error'=>string|null)
	 */
	public static function generateReplies($count, $config, $userIds, $threadIds) {
		if(empty($userIds) || empty($threadIds)) {
			return array('count' => 0, 'error' => '用户或主题为空');
		}
		$pools = self::getDataPools();
		$now = time();
		$longip = ip2long('127.0.0.1');
		$gid = intval($config['gid']);
		$created = 0;

		// 预取主题信息（fid, create_date）避免循环内 N+1 查询
		// P4 修复：跨批次缓存，reply 阶段每批的 $threadIds 相同
		$threadsInfo = cache_get(self::$cacheKeys['threads_info']);
		if($threadsInfo === null || $threadsInfo === false) {
			$threadsInfo = db_find('thread', array('tid' => $threadIds), array(), 1, count($threadIds), 'tid');
			cache_set(self::$cacheKeys['threads_info'], $threadsInfo, self::LOCK_TTL);
		}

		// 帕累托分布：前 20% 主题权重 4，其余权重 1
		$hotCount = max(1, intval(count($threadIds) * 0.2));
		$threadCount = count($threadIds);

		db_exec('BEGIN'); // 保留 db_exec（事务控制，无用户输入）
		try {
			for($i = 0; $i < $count; $i++) {
				$uid = $userIds[array_rand($userIds)];
				// 加权随机选 tid（不构造大数组，O(n) 内完成）
				$tid = self::weightedRandomPick($threadIds, $hotCount, $threadCount);
				$message = self::randomReply($pools);

				$threadInfo = isset($threadsInfo[$tid]) ? $threadsInfo[$tid] : null;
				if(!$threadInfo) {
					throw new Exception("thread $tid not found");
				}
				$fid = $threadInfo['fid'];
				$threadTime = $threadInfo['create_date'];
				$replyTime = mt_rand($threadTime, $now);

			// ponytail: skip_attach_assoc=true 跳过附件关联——批量生成演示数据时
			// 当前 session 可能含有管理员自己上传的 tmp_files，不跳过会被关联到随机生成的演示回复上
			$pid = post_create(array(
				'tid' => $tid,
				'uid' => $uid,
				'isfirst' => 0,
				'create_date' => $replyTime,
				'userip' => $longip,
				'message' => $message,
				'doctype' => 0,
				'audit_status' => 1,
				'quotepid' => 0,
			), $fid, $gid, array('skip_attach_assoc' => true));

				if(!$pid) {
					throw new Exception("post_create failed at iteration $i");
				}
				$created++;
			}
			db_exec('COMMIT'); // 保留 db_exec（事务控制，无用户输入）
		} catch(Exception $e) {
			db_exec('ROLLBACK'); // 保留 db_exec（事务控制，无用户输入）
			return array('count' => 0, 'error' => $e->getMessage());
		}

		return array('count' => $created);
	}

	// ==================== 清空与辅助 ====================

	/**
	 * 清空所有演示数据
	 *
	 * 删除顺序：回复 → 主题首帖 → 主题 → mythread → 用户，最后重建版块计数器
	 * 同时修正 runtime 全站统计
	 *
	 * @return array array('users'=>N, 'threads'=>N, 'replies'=>N, 'error'=>string|null)
	 */
	public static function cleanupDemoData() {
		global $db;
		// 保留 db_sql_find：LIKE 前缀匹配 demo_ 邮箱（db_find 的 LIKE 会两端加 %，无法精确前缀匹配）
		$demoUsers = db_sql_find("SELECT uid FROM " . $db->tablepre . "user WHERE email LIKE 'demo_%@example.com'");

		if(empty($demoUsers)) {
			return array('users' => 0, 'threads' => 0, 'replies' => 0);
		}

		$uids = array();
		foreach($demoUsers as $u) {
			$uids[] = $u['uid'];
		}

		// 查找这些用户创建的主题
		$threads = db_find('thread', array('uid' => $uids), array(), 1, 10000, 'tid');
		$tids = array_keys($threads);

		// 统计受影响的版块
		$affectedFids = array();
		foreach($threads as $t) {
			$affectedFids[$t['fid']] = 1;
		}

		// 统计实际会删除的回复数（演示用户发的回复 ∪ 演示用户主题下的所有回复）
		// L3 修复：原来用 $replyCountOwn + $replyCountInThread 会重复计算「演示用户在自己主题下的回复」
		// 改用 SQL OR 条件一次查询，自动去重
		// 保留 db_sql_find：db_count 不支持 OR 条件组合
		$uidList = implode(',', array_map('intval', $uids));
		$tidList = !empty($tids) ? implode(',', array_map('intval', $tids)) : '0';
		$totalRepliesToDelete = db_sql_find_one(
			"SELECT COUNT(*) AS c FROM " . $db->tablepre . "post " .
			"WHERE isfirst=0 AND (uid IN($uidList) OR tid IN($tidList))"
		);
		$totalRepliesToDelete = $totalRepliesToDelete ? intval($totalRepliesToDelete['c']) : 0;
		$threadCount = count($tids);

		db_exec('BEGIN'); // 保留 db_exec（事务控制，无用户输入）
		try {
			// 1. 删除演示用户的所有回复（按 uid，包括别人主题下的回复）
			db_delete('post', array('uid' => $uids, 'isfirst' => 0));
			// 2. 删除演示用户主题下的所有回复（其他人发的）
			if(!empty($tids)) {
				db_delete('post', array('tid' => $tids, 'isfirst' => 0));
			}
			// 3. 删除演示用户的所有主题（连同首帖）
			if(!empty($tids)) {
				db_delete('post', array('tid' => $tids, 'isfirst' => 1));
				db_delete('thread', array('tid' => $tids));
				db_delete('mythread', array('tid' => $tids));
			}
			// 4. 删除演示用户账号
			db_delete('user', array('uid' => $uids));

			db_exec('COMMIT'); // 保留 db_exec（事务控制，无用户输入）
		} catch(Exception $e) {
			db_exec('ROLLBACK'); // 保留 db_exec（事务控制，无用户输入）
			return array('error' => $e->getMessage());
		}

		// 修正 runtime 全站统计（user_create 时自动 +1，删除时需反向 -N）
		runtime_set('users-', count($uids));
		// threads/posts 计数由 forum_update 间接维护，runtime 不单独统计

		// 重建受影响版块的计数器（绝对值重算）
		foreach($affectedFids as $fid => $_) {
			self::rebuildForumStats($fid);
		}

		// P2-P5: cleanup 删除了用户/主题，清理所有跨批次缓存
		foreach(self::$cacheKeys as $key) {
			cache_delete($key);
		}

		return array(
			'users' => count($uids),
			'threads' => $threadCount,
			'replies' => $totalRepliesToDelete,
		);
	}

	/**
	 * 创建预设版块（公告/讨论/资源/灌水/问答），已存在则跳过
	 * P5 修复：跨批次缓存结果，避免每批重复 5 次 db_find_one
	 *
	 * @return array array('forumIds'=>array())
	 */
	public static function createPresetForums() {
		// P5: 跨批次缓存（thread 阶段每批都调，幂等）
		$cached = cache_get(self::$cacheKeys['preset_forums']);
		if($cached !== null && $cached !== false) {
			return $cached;
		}

		$presetNames = array('公告', '讨论', '资源', '灌水', '问答');
		$forumIds = array();
		$now = time();

		foreach($presetNames as $name) {
			// 检查是否已存在同名版块
			$existing = db_find_one('forum', array('name' => $name), array(), array('fid'));
			if($existing) {
				$forumIds[] = $existing['fid'];
				continue;
			}
			// 创建新版块
			$fid = forum_create(array(
				'name' => $name,
				'rank' => 100,
				'fup' => 0,
				'type' => 0,
				'brief' => '',
				'announcement' => '',
				'accesson' => 0,
				'orderby' => 0,
				'create_date' => $now,
				'icon' => '',
				'moduids' => '',
				'seo_title' => '',
				'seo_keywords' => '',
			));
			if($fid) {
				$forumIds[] = $fid;
			}
		}

		$result = array('forumIds' => $forumIds);
		cache_set(self::$cacheKeys['preset_forums'], $result, self::LOCK_TTL);
		return $result;
	}

	/**
	 * 获取所有演示用户 uid（按 email 前缀 demo_ 标识）
	 * P5 修复：跨批次缓存，thread/reply 阶段每批都调
	 * 注意：user 阶段每批新增用户会调用 cache_delete 使缓存失效
	 */
	public static function getDemoUserIds() {
		global $db;
		// P5: 跨批次缓存
		$cached = cache_get(self::$cacheKeys['demo_user_ids']);
		if($cached !== null && $cached !== false) {
			return $cached;
		}

		// 保留 db_sql_find：LIKE 前缀匹配（db_find 的 LIKE 会两端加 %）
		$users = db_sql_find("SELECT uid FROM " . $db->tablepre . "user WHERE email LIKE 'demo_%@example.com' ORDER BY uid");
		$ids = array();
		if(!empty($users)) {
			foreach($users as $u) {
				$ids[] = $u['uid'];
			}
		}
		cache_set(self::$cacheKeys['demo_user_ids'], $ids, self::LOCK_TTL);
		return $ids;
	}

	/**
	 * 获取所有演示用户创建的主题 tid
	 * P5 修复：跨批次缓存，reply 阶段每批都调
	 * 注意：thread 阶段每批新增主题会调用 cache_delete 使缓存失效
	 */
	public static function getDemoThreadIds() {
		// P5: 跨批次缓存
		$cached = cache_get(self::$cacheKeys['demo_thread_ids']);
		if($cached !== null && $cached !== false) {
			return $cached;
		}

		$demoUserIds = self::getDemoUserIds();
		if(empty($demoUserIds)) {
			return array();
		}
		$threads = db_find('thread', array('uid' => $demoUserIds), array('tid' => 1), 1, 10000, 'tid');
		$ids = array_keys($threads);
		cache_set(self::$cacheKeys['demo_thread_ids'], $ids, self::LOCK_TTL);
		return $ids;
	}

	/**
	 * 获取版块列表（顶级版块，按 rank 倒序）
	 * P5 修复：跨批次缓存（thread 阶段 forum_ids 为空时每批调）
	 */
	public static function getForumList() {
		// P5: 跨批次缓存
		$cached = cache_get(self::$cacheKeys['forum_list']);
		if($cached !== null && $cached !== false) {
			return $cached;
		}

		$list = db_find('forum', array('type' => 0), array('rank' => -1), 1, 100, 'fid');
		cache_set(self::$cacheKeys['forum_list'], $list, self::LOCK_TTL);
		return $list;
	}

	// ==================== 私有：数据池与工具方法 ====================

	/**
	 * 内置数据池（不依赖外部文件）
	 */
	private static function getDataPools() {
		return array(
			'surnames' => array(
				'李','王','张','刘','陈','杨','赵','黄','周','吴',
				'徐','孙','胡','朱','高','林','何','郭','马','罗',
				'梁','宋','郑','谢','韩','唐','冯','于','董','萧',
				'程','曹','袁','邓','许','傅','沈','曾','彭','吕',
				'苏','卢','蒋','蔡','贾','丁','魏','薛','叶','阎',
				'余','潘','杜','戴','夏','钟','汪','田','任','姜',
			), // 60 个姓氏
			'given_names' => array(
				'伟','芳','娜','秀英','敏','静','丽','强','磊','军',
				'洋','勇','艳','杰','娟','涛','明','超','秀兰','霞',
				'平','刚','桂英','玉兰','萍','鹏','华','建国','建华','建军',
				'志强','志明','志华','小红','小明','小华','小芳','小燕','小静','小兰',
				'浩然','子轩','梓涵','欣怡','佳怡','思远','雨涵','诗涵','梓萱','睿',
				'宇轩','浩宇','俊熙','皓轩','弘文','博文','博文','懿轩','煜城','懿轩',
				'梦琪','忆香','映波','访枫','含玉','笑寒','谷蓝','惜海','凌旋','曼凝',
				'初瑶','冷安','醉香','若菱','代曼','幻枫','寻绿','向南','初珍','傲菡',
			), // 80 名字
			'titles' => array(
				'【公告】社区规则更新通知',
				'【公告】新版块上线啦',
				'【公告】系统维护通知',
				'【讨论】大家觉得这个功能怎么样？',
				'【讨论】最近版本的更新体验',
				'【讨论】技术选型的几个建议',
				'【讨论】新手入门该选哪个框架',
				'【分享】推荐一个好用的开发工具',
				'【分享】开源了一个小项目',
				'【分享】今天踩到一个坑，分享给大家',
				'【分享】性能优化的几个实践',
				'【分享】学习笔记整理',
				'【资源】全套视频教程分享',
				'【资源】电子书下载合集',
				'【资源】开发者必备工具清单',
				'【资源】开源项目推荐',
				'【灌水】今天心情不错',
				'【灌水】周末去哪玩',
				'【灌水】给大家讲个笑话',
				'【灌水】最近看的剧推荐',
				'【问答】这个错误怎么解决？',
				'【问答】如何配置伪静态？',
				'【问答】数据库连接失败求助',
				'【问答】怎么部署到生产环境？',
				'【教程】从零搭建开发环境',
				'【教程】手把手教你写插件',
				'【教程】前后端分离实践',
				'【教程】Docker 部署指南',
				'【原创】我的技术成长之路',
				'【原创】写了一个小轮子',
				'【转载】10x 程序员的习惯',
				'【转载】如何写出优雅的代码',
				'【活动】线上 meetup 报名',
				'【活动】编程大赛开始啦',
				'【求助】服务器配置建议',
				'【求助】选 mac 还是 windows？',
				'【建议】希望增加暗黑模式',
				'【建议】能否优化下移动端体验',
				'【反馈】发现一个 bug',
				'【反馈】这个功能有点问题',
				'闲来无事，大家都在干嘛？',
				'记录一下今天的踩坑日常',
				'新手上路，请多关照',
				'终于搞定了一个困扰已久的问题',
				'今天学到了一招，分享给大家',
				'代码重构的一些心得',
				'关于架构设计的几点思考',
				'面试遇到的一个有趣问题',
				'聊聊我们团队的技术栈',
				'年终总结：这一年我学到了什么',
			), // 50+ 标题
			'paragraphs' => array(
				'在开发过程中，我们经常会遇到各种各样的问题。有些问题看似简单，但实际解决起来却需要深入理解底层原理。今天就跟大家分享一下我最近遇到的一个典型案例。',
				'关于性能优化，我认为最重要的不是盲目使用各种技巧，而是要先找到瓶颈所在。只有对症下药，才能事半功倍。常见的性能瓶颈包括数据库查询、网络 IO、算法复杂度等。',
				'最近在做一个项目，用到了不少新技术。整体体验下来，感觉开发效率提升了不少，但也踩了一些坑。这里简单总结一下，希望对大家有所帮助。',
				'代码规范是一个老生常谈的话题。好的代码不仅要能运行，更要易于维护和扩展。命名清晰、结构合理、注释到位，这些看似细节的地方，往往决定了代码的质量。',
				'学习编程最重要的就是动手实践。看书、看视频虽然重要，但只有真正写代码，才能深刻理解其中的原理。建议从一个小项目开始，逐步积累经验。',
				'架构设计没有银弹，不同的业务场景需要不同的解决方案。不要盲目追求新技术，也不要固守旧方案。适合自己的才是最好的。',
				'团队协作中，沟通比技术更重要。再厉害的开发者，如果不能与团队成员有效沟通，也很难做出好的产品。文档、会议、代码评审都是沟通的重要方式。',
				'关于代码审查，我认为这是一项非常有价值的实践。通过 review 别人的代码，可以学到很多新的思路和技巧；通过被 review，可以发现自己忽略的问题。',
				'调试是每个程序员都绕不开的环节。掌握好的调试技巧，可以大大提高开发效率。断点、日志、单步执行，这些基本功都要扎实。',
				'前端技术的发展真是日新月异。从 jQuery 到 Vue、React，从传统页面到单页应用，每一次技术革新都带来了开发模式的变革。',
				'后端开发中，数据库设计是非常关键的一环。合理的表结构、索引设计，能够大幅提升系统性能。切忌过度设计，也不要为了性能而牺牲可读性。',
				'测试是保证代码质量的重要手段。单元测试、集成测试、端到端测试，各有侧重。不要因为赶进度而忽视测试，那往往会得不偿失。',
				'部署运维这块，容器化已经是标配了。Docker + Kubernetes 的组合，让应用的部署、扩容、回滚都变得简单。但也增加了学习成本。',
				'安全性是任何系统都不能忽视的问题。SQL 注入、XSS、CSRF，这些常见的攻击手段都要做好防护。输入验证、输出转义、权限控制，缺一不可。',
				'关于缓存，最忌讳的就是缓存不一致。读写策略、过期时间、缓存穿透、缓存雪崩，这些问题都要提前考虑好应对方案。',
				'微服务架构这几年很火，但并不是所有场景都适合。小团队、简单业务，单体架构反而更合适。不要为了微服务而微服务。',
				'开源精神是程序员最宝贵的品质之一。分享代码、贡献社区，不仅帮助了别人，也能提升自己。读优秀的开源项目源码，是学习的捷径。',
				'技术博客是个好东西。坚持写博客，可以梳理思路、沉淀知识、建立个人品牌。不需要写得多高深，记录日常的踩坑和心得就很好。',
				'关于时间管理，程序员要学会区分重要和紧急。不要整天忙于救火，而忽略了真正重要的事情，比如学习新技术、优化系统架构、写文档。',
				'代码重构是持续的过程。不要等到代码烂得无法维护了才重构，而要在每次改动时顺手优化。小步重构，快速验证，才能降低风险。',
			), // 20+ 段落
			'short_replies' => array(
				'支持一下！','学习了，感谢分享','沙发！','板凳','地板也不错',
				'好文，mark 一下','楼主辛苦了','涨知识了','收藏了','正好需要这个',
				'感谢楼主','说得很对','深有同感','哈哈，有意思','这个坑我也踩过',
				'学习了','学到了','受教了','感谢','点赞',
				'期待更多分享','催更催更','楼主加油','关注了','已三连',
				'求楼主联系方式','有 demo 吗','这个怎么用','看起来不错','试试看',
			), // 30 条短回复
		);
	}

	/**
	 * 生成随机中文姓名
	 */
	private static function randomUsername($pools) {
		$surname = $pools['surnames'][array_rand($pools['surnames'])];
		$given = $pools['given_names'][array_rand($pools['given_names'])];
		return $surname . $given;
	}

	/**
	 * 生成随机密码（字母+数字，排除易混淆字符）
	 *
	 * @param int $length 密码长度
	 * @return string 随机密码
	 */
	private static function randomPassword($length = 16) {
		$chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
		$len = strlen($chars) - 1;
		$str = '';
		for($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $len)];
		}
		return $str;
	}

	/**
	 * 生成随机主题内容（3~8 段，HTML 段落标签包裹）
	 */
	private static function randomContent($pools) {
		$paraCount = mt_rand(3, 8);
		$content = '';
		$indices = array_rand($pools['paragraphs'], $paraCount);
		// array_rand 第二参数为 1 时返回单键而非数组，统一为数组
		if(!is_array($indices)) {
			$indices = array($indices);
		}
		foreach($indices as $idx) {
			$content .= '<p>' . $pools['paragraphs'][$idx] . '</p>';
		}
		return $content;
	}

	/**
	 * 生成随机回复内容（60% 短回复，40% 长回复）
	 */
	private static function randomReply($pools) {
		if(mt_rand(0, 9) < 6) {
			return $pools['short_replies'][array_rand($pools['short_replies'])];
		}
		return self::randomContent($pools);
	}

	/**
	 * 加权随机选取 tid（帕累托分布，不构造大数组）
	 *
	 * 前 hotCount 个主题权重 4，其余权重 1
	 * 总权重 = hotCount * 4 + (total - hotCount) * 1
	 * 随机数落在哪个区间就选哪个
	 *
	 * @param array $threadIds 主题 tid 列表
	 * @param int $hotCount 热门主题数（前 N 个权重 4）
	 * @param int $total 总主题数
	 * @return int 选中的 tid
	 */
	private static function weightedRandomPick($threadIds, $hotCount, $total) {
		$totalWeight = $hotCount * 4 + ($total - $hotCount) * 1;
		$r = mt_rand(1, $totalWeight);
		$accum = 0;
		foreach($threadIds as $idx => $tid) {
			$weight = ($idx < $hotCount) ? 4 : 1;
			$accum += $weight;
			if($r <= $accum) {
				return $tid;
			}
		}
		return $threadIds[count($threadIds) - 1]; // 兜底
	}

	/**
	 * 重建版块统计计数器（绝对值重算）
	 *
	 * forum 表字段：threads / todaythreads / todayposts
	 *
	 * @param int $fid 版块 id
	 */
	private static function rebuildForumStats($fid) {
		// threads：该版块下未删除主题数
		$threadCount = db_count('thread', array('fid' => $fid, 'is_deleted' => 0));

		// todaythreads：今天创建的主题数
		$todayStart = strtotime(date('Y-m-d'));
		$todayThreads = db_count('thread', array(
			'fid' => $fid,
			'create_date' => array('>=' => $todayStart),
			'is_deleted' => 0,
		));

		// todayposts：今天创建的回复数（post 表无 is_deleted 字段，按 isfirst=0 计数）
		// ponytail: 简化处理，置 0；今日发帖计数本就每日凌晨由计划任务清零
		$todayPosts = 0;

		forum_update($fid, array(
			'threads' => $threadCount,
			'todaythreads' => $todayThreads,
			'todayposts' => $todayPosts,
		));
	}

}
