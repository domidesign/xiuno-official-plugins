<?php
!defined('DEBUG') AND exit('Access Denied.');
global $db;
$tablepre = $db->tablepre;

// 首版预留结构，后续数据库变更在此添加幂等迁移逻辑
// 示例（取消注释后使用）：
// $cols = db_sql_find("SHOW COLUMNS FROM " . $tablepre . "xnx_avatar_frame");
// $has_new_field = false;
// if ($cols) {
//     foreach ($cols as $col) {
//         if ($col['Field'] == 'new_field') $has_new_field = true;
//     }
// }
// if (!$has_new_field) {
//     db_exec("ALTER TABLE " . $tablepre . "xnx_avatar_frame ADD COLUMN new_field varchar(255) NOT NULL DEFAULT '' AFTER name");
// }

// 结构变更后需递增 conf.json.version，并清 tmp/ 编译缓存
