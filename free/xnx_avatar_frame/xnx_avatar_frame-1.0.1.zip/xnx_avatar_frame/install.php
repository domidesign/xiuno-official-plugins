<?php
!defined('DEBUG') AND exit('Access Denied.');
global $db;
$tablepre = $db->tablepre;

// 头像框定义表（utf8mb4 支持 emoji）
db_exec("CREATE TABLE IF NOT EXISTS " . $tablepre . "xnx_avatar_frame (
    id int unsigned NOT NULL AUTO_INCREMENT,
    name varchar(64) NOT NULL DEFAULT '',
    description varchar(255) NOT NULL DEFAULT '',
    frame_type tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=图片 1=CSS',
    frame_image varchar(255) NOT NULL DEFAULT '' COMMENT '图片框URL',
    frame_css text NOT NULL COMMENT 'CSS框样式',
    price_type varchar(16) NOT NULL DEFAULT 'credits' COMMENT 'credits/golds',
    price_value int NOT NULL DEFAULT 0,
    duration_days int NOT NULL DEFAULT 0 COMMENT '0=永久',
    allowed_gids varchar(255) NOT NULL DEFAULT '' COMMENT '白名单gid逗号分隔，空=所有组',
    sort int NOT NULL DEFAULT 0,
    enabled tinyint(1) NOT NULL DEFAULT 1,
    create_time int unsigned NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY sort (sort),
    KEY enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 用户拥有+佩戴表（utf8mb4）
db_exec("CREATE TABLE IF NOT EXISTS " . $tablepre . "xnx_avatar_frame_own (
    id int unsigned NOT NULL AUTO_INCREMENT,
    uid int unsigned NOT NULL DEFAULT 0,
    frame_id int unsigned NOT NULL DEFAULT 0,
    source varchar(16) NOT NULL DEFAULT 'buy' COMMENT 'buy/gift/admin',
    cost_type varchar(16) NOT NULL DEFAULT '',
    cost_value int NOT NULL DEFAULT 0,
    buy_time int unsigned NOT NULL DEFAULT 0,
    expire_time int unsigned NOT NULL DEFAULT 0 COMMENT '0=永久',
    is_wearing tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uid_frame (uid, frame_id),
    KEY uid (uid),
    KEY uid_wearing (uid, is_wearing),
    KEY expire_time (expire_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 日志表（utf8mb4）
db_exec("CREATE TABLE IF NOT EXISTS " . $tablepre . "xnx_avatar_frame_log (
    id int unsigned NOT NULL AUTO_INCREMENT,
    uid int unsigned NOT NULL DEFAULT 0,
    frame_id int unsigned NOT NULL DEFAULT 0,
    frame_name varchar(64) NOT NULL DEFAULT '' COMMENT '冗余记录',
    action varchar(16) NOT NULL DEFAULT 'buy' COMMENT 'buy/wear/unwear/expire',
    cost_type varchar(16) NOT NULL DEFAULT '',
    cost_value int NOT NULL DEFAULT 0,
    create_time int unsigned NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY uid (uid),
    KEY frame_id (frame_id),
    KEY action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 创建头像框图片上传目录（幂等）
$_avatar_frame_upload_dir = APP_PATH . 'upload/avatar_frame/';
if (!is_dir($_avatar_frame_upload_dir)) {
    mkdir($_avatar_frame_upload_dir, 0755, true);
}

// 初始化默认配置
setting_set('xnx_avatar_frame', array('enabled' => 1));
