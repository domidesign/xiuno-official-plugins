<?php
!defined('DEBUG') AND exit('Access Denied');

// 权限检查：仅管理员组（gid=1,2）可访问
$gid != 1 && $gid != 2 AND message(-1, '无权限');

// FrameService 已通过 model_inc_file.php hook 自动加载
$tab = param(3, 'list');

// POST 操作统一处理
if ($method == 'POST') {
    CsrfService::check();
    $do = param('do', '');

    if ($do == 'create') {
        $allowed_gids = param('allowed_gids', array());
        if (!is_array($allowed_gids)) {
            $allowed_gids = array();
        }
        $allowed_gids = array_filter(array_map('intval', $allowed_gids), function($v) { return $v > 0; });
        $frame_css = param('frame_css', '');
        // 防御性检查：禁止包含 PHP 标签字符（frame_css 仅作为内联 style 输出，理论上不会进入 PHP 解析，仍做兜底过滤）
        // 注意：字符串拼接构造避免 PHP tokenizer 误识别
        $php_open = '<' . '?php';
        $php_short = '<' . '?';
        $php_short_eq = '<' . '?=';
        $php_close = '?' . '>';
        $frame_css = str_replace(array($php_close, $php_open, $php_short_eq, $php_short), '', $frame_css);
        $data = array(
            'name'           => trim(param('name', '')),
            'description'    => trim(param('description', '')),
            'frame_type'     => intval(param('frame_type', 0)),
            'frame_image'    => trim(param('frame_image', '')),
            'frame_css'      => $frame_css,
            'price_type'     => param('price_type', 'credits') === 'golds' ? 'golds' : 'credits',
            'price_value'    => intval(param('price_value', 0)),
            'duration_days'  => intval(param('duration_days', 0)),
            'allowed_gids'   => implode(',', $allowed_gids),
            'sort'           => intval(param('sort', 0)),
            'enabled'        => intval(param('enabled', 0)) ? 1 : 0,
            'create_time'    => time(),
        );
        if (empty($data['name'])) {
            message(-1, lang('xnx_avatar_frame_admin_name') . ' 不能为空');
        }
        $r = FrameService::createFrame($data);
        if (empty($r['ok'])) {
            message(-1, $r['message']);
        }
        message(0, lang('xnx_avatar_frame_save_success'));

    } elseif ($do == 'edit') {
        $id = intval(param('id', 0));
        if ($id <= 0) {
            message(-1, '参数错误');
        }
        $allowed_gids = param('allowed_gids', array());
        if (!is_array($allowed_gids)) {
            $allowed_gids = array();
        }
        $allowed_gids = array_filter(array_map('intval', $allowed_gids), function($v) { return $v > 0; });
        $frame_css = param('frame_css', '');
        $php_open = '<' . '?php';
        $php_short = '<' . '?';
        $php_short_eq = '<' . '?=';
        $php_close = '?' . '>';
        $frame_css = str_replace(array($php_close, $php_open, $php_short_eq, $php_short), '', $frame_css);
        $data = array(
            'name'           => trim(param('name', '')),
            'description'    => trim(param('description', '')),
            'frame_type'     => intval(param('frame_type', 0)),
            'frame_image'    => trim(param('frame_image', '')),
            'frame_css'      => $frame_css,
            'price_type'     => param('price_type', 'credits') === 'golds' ? 'golds' : 'credits',
            'price_value'    => intval(param('price_value', 0)),
            'duration_days'  => intval(param('duration_days', 0)),
            'allowed_gids'   => implode(',', $allowed_gids),
            'sort'           => intval(param('sort', 0)),
            'enabled'        => intval(param('enabled', 0)) ? 1 : 0,
        );
        if (empty($data['name'])) {
            message(-1, lang('xnx_avatar_frame_admin_name') . ' 不能为空');
        }
        $ok = FrameService::updateFrame($id, $data);
        if (!$ok) {
            message(-1, '更新失败');
        }
        message(0, lang('xnx_avatar_frame_save_success'));

    } elseif ($do == 'delete') {
        $id = intval(param('id', 0));
        if ($id <= 0) {
            message(-1, '参数错误');
        }
        FrameService::deleteFrame($id);
        message(0, lang('xnx_avatar_frame_save_success'));

    } elseif ($do == 'upload_image') {
        // 头像框图片上传（参考 xnx_medal upload_icon 模式）
        if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            message(-1, lang('xnx_avatar_frame_upload_fail'));
        }
        $file = $_FILES['file'];
        $allowed_exts = array('jpg', 'jpeg', 'png', 'gif', 'webp');
        $max_size = 2 * 1024 * 1024; // 2MB

        if ($file['size'] > $max_size) {
            message(-1, '图片文件大小不能超过 2MB');
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed_exts)) {
            message(-1, '图片仅支持 jpg/png/gif/webp 格式');
        }

        // 真实 MIME 校验
        $img_mimes = array('image/jpeg', 'image/pjpeg', 'image/png', 'image/gif', 'image/webp');
        if (!class_exists('AttachmentService')) {
            include APP_PATH . 'service/AttachmentService.php';
        }
        if (!AttachmentService::verifyUploadMime($file['tmp_name'], $img_mimes, true)) {
            message(-1, lang('file_mime_not_allowed'));
        }

        $upload_dir = APP_PATH . 'upload/avatar_frame/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $filename = 'frame_' . date('Ymd_His') . '_' . substr(md5(uniqid('', true)), 0, 8) . '.' . $ext;
        $save_path = $upload_dir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $save_path)) {
            message(-1, lang('xnx_avatar_frame_upload_fail'));
        }
        // 返回绝对路径 URL，避免后台相对路径被浏览器解析为 /admin/upload/...
        $url = '/upload/avatar_frame/' . $filename;
        message(0, lang('xnx_avatar_frame_upload_success'), array('url' => $url));

    } elseif ($do == 'save_settings') {
        $enabled = intval(param('enabled', 0)) ? 1 : 0;
        $settings = array('enabled' => $enabled);
        FrameService::saveSettings($settings);
        message(0, lang('xnx_avatar_frame_save_success'));
    }

    message(-1, '未知操作');
}

// ============ GET 页面展示 ============
$page = param(4, 1);
$pagesize = 20;
$groups = group_list_cache(); // 用于白名单多选

// 各 tab 的数据准备（只加载当前 tab 的数据以减少开销）
$frames_list = array('list' => array(), 'count' => 0, 'pagination' => '');
$log_list = array('list' => array(), 'count' => 0, 'pagination' => '');
$wear_list = array('list' => array(), 'count' => 0, 'pagination' => '');
$settings = array('enabled' => 1);

if ($tab == 'list') {
    $result = FrameService::getAllFrames($page, $pagesize, false);
    $frames_list['list'] = $result['list'];
    $frames_list['count'] = $result['count'];
    $frames_list['pagination'] = pagination(url("plugin-setting-xnx_avatar_frame-list-{page}"), $frames_list['count'], $page, $pagesize);
} elseif ($tab == 'log') {
    // JOIN user 表取用户名、JOIN frame 表取头像框名称
    global $db;
    $tablepre = $db->tablepre;
    $offset = max(0, ($page - 1) * $pagesize);
    // 保留 db_sql_find：JOIN 查询日志表，db_find 不支持 JOIN
    $sql = "SELECT l.id, l.uid, l.frame_id, l.frame_name, l.action, l.cost_type, l.cost_value, l.create_time"
         . " FROM `" . $tablepre . "xnx_avatar_frame_log` l"
         . " ORDER BY l.id DESC"
         . " LIMIT " . $offset . "," . $pagesize;
    $log_list['list'] = db_sql_find($sql);
    if (!is_array($log_list['list'])) $log_list['list'] = array();
    $log_list['count'] = db_count('xnx_avatar_frame_log', array());
    $log_list['pagination'] = pagination(url("plugin-setting-xnx_avatar_frame-log-{page}"), $log_list['count'], $page, $pagesize);
    // 批量获取用户信息
    if (!empty($log_list['list'])) {
        $uids = array_unique(array_filter(array_map('intval', array_column($log_list['list'], 'uid'))));
        $users_map = !empty($uids) ? user_find_by_uids(implode(',', $uids)) : array();
        foreach ($log_list['list'] as &$_row) {
            $_uid = intval($_row['uid']);
            $_row['username'] = isset($users_map[$_uid]) ? ($users_map[$_uid]['display_name'] ?? $users_map[$_uid]['username']) : '';
        }
        unset($_row);
    }
} elseif ($tab == 'wear') {
    // JOIN user + frame 表取佩戴中的记录
    global $db;
    $tablepre = $db->tablepre;
    $offset = max(0, ($page - 1) * $pagesize);
    // 保留 db_sql_find：JOIN 查询佩戴记录+头像框详情，db_find 不支持 JOIN
    $sql = "SELECT o.id, o.uid, o.frame_id, o.buy_time, o.expire_time, o.is_wearing,"
         . " f.name AS frame_name, f.frame_type, f.frame_image"
         . " FROM `" . $tablepre . "xnx_avatar_frame_own` o"
         . " LEFT JOIN `" . $tablepre . "xnx_avatar_frame` f ON o.frame_id = f.id"
         . " WHERE o.is_wearing = 1"
         . " ORDER BY o.buy_time DESC"
         . " LIMIT " . $offset . "," . $pagesize;
    $wear_list['list'] = db_sql_find($sql);
    if (!is_array($wear_list['list'])) $wear_list['list'] = array();
    // 佩戴中的总数
    $wear_list['count'] = db_count('xnx_avatar_frame_own', array('is_wearing' => 1));
    $wear_list['pagination'] = pagination(url("plugin-setting-xnx_avatar_frame-wear-{page}"), $wear_list['count'], $page, $pagesize);
    // 批量获取用户信息
    if (!empty($wear_list['list'])) {
        $uids = array_unique(array_filter(array_map('intval', array_column($wear_list['list'], 'uid'))));
        $users_map = !empty($uids) ? user_find_by_uids(implode(',', $uids)) : array();
        foreach ($wear_list['list'] as &$_row) {
            $_uid = intval($_row['uid']);
            $_row['username'] = isset($users_map[$_uid]) ? ($users_map[$_uid]['display_name'] ?? $users_map[$_uid]['username']) : '';
        }
        unset($_row);
    }
} elseif ($tab == 'settings') {
    $settings = FrameService::getSettings();
}

include _include(APP_PATH . 'plugin/xnx_avatar_frame/view/htm/setting.htm');
