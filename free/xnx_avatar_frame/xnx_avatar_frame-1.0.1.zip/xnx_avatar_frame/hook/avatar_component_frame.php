<?php
// xnx_avatar_frame 头像框渲染 hook
// 注入到 L1 avatar-wrap 内、L2 头像本体之后（覆盖模式 $data['frame_html'] = ...）
// 注意：hook 文件禁止 return（会从 plugin_hook 宿主返回），用 if 包裹整个逻辑
//
// 跳过 xs 尺寸（24px）：头像框在如此小的头像上无法辨识，反而影响视觉
// 跳过 uid=0：调用方未传 _uid 时无法定位用户佩戴记录，避免无效查询

$_frame_uid = isset($data['uid']) ? intval($data['uid']) : 0;
$_frame_size = isset($data['size']) ? $data['size'] : 'md';
if ($_frame_uid > 0 && $_frame_size !== 'xs') {
	// class_exists 守卫（FrameService 通过 model_inc_file.php 自动加载，但守卫更安全）
	if (class_exists('FrameService', false)) {
		// getWearingFrame 有静态缓存 $userWearCache，避免帖子列表页 N+1
		$_wearing_frame = FrameService::getWearingFrame($_frame_uid);
		if (!empty($_wearing_frame)) {
			$_frame_html = FrameService::renderFrameHtml($_wearing_frame, $_frame_size);
			if ($_frame_html !== '') {
				$data['frame_html'] = $_frame_html;
			}
		}
	}
}
