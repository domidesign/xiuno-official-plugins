<?php
// 头像框插件前台路由注册
// 注意：Xiuno URL 解析器按 '-' 拆分（explode('-', $front)），
//   'frame-shop' → $route='frame', param(1)='shop'
//   'frame-my'   → $route='frame', param(1)='my'
// 因此 case 必须是 'frame'，在分发器中用 param(1) 区分子操作
$routes['frame_shop']      = 'frame-shop';        // 商店
$routes['frame_shop_page'] = 'frame-shop-{page}'; // 商店分页
$routes['my_frame']        = 'frame-my';          // 我的头像框
