<?php
// xnx_avatar_frame language pack - English

// General
$lang['xnx_avatar_frame_name'] = 'Avatar Frame';
$lang['xnx_avatar_frame_brief'] = 'Avatar Frame Shop, Purchase & Wear Management';
$lang['xnx_avatar_frame_shop'] = 'Avatar Frame Shop';
$lang['xnx_avatar_frame_my'] = 'My Avatar Frames';
$lang['xnx_avatar_frame_buy'] = 'Buy';
$lang['xnx_avatar_frame_owned'] = 'Owned';
$lang['xnx_avatar_frame_wear'] = 'Wear';
$lang['xnx_avatar_frame_unwear'] = 'Unwear';
$lang['xnx_avatar_frame_wearing'] = 'Wearing';
$lang['xnx_avatar_frame_expired'] = 'Expired';
$lang['xnx_avatar_frame_not_allowed'] = 'Not Available';
$lang['xnx_avatar_frame_permanent'] = 'Permanent';
$lang['xnx_avatar_frame_days'] = 'days';

// Action messages
$lang['xnx_avatar_frame_buy_success'] = 'Purchase successful';
$lang['xnx_avatar_frame_buy_fail'] = 'Purchase failed';
$lang['xnx_avatar_frame_wear_success'] = 'Worn successfully';
$lang['xnx_avatar_frame_unwear_success'] = 'Unworn successfully';
$lang['xnx_avatar_frame_insufficient_credits'] = 'Insufficient credits';
$lang['xnx_avatar_frame_already_owned'] = 'You already own this frame';
$lang['xnx_avatar_frame_not_owned'] = 'You do not own this frame';
$lang['xnx_avatar_frame_expired_wearing'] = 'This frame has expired';
$lang['xnx_avatar_frame_save_success'] = 'Saved successfully';
$lang['xnx_avatar_frame_upload_success'] = 'Upload successful';
$lang['xnx_avatar_frame_upload_fail'] = 'Upload failed';

// Admin
$lang['xnx_avatar_frame_admin_list'] = 'Frame List';
$lang['xnx_avatar_frame_admin_log'] = 'Purchase Log';
$lang['xnx_avatar_frame_admin_wear'] = 'Wear Log';
$lang['xnx_avatar_frame_admin_settings'] = 'Global Settings';
$lang['xnx_avatar_frame_admin_create'] = 'Create Frame';
$lang['xnx_avatar_frame_admin_edit'] = 'Edit Frame';
$lang['xnx_avatar_frame_admin_delete'] = 'Delete';
$lang['xnx_avatar_frame_admin_name'] = 'Name';
$lang['xnx_avatar_frame_admin_description'] = 'Description';
$lang['xnx_avatar_frame_admin_frame_type'] = 'Type';
$lang['xnx_avatar_frame_admin_frame_type_image'] = 'Image Frame';
$lang['xnx_avatar_frame_admin_frame_type_css'] = 'CSS Frame';
$lang['xnx_avatar_frame_admin_frame_image'] = 'Image';
$lang['xnx_avatar_frame_admin_frame_css'] = 'CSS Style';
$lang['xnx_avatar_frame_admin_price'] = 'Price';
$lang['xnx_avatar_frame_admin_price_type'] = 'Payment Method';
$lang['xnx_avatar_frame_admin_duration'] = 'Duration (days, 0=permanent)';
$lang['xnx_avatar_frame_admin_allowed_gids'] = 'Allowed Groups (none=all groups)';
$lang['xnx_avatar_frame_admin_sort'] = 'Sort';
$lang['xnx_avatar_frame_admin_enabled'] = 'Enabled';
$lang['xnx_avatar_frame_admin_preview'] = 'Preview';
$lang['xnx_avatar_frame_admin_upload_image'] = 'Upload Image';
$lang['xnx_avatar_frame_admin_user'] = 'User';
$lang['xnx_avatar_frame_admin_action'] = 'Action';
$lang['xnx_avatar_frame_admin_time'] = 'Time';
$lang['xnx_avatar_frame_admin_cost'] = 'Cost';
$lang['xnx_avatar_frame_admin_expire_time'] = 'Expire Time';
$lang['xnx_avatar_frame_admin_wear_time'] = 'Wear Time';

// Price types
$lang['xnx_avatar_frame_price_credits'] = 'Credits';
$lang['xnx_avatar_frame_price_golds'] = 'Golds';

// Other
$lang['xnx_avatar_frame_remaining_days'] = '%d days remaining';
$lang['xnx_avatar_frame_no_data'] = 'No data';
$lang['xnx_avatar_frame_confirm_delete'] = 'Confirm delete this frame?';
$lang['xnx_avatar_frame_nav_my'] = 'My Avatar Frames';
