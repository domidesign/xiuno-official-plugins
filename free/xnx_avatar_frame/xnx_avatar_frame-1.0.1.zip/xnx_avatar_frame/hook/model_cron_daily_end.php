<?php
// hook: model_cron_daily_end.php
// 每日清理过期的头像框佩戴
if (class_exists('FrameService', false)) {
	FrameService::cleanExpired();
}
