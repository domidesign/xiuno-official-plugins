<?php
// xnx_avatar_frame 语言包 - 简体中文

// 通用
$lang['xnx_avatar_frame_name'] = '头像框';
$lang['xnx_avatar_frame_brief'] = '头像框商店、购买、佩戴管理';
$lang['xnx_avatar_frame_shop'] = '头像框商店';
$lang['xnx_avatar_frame_my'] = '我的头像框';
$lang['xnx_avatar_frame_buy'] = '购买';
$lang['xnx_avatar_frame_owned'] = '已拥有';
$lang['xnx_avatar_frame_wear'] = '佩戴';
$lang['xnx_avatar_frame_unwear'] = '取消佩戴';
$lang['xnx_avatar_frame_wearing'] = '佩戴中';
$lang['xnx_avatar_frame_expired'] = '已过期';
$lang['xnx_avatar_frame_not_allowed'] = '不可购买';
$lang['xnx_avatar_frame_permanent'] = '永久';
$lang['xnx_avatar_frame_days'] = '天';

// 操作提示
$lang['xnx_avatar_frame_buy_success'] = '购买成功';
$lang['xnx_avatar_frame_buy_fail'] = '购买失败';
$lang['xnx_avatar_frame_wear_success'] = '佩戴成功';
$lang['xnx_avatar_frame_unwear_success'] = '已取消佩戴';
$lang['xnx_avatar_frame_insufficient_credits'] = '积分不足';
$lang['xnx_avatar_frame_already_owned'] = '您已拥有该头像框';
$lang['xnx_avatar_frame_not_owned'] = '您未拥有该头像框';
$lang['xnx_avatar_frame_expired_wearing'] = '头像框已过期';
$lang['xnx_avatar_frame_save_success'] = '保存成功';
$lang['xnx_avatar_frame_upload_success'] = '上传成功';
$lang['xnx_avatar_frame_upload_fail'] = '上传失败';

// 后台管理
$lang['xnx_avatar_frame_admin_list'] = '头像框列表';
$lang['xnx_avatar_frame_admin_log'] = '购买记录';
$lang['xnx_avatar_frame_admin_wear'] = '佩戴记录';
$lang['xnx_avatar_frame_admin_settings'] = '全局设置';
$lang['xnx_avatar_frame_admin_create'] = '新建头像框';
$lang['xnx_avatar_frame_admin_edit'] = '编辑头像框';
$lang['xnx_avatar_frame_admin_delete'] = '删除';
$lang['xnx_avatar_frame_admin_name'] = '名称';
$lang['xnx_avatar_frame_admin_description'] = '描述';
$lang['xnx_avatar_frame_admin_frame_type'] = '类型';
$lang['xnx_avatar_frame_admin_frame_type_image'] = '图片框';
$lang['xnx_avatar_frame_admin_frame_type_css'] = 'CSS 框';
$lang['xnx_avatar_frame_admin_frame_image'] = '图片';
$lang['xnx_avatar_frame_admin_frame_css'] = 'CSS 样式';
$lang['xnx_avatar_frame_admin_price'] = '价格';
$lang['xnx_avatar_frame_admin_price_type'] = '支付方式';
$lang['xnx_avatar_frame_admin_duration'] = '有效期（天，0=永久）';
$lang['xnx_avatar_frame_admin_allowed_gids'] = '允许购买的用户组（不选=所有组）';
$lang['xnx_avatar_frame_admin_sort'] = '排序';
$lang['xnx_avatar_frame_admin_enabled'] = '上架';
$lang['xnx_avatar_frame_admin_preview'] = '预览';
$lang['xnx_avatar_frame_admin_upload_image'] = '上传图片';
$lang['xnx_avatar_frame_admin_user'] = '用户';
$lang['xnx_avatar_frame_admin_action'] = '操作';
$lang['xnx_avatar_frame_admin_time'] = '时间';
$lang['xnx_avatar_frame_admin_cost'] = '花费';
$lang['xnx_avatar_frame_admin_expire_time'] = '过期时间';
$lang['xnx_avatar_frame_admin_wear_time'] = '佩戴时间';

// 价格类型
$lang['xnx_avatar_frame_price_credits'] = '积分';
$lang['xnx_avatar_frame_price_golds'] = '金币';

// 其他
$lang['xnx_avatar_frame_remaining_days'] = '剩余 %d 天';
$lang['xnx_avatar_frame_no_data'] = '暂无数据';
$lang['xnx_avatar_frame_confirm_delete'] = '确认删除该头像框？';
$lang['xnx_avatar_frame_nav_my'] = '我的头像框';
