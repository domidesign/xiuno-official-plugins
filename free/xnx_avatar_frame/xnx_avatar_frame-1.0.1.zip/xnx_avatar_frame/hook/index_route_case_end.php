<?php exit;
// 头像框插件前台路由分发
// Xiuno URL 解析器按 '-' 拆分：
//   frame-shop.htm       → $route='frame', param(1)='shop'
//   frame-shop-2.htm     → $route='frame', param(1)='shop', param(2)='2'
//   frame-my.htm         → $route='frame', param(1)='my'
// 因此 case 必须是 'frame'，内部用 param(1) 分发到对应文件
case 'frame':
	$_frame_action = param(1);
	if ($_frame_action == 'shop') {
		include APP_PATH.'plugin/xnx_avatar_frame/route/frame_shop.php';
	} elseif ($_frame_action == 'my') {
		include APP_PATH.'plugin/xnx_avatar_frame/route/my_frame.php';
	}
	break;
