<?php exit;
APP_PATH.'plugin/xnx_avatar_frame/model/FrameService.php',
