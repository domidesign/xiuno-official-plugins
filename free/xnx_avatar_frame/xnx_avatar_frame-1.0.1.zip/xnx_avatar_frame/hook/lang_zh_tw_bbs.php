<?php
// xnx_avatar_frame 語言包 - 繁體中文

// 通用
$lang['xnx_avatar_frame_name'] = '頭像框';
$lang['xnx_avatar_frame_brief'] = '頭像框商店、購買、佩戴管理';
$lang['xnx_avatar_frame_shop'] = '頭像框商店';
$lang['xnx_avatar_frame_my'] = '我的頭像框';
$lang['xnx_avatar_frame_buy'] = '購買';
$lang['xnx_avatar_frame_owned'] = '已擁有';
$lang['xnx_avatar_frame_wear'] = '佩戴';
$lang['xnx_avatar_frame_unwear'] = '取消佩戴';
$lang['xnx_avatar_frame_wearing'] = '佩戴中';
$lang['xnx_avatar_frame_expired'] = '已過期';
$lang['xnx_avatar_frame_not_allowed'] = '不可購買';
$lang['xnx_avatar_frame_permanent'] = '永久';
$lang['xnx_avatar_frame_days'] = '天';

// 操作提示
$lang['xnx_avatar_frame_buy_success'] = '購買成功';
$lang['xnx_avatar_frame_buy_fail'] = '購買失敗';
$lang['xnx_avatar_frame_wear_success'] = '佩戴成功';
$lang['xnx_avatar_frame_unwear_success'] = '已取消佩戴';
$lang['xnx_avatar_frame_insufficient_credits'] = '積分不足';
$lang['xnx_avatar_frame_already_owned'] = '您已擁有該頭像框';
$lang['xnx_avatar_frame_not_owned'] = '您未擁有該頭像框';
$lang['xnx_avatar_frame_expired_wearing'] = '頭像框已過期';
$lang['xnx_avatar_frame_save_success'] = '儲存成功';
$lang['xnx_avatar_frame_upload_success'] = '上傳成功';
$lang['xnx_avatar_frame_upload_fail'] = '上傳失敗';

// 後台管理
$lang['xnx_avatar_frame_admin_list'] = '頭像框列表';
$lang['xnx_avatar_frame_admin_log'] = '購買記錄';
$lang['xnx_avatar_frame_admin_wear'] = '佩戴記錄';
$lang['xnx_avatar_frame_admin_settings'] = '全域設定';
$lang['xnx_avatar_frame_admin_create'] = '新建頭像框';
$lang['xnx_avatar_frame_admin_edit'] = '編輯頭像框';
$lang['xnx_avatar_frame_admin_delete'] = '刪除';
$lang['xnx_avatar_frame_admin_name'] = '名稱';
$lang['xnx_avatar_frame_admin_description'] = '描述';
$lang['xnx_avatar_frame_admin_frame_type'] = '類型';
$lang['xnx_avatar_frame_admin_frame_type_image'] = '圖片框';
$lang['xnx_avatar_frame_admin_frame_type_css'] = 'CSS 框';
$lang['xnx_avatar_frame_admin_frame_image'] = '圖片';
$lang['xnx_avatar_frame_admin_frame_css'] = 'CSS 樣式';
$lang['xnx_avatar_frame_admin_price'] = '價格';
$lang['xnx_avatar_frame_admin_price_type'] = '支付方式';
$lang['xnx_avatar_frame_admin_duration'] = '有效期（天，0=永久）';
$lang['xnx_avatar_frame_admin_allowed_gids'] = '允許購買的用戶組（不選=所有組）';
$lang['xnx_avatar_frame_admin_sort'] = '排序';
$lang['xnx_avatar_frame_admin_enabled'] = '上架';
$lang['xnx_avatar_frame_admin_preview'] = '預覽';
$lang['xnx_avatar_frame_admin_upload_image'] = '上傳圖片';
$lang['xnx_avatar_frame_admin_user'] = '用戶';
$lang['xnx_avatar_frame_admin_action'] = '操作';
$lang['xnx_avatar_frame_admin_time'] = '時間';
$lang['xnx_avatar_frame_admin_cost'] = '花費';
$lang['xnx_avatar_frame_admin_expire_time'] = '過期時間';
$lang['xnx_avatar_frame_admin_wear_time'] = '佩戴時間';

// 價格類型
$lang['xnx_avatar_frame_price_credits'] = '積分';
$lang['xnx_avatar_frame_price_golds'] = '金幣';

// 其他
$lang['xnx_avatar_frame_remaining_days'] = '剩餘 %d 天';
$lang['xnx_avatar_frame_no_data'] = '暫無資料';
$lang['xnx_avatar_frame_confirm_delete'] = '確認刪除該頭像框？';
$lang['xnx_avatar_frame_nav_my'] = '我的頭像框';
