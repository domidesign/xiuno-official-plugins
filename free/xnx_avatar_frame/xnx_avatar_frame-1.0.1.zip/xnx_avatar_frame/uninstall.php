<?php
!defined('DEBUG') AND exit('Access Denied.');
global $db;
$tablepre = $db->tablepre;

// 删除插件数据表
db_exec("DROP TABLE IF EXISTS " . $tablepre . "xnx_avatar_frame");
db_exec("DROP TABLE IF EXISTS " . $tablepre . "xnx_avatar_frame_own");
db_exec("DROP TABLE IF EXISTS " . $tablepre . "xnx_avatar_frame_log");

// 清理插件配置
setting_delete('xnx_avatar_frame');
kv_delete('xnx_avatar_frame');

// 不删除 upload/avatar_frame/ 目录，保留用户上传的文件
