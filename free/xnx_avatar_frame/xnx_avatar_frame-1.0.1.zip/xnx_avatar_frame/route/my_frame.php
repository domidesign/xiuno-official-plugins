<?php
!defined('DEBUG') AND exit('Access Denied');

/**
 * 我的头像框路由
 * URL: frame-my
 * 由 index_route_case_end.php 的 case 'frame': 分发（param(1)='my'）
 */

// 登录检查
user_login_check();

// ===================== POST 操作 =====================
if ($method == 'POST') {
	CsrfService::check();
	$do = param('do', '');
	$frame_id = intval(param('frame_id', 0));

	if ($do == 'buy') {
		$result = FrameService::buyFrame($uid, $frame_id);
		message($result['ok'] ? 0 : -1, $result['message']);
	} elseif ($do == 'wear') {
		$result = FrameService::wearFrame($uid, $frame_id);
		message($result['ok'] ? 0 : -1, $result['message']);
	} elseif ($do == 'unwear') {
		$result = FrameService::unwearFrame($uid);
		message($result['ok'] ? 0 : -1, $result['message']);
	}
	message(-1, '无效操作');
}

// ===================== GET 页面 =====================
$owned = FrameService::getOwnedFrames($uid);

// 当前佩戴的 frame_id
$wearing_id = 0;
foreach ($owned as $o) {
	if (!empty($o['is_wearing'])) {
		$wearing_id = intval($o['frame_id']);
	}
}

$header['title'] = lang('xnx_avatar_frame_my');
$active_tab = 'frame';

include _include(APP_PATH . 'view/htm/header.inc.htm');
include _include(APP_PATH . 'plugin/xnx_avatar_frame/view/htm/my_frame.htm');
include _include(APP_PATH . 'view/htm/footer.inc.htm');
