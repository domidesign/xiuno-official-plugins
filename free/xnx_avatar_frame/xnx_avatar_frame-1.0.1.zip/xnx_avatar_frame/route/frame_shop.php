<?php
!defined('DEBUG') AND exit('Access Denied');

/**
 * 头像框商店路由
 * URL: frame-shop / frame-shop-{page}
 * 由 index_route_case_end.php 的 case 'frame': 分发（param(1)='shop'）
 * 分页参数在 param(2)（URL 第三段：frame-shop-{page}）
 */

// ===================== POST 操作 =====================
if ($method == 'POST') {
	CsrfService::check();
	$do = param('do', '');
	if ($do == 'buy') {
		$frame_id = intval(param('frame_id', 0));
		$result = FrameService::buyFrame($uid, $frame_id);
		message($result['ok'] ? 0 : -1, $result['message']);
	}
	message(-1, '无效操作');
}

// ===================== GET 页面 =====================
// URL: frame-shop-{page}.htm → param(0)='frame', param(1)='shop', param(2)={page}
$page = param(2, 1);
$page = intval($page);
if ($page < 1) $page = 1;

$pagesize = 12;
$result = FrameService::getAllFrames($page, $pagesize, true);
$frames = $result['list'];
$total = $result['count'];

// 当前用户已拥有的 frame_id 列表
$owned_ids = array();
if (!empty($uid)) {
	$owned_list = FrameService::getOwnedFrames($uid);
	foreach ($owned_list as $o) {
		$owned_ids[] = intval(isset($o['frame_id']) ? $o['frame_id'] : 0);
	}
}

// 当前用户 gid（全局变量）
$user_gid = isset($gid) ? intval($gid) : 0;

// 分页 URL（route_url 生成 frame-shop-{page} 模板，pagination 替换 {page}）
$pagination = pagination(route_url('frame_shop_page', array()), $total, $page, $pagesize);

$header['title'] = lang('xnx_avatar_frame_shop');

include _include(APP_PATH . 'view/htm/header.inc.htm');
include _include(APP_PATH . 'plugin/xnx_avatar_frame/view/htm/frame_shop.htm');
include _include(APP_PATH . 'view/htm/footer.inc.htm');
