<?php
!defined('DEBUG') AND exit('Access Denied.');

/**
 * FrameService 头像框服务
 * 管理头像框的增删改查、购买、佩戴、过期处理
 * 通过 avatar_component_frame.php hook 渲染装饰性头像框
 */
class FrameService {

    /**
     * 静态缓存：用户佩戴的头像框（uid => frame data or null），避免帖子列表页 N+1 查询
     * @var array
     */
    private static $userWearCache = array();

    /**
     * 静态缓存：头像框定义（frame_id => frame data），避免重复查库
     * @var array
     */
    private static $frameCache = array();

    // ---- 配置管理 ----

    public static function getSettings() {
        $cfg = setting_get('xnx_avatar_frame');
        if (!is_array($cfg)) $cfg = array();
        if (!isset($cfg['enabled'])) $cfg['enabled'] = 1;
        return $cfg;
    }

    public static function saveSettings($settings) {
        setting_set('xnx_avatar_frame', $settings);
    }

    // ---- 头像框 CRUD ----

    public static function createFrame($data) {
        $r = db_insert('xnx_avatar_frame', $data);
        if (!$r) {
            return array('ok' => false, 'message' => '创建失败');
        }
        return array('ok' => true, 'id' => intval($r));
    }

    public static function updateFrame($id, $data) {
        $id = intval($id);
        $r = db_update('xnx_avatar_frame', array('id' => $id), $data);
        self::clearFrameCache($id);
        return $r ? true : false;
    }

    public static function deleteFrame($id) {
        $id = intval($id);
        db_delete('xnx_avatar_frame', array('id' => $id));
        // 级联清理拥有记录（日志保留作为历史记录）
        db_delete('xnx_avatar_frame_own', array('frame_id' => $id));
        self::clearFrameCache($id);
        return true;
    }

    public static function getFrame($id) {
        $id = intval($id);
        if ($id <= 0) return array();
        if (!isset(self::$frameCache[$id])) {
            $frame = db_find_one('xnx_avatar_frame', array('id' => $id));
            self::$frameCache[$id] = $frame ? $frame : array();
        }
        return self::$frameCache[$id];
    }

    public static function getAllFrames($page = 1, $pagesize = 20, $enabled_only = false) {
        $cond = $enabled_only ? array('enabled' => 1) : array();
        $list = db_find('xnx_avatar_frame', $cond, array('sort' => 1, 'id' => 1), $page, $pagesize, 'id');
        $count = db_count('xnx_avatar_frame', $cond);
        return array('list' => $list, 'count' => $count);
    }

    // ---- 购买 ----

    /**
     * 购买头像框
     * @param int $uid 用户ID
     * @param int $frame_id 头像框ID
     * @return array ['ok'=>bool, 'message'=>string]
     */
    public static function buyFrame($uid, $frame_id) {
        $uid = intval($uid);
        $frame_id = intval($frame_id);
        if ($uid <= 0 || $frame_id <= 0) {
            return array('ok' => false, 'message' => '参数错误');
        }

        // 1. 校验 frame 存在且 enabled=1
        $frame = self::getFrame($frame_id);
        if (empty($frame)) {
            return array('ok' => false, 'message' => '头像框不存在');
        }
        if (empty($frame['enabled'])) {
            return array('ok' => false, 'message' => '头像框已下架');
        }

        // 2. 校验用户未拥有
        $owned = db_find_one('xnx_avatar_frame_own', array('uid' => $uid, 'frame_id' => $frame_id));
        if (!empty($owned)) {
            return array('ok' => false, 'message' => '您已拥有该头像框');
        }

        // 3. 校验用户组白名单
        $user = user_read($uid);
        if (empty($user)) {
            return array('ok' => false, 'message' => '用户不存在');
        }
        $gid = isset($user['gid']) ? intval($user['gid']) : 0;
        if (!self::isAllowedGroup(isset($frame['allowed_gids']) ? $frame['allowed_gids'] : '', $gid)) {
            return array('ok' => false, 'message' => '当前用户组不允许购买');
        }

        // 4. 扣分（CreditsService::sub 内部已有事务，不需要额外事务包裹）
        $price_type = isset($frame['price_type']) ? $frame['price_type'] : 'credits';
        $price_value = intval(isset($frame['price_value']) ? $frame['price_value'] : 0);
        if ($price_value > 0) {
            if (!class_exists('CreditsService')) {
                include_once APP_PATH . 'lib/CreditsService.php';
            }
            if (!class_exists('CreditsService')) {
                return array('ok' => false, 'message' => '积分服务不可用');
            }
            global $db, $conf;
            $creditsService = new CreditsService($db, $conf);
            $subResult = $creditsService->sub($uid, $price_type, $price_value, '购买头像框: ' . (isset($frame['name']) ? $frame['name'] : ''), 0, true);
            if (empty($subResult['ok'])) {
                return array('ok' => false, 'message' => $subResult['message']);
            }
        }

        // 6. 写入拥有记录
        $now = time();
        $duration_days = intval(isset($frame['duration_days']) ? $frame['duration_days'] : 0);
        $expire_time = $duration_days > 0 ? $now + $duration_days * 86400 : 0;
        $own_id = db_insert('xnx_avatar_frame_own', array(
            'uid' => $uid,
            'frame_id' => $frame_id,
            'source' => 'buy',
            'cost_type' => $price_type,
            'cost_value' => $price_value,
            'buy_time' => $now,
            'expire_time' => $expire_time,
            'is_wearing' => 0,
        ));
        if (!$own_id) {
            return array('ok' => false, 'message' => '购买失败，扣分已成功但写入拥有记录失败');
        }

        // 7. 写入日志
        db_insert('xnx_avatar_frame_log', array(
            'uid' => $uid,
            'frame_id' => $frame_id,
            'frame_name' => isset($frame['name']) ? $frame['name'] : '',
            'action' => 'buy',
            'cost_type' => $price_type,
            'cost_value' => $price_value,
            'create_time' => $now,
        ));

        // 8. 清缓存
        self::clearUserCache($uid);

        return array('ok' => true, 'message' => '购买成功');
    }

    // ---- 拥有查询 ----

    /**
     * 获取用户拥有的所有头像框（含头像框详情）
     * @param int $uid
     * @return array
     */
    public static function getOwnedFrames($uid) {
        $uid = intval($uid);
        if ($uid <= 0) return array();
        global $db;
        $tablepre = $db->tablepre;
        // JOIN 查询获取拥有记录+头像框详情，db_find 不支持 JOIN，保留 db_sql_find
        $sql = "SELECT o.*, f.name, f.description, f.frame_type, f.frame_image, f.frame_css, f.price_type, f.price_value, f.duration_days, f.allowed_gids, f.sort, f.enabled
                FROM `" . $tablepre . "xnx_avatar_frame_own` o
                LEFT JOIN `" . $tablepre . "xnx_avatar_frame` f ON o.frame_id = f.id
                WHERE o.uid = " . $uid . "
                ORDER BY o.buy_time DESC";
        $list = db_sql_find($sql);
        return $list ? $list : array();
    }

    public static function isOwned($uid, $frame_id) {
        $uid = intval($uid);
        $frame_id = intval($frame_id);
        if ($uid <= 0 || $frame_id <= 0) return false;
        $owned = db_find_one('xnx_avatar_frame_own', array('uid' => $uid, 'frame_id' => $frame_id));
        return !empty($owned);
    }

    // ---- 佩戴管理 ----

    /**
     * 佩戴头像框（同一时间只能佩戴一个）
     * @param int $uid
     * @param int $frame_id
     * @return array
     */
    public static function wearFrame($uid, $frame_id) {
        $uid = intval($uid);
        $frame_id = intval($frame_id);
        if ($uid <= 0 || $frame_id <= 0) {
            return array('ok' => false, 'message' => '参数错误');
        }

        // 1. 校验用户拥有该 frame
        $own = db_find_one('xnx_avatar_frame_own', array('uid' => $uid, 'frame_id' => $frame_id));
        if (empty($own)) {
            return array('ok' => false, 'message' => '您未拥有该头像框');
        }

        // 2. 校验未过期（expire_time=0 或 >now）
        $expire_time = intval(isset($own['expire_time']) ? $own['expire_time'] : 0);
        if ($expire_time > 0 && $expire_time < time()) {
            return array('ok' => false, 'message' => '头像框已过期');
        }

        $now = time();

        // 3. 取消旧佩戴
        db_update('xnx_avatar_frame_own', array('uid' => $uid, 'is_wearing' => 1), array('is_wearing' => 0));

        // 4. 佩戴新的
        db_update('xnx_avatar_frame_own', array('uid' => $uid, 'frame_id' => $frame_id), array('is_wearing' => 1));

        // 5. 写入日志
        $frame = self::getFrame($frame_id);
        db_insert('xnx_avatar_frame_log', array(
            'uid' => $uid,
            'frame_id' => $frame_id,
            'frame_name' => isset($frame['name']) ? $frame['name'] : '',
            'action' => 'wear',
            'cost_type' => '',
            'cost_value' => 0,
            'create_time' => $now,
        ));

        // 6. 清缓存
        self::clearUserCache($uid);

        return array('ok' => true, 'message' => '佩戴成功');
    }

    /**
     * 取消佩戴头像框
     * @param int $uid
     * @return array
     */
    public static function unwearFrame($uid) {
        $uid = intval($uid);
        if ($uid <= 0) {
            return array('ok' => false, 'message' => '参数错误');
        }

        $wearing = db_find_one('xnx_avatar_frame_own', array('uid' => $uid, 'is_wearing' => 1));
        if (empty($wearing)) {
            return array('ok' => false, 'message' => '当前未佩戴头像框');
        }

        db_update('xnx_avatar_frame_own', array('uid' => $uid, 'is_wearing' => 1), array('is_wearing' => 0));

        // 写入日志
        $frame = self::getFrame(intval($wearing['frame_id']));
        db_insert('xnx_avatar_frame_log', array(
            'uid' => $uid,
            'frame_id' => intval($wearing['frame_id']),
            'frame_name' => isset($frame['name']) ? $frame['name'] : '',
            'action' => 'unwear',
            'cost_type' => '',
            'cost_value' => 0,
            'create_time' => time(),
        ));

        self::clearUserCache($uid);

        return array('ok' => true, 'message' => '已取消佩戴');
    }

    // ---- 佩戴查询（核心，性能敏感）----

    /**
     * 获取用户当前佩戴的头像框（带静态缓存 + 懒过期检查）
     * @param int $uid
     * @return array|null 头像框数据或 null
     */
    public static function getWearingFrame($uid) {
        $uid = intval($uid);
        if ($uid <= 0) return null;

        // 1. 检查静态缓存
        if (isset(self::$userWearCache[$uid])) {
            return self::$userWearCache[$uid];
        }

        // 2. 查询佩戴记录
        $own = db_find_one('xnx_avatar_frame_own', array('uid' => $uid, 'is_wearing' => 1));

        // 3. 懒检查过期：如果 expire_time>0 且 <now，则视为过期
        if (!empty($own)) {
            $expire_time = intval(isset($own['expire_time']) ? $own['expire_time'] : 0);
            if ($expire_time > 0 && $expire_time < time()) {
                // 过期处理
                db_update('xnx_avatar_frame_own', array('id' => intval($own['id'])), array('is_wearing' => 0));
                $frame = self::getFrame(intval($own['frame_id']));
                db_insert('xnx_avatar_frame_log', array(
                    'uid' => $uid,
                    'frame_id' => intval($own['frame_id']),
                    'frame_name' => isset($frame['name']) ? $frame['name'] : '',
                    'action' => 'expire',
                    'cost_type' => '',
                    'cost_value' => 0,
                    'create_time' => time(),
                ));
                self::$userWearCache[$uid] = null;
                return null;
            }
        }

        // 4. 如果无佩戴记录
        if (empty($own)) {
            self::$userWearCache[$uid] = null;
            return null;
        }

        // 5. JOIN xnx_avatar_frame 取 frame 详情
        global $db;
        $tablepre = $db->tablepre;
        // JOIN 查询获取佩戴记录+头像框详情，db_find 不支持 JOIN，保留 db_sql_find
        $sql = "SELECT o.*, f.name, f.description, f.frame_type, f.frame_image, f.frame_css, f.price_type, f.price_value, f.duration_days, f.allowed_gids, f.sort, f.enabled
                FROM `" . $tablepre . "xnx_avatar_frame_own` o
                LEFT JOIN `" . $tablepre . "xnx_avatar_frame` f ON o.frame_id = f.id
                WHERE o.id = " . intval($own['id']) . "
                LIMIT 1";
        $frame = db_sql_find_one($sql);

        // 6. 存入静态缓存
        self::$userWearCache[$uid] = $frame ? $frame : null;

        return self::$userWearCache[$uid];
    }

    // ---- 过期清理（cron 调用）----

    /**
     * 清理所有过期的佩戴记录（由 model_cron_daily_end.php hook 调用）
     * @return int 清理的记录数
     */
    public static function cleanExpired() {
        $now = time();
        // 查所有可能过期的佩戴记录（expire_time>0 且 is_wearing=1）
        $list = db_find('xnx_avatar_frame_own', array('expire_time' => array('>' => 0), 'is_wearing' => 1), array(), 1, 1000);
        if (empty($list)) return 0;

        $count = 0;
        foreach ($list as $own) {
            $expire_time = intval(isset($own['expire_time']) ? $own['expire_time'] : 0);
            if ($expire_time > 0 && $expire_time < $now) {
                db_update('xnx_avatar_frame_own', array('id' => intval($own['id'])), array('is_wearing' => 0));
                $frame = self::getFrame(intval($own['frame_id']));
                db_insert('xnx_avatar_frame_log', array(
                    'uid' => intval($own['uid']),
                    'frame_id' => intval($own['frame_id']),
                    'frame_name' => isset($frame['name']) ? $frame['name'] : '',
                    'action' => 'expire',
                    'cost_type' => '',
                    'cost_value' => 0,
                    'create_time' => $now,
                ));
                self::clearUserCache(intval($own['uid']));
                $count++;
            }
        }
        return $count;
    }

    // ---- 用户组校验 ----

    /**
     * 检查用户组是否在白名单内
     * @param string $allowed_gids 逗号分隔的 gid 列表，空字符串表示允许所有组
     * @param int $gid 用户组ID
     * @return bool
     */
    public static function isAllowedGroup($allowed_gids, $gid) {
        $allowed_gids = is_string($allowed_gids) ? trim($allowed_gids) : '';
        if ($allowed_gids === '') {
            return true; // 空表示所有组
        }
        $gid = intval($gid);
        $gids = explode(',', $allowed_gids);
        $gids = array_map('intval', $gids);
        return in_array($gid, $gids, true);
    }

    // ---- 缓存清理 ----

    public static function clearUserCache($uid) {
        $uid = intval($uid);
        unset(self::$userWearCache[$uid]);
    }

    public static function clearFrameCache($frame_id) {
        $frame_id = intval($frame_id);
        unset(self::$frameCache[$frame_id]);
    }

    // ---- 渲染辅助 ----

    /**
     * 生成头像框 HTML 片段（用于 avatar_component_frame.php hook）
     * @param array $frame 头像框数据
     * @param string $size 尺寸（预留参数，当前未使用）
     * @return string HTML
     */
    public static function renderFrameHtml($frame, $size = 'md') {
        if (empty($frame)) return '';
        $frame_type = intval(isset($frame['frame_type']) ? $frame['frame_type'] : 0);
        $frame_id = intval(isset($frame['id']) ? $frame['id'] : (isset($frame['frame_id']) ? $frame['frame_id'] : 0));
        // 每个头像框唯一 class，方便主题/管理员针对具体框做 css 微调（如 .avatar-frame-3 { transform: scale(1.2); }）
        $unique_class = $frame_id > 0 ? ' avatar-frame-' . $frame_id : '';
        if ($frame_type === 0) {
            // 图片框：基础布局走全局 frame.css 的 .avatar-frame-img
            $frame_image = isset($frame['frame_image']) ? $frame['frame_image'] : '';
            if (empty($frame_image)) return '';
            return '<img class="avatar-frame-img' . $unique_class . '" src="' . esc_attr($frame_image) . '" alt="">';
        } else {
            // CSS 框：基础布局走全局 frame.css 的 .avatar-frame-css，frame_css 是管理员后台填的微调样式（可信输入，不转义）
            $frame_css = isset($frame['frame_css']) ? $frame['frame_css'] : '';
            $style_attr = $frame_css !== '' ? ' style="' . $frame_css . '"' : '';
            return '<div class="avatar-frame-css' . $unique_class . '"' . $style_attr . '></div>';
        }
    }
}
