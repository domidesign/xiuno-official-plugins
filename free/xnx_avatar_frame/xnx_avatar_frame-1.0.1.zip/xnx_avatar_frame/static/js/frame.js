/* xnx_avatar_frame 前台交互（无 jQuery，纯原生 JS） */
(function() {
    'use strict';

    var I18N = window.XNX_FRAME_I18N || {
        buy_success: '购买成功',
        buy_fail: '购买失败',
        wear_success: '佩戴成功',
        unwear_success: '已取消佩戴',
        insufficient_credits: '积分不足',
        confirm_buy: '确认购买该头像框？',
        loading: '处理中...'
    };

    function getCsrfToken() {
        var input = document.querySelector('input[name="csrf_token"]');
        return input ? input.value : '';
    }

    function showToast(message, type) {
        if (typeof XN !== 'undefined' && typeof XN.toast === 'function') {
            XN.toast(message, type || 'success');
        } else {
            alert(message);
        }
    }

    function setBtnLoading(btn, loading) {
        if (!btn) return;
        // 保留 innerHTML：需渲染 spinner 标签，I18N.loading 为开发者定义的国际化文案，非用户输入
        if (loading) {
            btn.dataset.originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>' + I18N.loading;
        } else {
            if (btn.dataset.originalText) {
                btn.innerHTML = btn.dataset.originalText;
            }
            btn.disabled = false;
        }
    }

    function bindAction(selector, action, confirmMsg, successMsg) {
        document.querySelectorAll(selector).forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var frameId = btn.dataset.frameId;
                if (!frameId) return;

                function doAction() {
                    setBtnLoading(btn, true);
                    var formData = new FormData();
                    formData.append('csrf_token', getCsrfToken());
                    formData.append('do', action);
                    formData.append('frame_id', frameId);

                    var postUrl = window.XNX_FRAME_POST_URL || '';
                    // 必须设 X-Requested-With: XMLHttpRequest，否则后端 message() 不会走 JSON 分支
                    // （message() 检测 $is_htmx（HX-Request header）/ $is_api（X-Requested-With/Accept）/ $ajax，三者都 false 时返回 HTML 跳转页面，前端 res.json() 解析失败报"购买失败"）
                    fetch(postUrl, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    })
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        setBtnLoading(btn, false);
                        if (data.code === 0 || data.code === '0') {
                            showToast(successMsg || data.message, 'success');
                            // buy 成功跳到"我的头像框"页（佩戴入口在那）；wear/unwear 仅 reload 当前页（更新按钮状态）
                            var redirectUrl = (action === 'buy' && window.XNX_FRAME_MY_URL) ? window.XNX_FRAME_MY_URL : '';
                            setTimeout(function() {
                                if (redirectUrl) {
                                    window.location.href = redirectUrl;
                                } else {
                                    window.location.reload();
                                }
                            }, 800);
                        } else {
                            showToast(data.message || I18N.buy_fail, 'danger');
                        }
                    })
                    .catch(function() {
                        setBtnLoading(btn, false);
                        showToast(I18N.buy_fail, 'danger');
                    });
                }

                if (confirmMsg) {
                    XN.confirm(confirmMsg, function() {
                        doAction();
                    }, {type: 'warning'});
                    return;
                }
                doAction();
            });
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        bindAction('.xnx-frame-buy', 'buy', I18N.confirm_buy, I18N.buy_success);
        bindAction('.xnx-frame-wear', 'wear', null, I18N.wear_success);
        bindAction('.xnx-frame-unwear', 'unwear', null, I18N.unwear_success);
    });
})();
