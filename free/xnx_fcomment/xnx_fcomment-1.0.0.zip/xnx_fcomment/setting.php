<?php
!defined('DEBUG') AND exit('Access Denied');

// 权限检查
$gid != 1 && $gid != 2 AND message(-1, lang('user_group_insufficient_privilege'));

// POST 保存设置
if ($method == 'POST' && !empty($_POST)) {
    CsrfService::check();

    $settings = array(
        'enabled' => intval(param('enabled', 0)),
        'count' => max(1, min(50, intval(param('count', 10)))),
        'cache_ttl' => max(0, intval(param('cache_ttl', 60))),
        'content_length' => max(1, intval(param('content_length', 100))),
    );

    FcommentService::saveSettings($settings);

    message(0, lang('xnx_fcomment_save_ok'), array('redirect_url' => admin_plugin_setting_url('xnx_fcomment')));
}

// GET 渲染设置页
$settings = FcommentService::getSettings();

include _include(APP_PATH.'plugin/xnx_fcomment/view/htm/setting.htm');
