<?php
!defined('DEBUG') AND exit('Access Denied');
setting_delete('xnx_fcomment');
if (class_exists('CacheHelper', false)) {
    CacheHelper::pluginDeletePrefix('xnx_fcomment');
}
