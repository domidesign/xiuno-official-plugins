# xnx_fcomment 版块最新评论插件

## 功能
- 在版块页面右栏展示本版块最新回复列表（头像 + 用户名 + 内容摘要 + 时间）
- 内容摘要：去除 blockquote 引用块后提取纯文本，按配置长度截断
- 权限分级：管理员组（gid=1,2）可见 audit_status 0/1 的评论，普通用户仅可见已审核通过
- 移动端自动跳过（UA 检测，避免遮挡内容）
- 缓存机制：基于 CacheHelper::remember，按 fid+role 分键，TTL 可配置
- 头像组件优先使用系统 avatar_component_from_data（含用户组图标/颜色）

## 文件结构
```
plugin/xnx_fcomment/
├── conf.json
├── install.php / uninstall.php
├── setting.php + setting.htm
├── model/
│   └── FcommentService.php       # 服务类（配置 / 缓存 / 评论查询 / 移动端检测）
├── hook/
│   ├── model_inc_file.php
│   ├── forum_mod_after.htm       # 在版块页右栏版主信息卡之后注入
│   ├── lang_zh_cn_bbs.php
│   ├── lang_zh_tw_bbs.php
│   └── lang_en_us_bbs.php
└── view/htm/
    └── setting.htm
```

## 配置流程
1. 后台启用插件
2. 进入「插件设置」→ 配置启用开关、显示条数（1-50）、缓存时长（秒）、内容摘要长度
3. 测试：访问任意版块页面，右栏应出现「本版块最新评论」卡片
