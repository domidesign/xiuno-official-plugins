<?php
!defined('DEBUG') AND exit('Access Denied');
// 写入默认配置
setting_set('xnx_fcomment', array(
    'enabled' => 1,
    'count' => 10,
    'cache_ttl' => 60,
    'content_length' => 100,
));