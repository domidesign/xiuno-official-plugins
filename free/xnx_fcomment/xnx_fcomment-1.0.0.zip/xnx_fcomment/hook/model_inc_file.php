<?php exit;
APP_PATH.'plugin/xnx_fcomment/model/FcommentService.php',
