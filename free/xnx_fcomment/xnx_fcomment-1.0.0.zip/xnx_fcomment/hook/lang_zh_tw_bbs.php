<?php
// XIUNOX 版塊最新評論插件 - 繁體中文語言包
$lang['xnx_fcomment_title'] = '最新評論';
$lang['xnx_fcomment_empty'] = '暫無回覆';
$lang['xnx_fcomment_settings'] = '版塊最新評論設定';
$lang['xnx_fcomment_enabled'] = '啟用插件';
$lang['xnx_fcomment_enabled_tip'] = '開啟後在版塊右欄展示最新回覆';
$lang['xnx_fcomment_count'] = '顯示數量';
$lang['xnx_fcomment_cache_ttl'] = '快取時間（秒）';
$lang['xnx_fcomment_cache_ttl_tip'] = '設為 0 表示永久快取，建議 30-300 秒';
$lang['xnx_fcomment_content_length'] = '摘要長度';
$lang['xnx_fcomment_save'] = '儲存設定';
$lang['xnx_fcomment_save_ok'] = '設定已儲存';
