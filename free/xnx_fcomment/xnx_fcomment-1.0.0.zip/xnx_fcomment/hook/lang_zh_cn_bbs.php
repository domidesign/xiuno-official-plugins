<?php
// XIUNOX 版块最新评论插件 - 简体中文语言包
$lang['xnx_fcomment_title'] = '最新评论';
$lang['xnx_fcomment_empty'] = '暂无回复';
$lang['xnx_fcomment_settings'] = '版块最新评论设置';
$lang['xnx_fcomment_enabled'] = '启用插件';
$lang['xnx_fcomment_enabled_tip'] = '开启后在版块右栏展示最新回复';
$lang['xnx_fcomment_count'] = '显示数量';
$lang['xnx_fcomment_cache_ttl'] = '缓存时间（秒）';
$lang['xnx_fcomment_cache_ttl_tip'] = '设为 0 表示永久缓存，建议 30-300 秒';
$lang['xnx_fcomment_content_length'] = '摘要长度';
$lang['xnx_fcomment_save'] = '保存设置';
$lang['xnx_fcomment_save_ok'] = '设置已保存';
