<?php
// XIUNOX Forum Latest Comments Plugin - English Language Pack
$lang['xnx_fcomment_title'] = 'Latest Comments';
$lang['xnx_fcomment_empty'] = 'No replies yet';
$lang['xnx_fcomment_settings'] = 'Forum Latest Comments Settings';
$lang['xnx_fcomment_enabled'] = 'Enable Plugin';
$lang['xnx_fcomment_enabled_tip'] = 'Show latest replies in forum sidebar when enabled';
$lang['xnx_fcomment_count'] = 'Display Count';
$lang['xnx_fcomment_cache_ttl'] = 'Cache TTL (seconds)';
$lang['xnx_fcomment_cache_ttl_tip'] = 'Set to 0 for permanent cache, recommended 30-300 seconds';
$lang['xnx_fcomment_content_length'] = 'Summary Length';
$lang['xnx_fcomment_save'] = 'Save Settings';
$lang['xnx_fcomment_save_ok'] = 'Settings saved';
