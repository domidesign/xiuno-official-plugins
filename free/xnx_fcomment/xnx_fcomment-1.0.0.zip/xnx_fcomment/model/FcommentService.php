<?php
!defined('DEBUG') AND exit('Access Denied');

/**
 * FcommentService 版块最新评论服务
 *
 * 在版块页面右栏展示本版块最新回复，支持缓存与权限分级。
 * 静态方法模式，缓存键通过 init() 注册。
 */
class FcommentService {

    const PLUGIN_NAME = 'xnx_fcomment';
    const SETTING_KEY = 'xnx_fcomment';

    // 缓存键注册表：key => [ttl, desc]
    private static $cacheKeys = array(
        'forum_replies' => array(60, '版块最新回复列表'),
    );

    // 默认配置
    private static $defaults = array(
        'enabled' => 1,
        'count' => 10,
        'cache_ttl' => 60,
        'content_length' => 100,
    );

    /**
     * 缓存初始化（每个方法开头调用）
     */
    public static function init() {
        if (class_exists('CacheHelper', false)) {
            CacheHelper::registerKeys(self::PLUGIN_NAME, self::$cacheKeys);
        }
    }

    /**
     * 构造函数：注册缓存键清单
     */
    public function __construct() {
        self::init();
    }

    /**
     * 清除本插件所有缓存
     */
    public static function clearCache() {
        if (class_exists('CacheHelper', false)) {
            CacheHelper::pluginDeletePrefix(self::PLUGIN_NAME);
        }
    }

    // ========== 配置 ==========

    /**
     * 读取配置（合并默认值）
     */
    public static function getSettings() {
        $settings = setting_get(self::SETTING_KEY);
        if (!is_array($settings)) $settings = array();
        return array_merge(self::$defaults, $settings);
    }

    /**
     * 保存配置并清缓存
     */
    public static function saveSettings($arr) {
        setting_set(self::SETTING_KEY, $arr);
        self::clearCache();
    }

    // ========== 核心查询 ==========

    /**
     * 获取版块最新回复列表
     *
     * @param int $fid 版块 id
     * @param int $gid 当前用户组 id（1/2 为管理员，可看 audit_status 0/1）
     * @return array postlist（已 format，含 user / user_avatar_url / create_date_fmt）
     */
    public static function getLatestReplies($fid, $gid) {
        self::init();

        $fid = intval($fid);
        $gid = intval($gid);
        if ($fid <= 0) return array();

        $settings = self::getSettings();
        if (empty($settings['enabled'])) return array();

        $count = max(1, min(50, intval($settings['count'])));
        $ttl = max(0, intval($settings['cache_ttl']));

        $isAdmin = ($gid == 1 || $gid == 2);
        $role = $isAdmin ? 'admin' : 'user';
        // remember 内部调用 pluginKey 生成带 p_xnx_fcomment_ 前缀的键名
        $key = 'forum_replies_'.$fid.'_'.$role;

        return CacheHelper::remember($key, $ttl, function() use ($fid, $isAdmin, $count) {
            global $db;
            $tablepre = $db->tablepre;

            $auditCond = $isAdmin ? 'p.audit_status IN (0,1)' : 'p.audit_status=1';

            // JOIN thread 查询，db_find 不支持 JOIN，保留 db_sql_find
            $sql = "SELECT p.pid FROM {$tablepre}post p INNER JOIN {$tablepre}thread t ON p.tid=t.tid WHERE t.fid={$fid} AND p.isfirst=0 AND p.is_deleted=0 AND {$auditCond} ORDER BY p.pid DESC LIMIT {$count}";
            $rows = db_sql_find($sql, 'pid');
            if (empty($rows)) return array();

            $pids = array_keys($rows);
            // post_find_by_pids 完成 format + 用户预加载（自动生成 display_name）
            return post_find_by_pids($pids);
        }, self::PLUGIN_NAME);
    }

    // ========== 工具 ==========

    /**
     * 判断是否移动端（UA 检测）
     */
    public static function isMobile() {
        if (empty($_SERVER['HTTP_USER_AGENT'])) return false;
        return (bool)preg_match('/Android|iPhone|iPod|Mobile|Opera Mini|IEMobile|WPDesktop/i', $_SERVER['HTTP_USER_AGENT']);
    }
}
