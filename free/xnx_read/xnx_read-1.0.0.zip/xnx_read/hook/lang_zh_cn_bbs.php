<?php
$lang['xnx_read_toggle'] = '沉浸阅读';
$lang['xnx_read_exit'] = '退出阅读';
