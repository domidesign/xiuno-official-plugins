<?php
$lang['xnx_read_toggle'] = '沉浸閱讀';
$lang['xnx_read_exit'] = '退出閱讀';
