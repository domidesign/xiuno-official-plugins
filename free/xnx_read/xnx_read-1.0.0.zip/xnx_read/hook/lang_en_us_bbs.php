<?php
$lang['xnx_read_toggle'] = 'Immersive Reading';
$lang['xnx_read_exit'] = 'Exit Reading';
