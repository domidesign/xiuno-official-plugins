/*! xnx_read 沉浸阅读模式切换 */
(function () {
    var STORAGE_KEY = 'xnx_read_mode';
    var READ_MODE_CLASS = 'read-mode';

    function updateButton(btn, icon, isReadMode) {
        var enterText = btn.getAttribute('data-enter-text');
        var exitText = btn.getAttribute('data-exit-text');
        if (isReadMode) {
            icon.className = 'ti ti-arrows-minimize';
            btn.setAttribute('title', exitText);
            btn.setAttribute('data-bs-original-title', exitText);
        } else {
            icon.className = 'ti ti-book';
            btn.setAttribute('title', enterText);
            btn.setAttribute('data-bs-original-title', enterText);
        }
    }

    function init() {
        var btn = document.getElementById('xnx-read-toggle');
        if (!btn) return;

        var icon = btn.querySelector('i');
        if (!icon) return;

        /* 从 localStorage 读取偏好并自动应用 */
        if (localStorage.getItem(STORAGE_KEY) === '1') {
            document.body.classList.add(READ_MODE_CLASS);
            updateButton(btn, icon, true);
        }

        /* 避免重复绑定（htmx boost 导航后可能重复执行） */
        if (btn.getAttribute('data-xnx-read-bound')) return;
        btn.setAttribute('data-xnx-read-bound', '1');

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            var isReadMode = document.body.classList.toggle(READ_MODE_CLASS);
            localStorage.setItem(STORAGE_KEY, isReadMode ? '1' : '0');
            updateButton(btn, icon, isReadMode);
        });
    }

    /* 初始化：DOM 已就绪时立即执行，否则等 DOMContentLoaded */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    /* htmx boost 导航后重新初始化 */
    document.addEventListener('htmx:after:swap', init);
})();
