# xnx_read 沉浸阅读

## 功能
- 帖子详情页一键切换沉浸阅读模式，隐藏右侧边栏（作者卡片 / 目录 / 二维码），主内容区扩展到 83.33% 宽度
- 偏好持久化：通过 `localStorage` 保存用户选择，下次访问自动应用
- 平滑过渡：布局切换带 0.3s 过渡动画
- 图标切换：进入时 `ti-book`，退出时 `ti-arrows-minimize`
- htmx 兼容：监听 `htmx:after:swap` 事件，boost 导航后自动重新初始化
- 多语言（zh-cn / zh-tw / en-us）

## 文件结构
```
plugin/xnx_read/
├── conf.json
├── icon.png
├── readme.md                          # 历史文档（与本 README 同文件，macOS 大小写不敏感）
├── hook/
│   ├── thread_action_bar_body.htm     # 左侧操作栏注入切换按钮
│   ├── thread_end.htm                 # 帖子详情页加载 CSS / JS
│   ├── lang_zh_cn_bbs.php
│   ├── lang_zh_tw_bbs.php
│   └── lang_en_us_bbs.php
└── static/
    ├── css/read.css                   # 布局切换样式（body.read-mode）
    └── js/read.js                     # 切换逻辑 + localStorage 持久化
```

## 配置流程
1. 后台「插件管理」安装并启用 xnx_read
2. 访问任意帖子详情页，左侧操作栏最下方出现沉浸阅读按钮（书本图标）
3. 测试：点击按钮切换 → 右侧边栏隐藏、主内容区扩展 → 再次点击还原；刷新页面后偏好自动保留

> 纯前端插件，无 PHP 后端、无数据库表、无后台配置项，开箱即用。
> 移动端（xl 断点以下）按钮自动隐藏。
