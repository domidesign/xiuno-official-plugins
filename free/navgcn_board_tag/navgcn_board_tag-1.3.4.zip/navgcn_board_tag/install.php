<?php
/*
    XIUNOX 版块自定义标签插件 - 安装脚本
*/
!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

// 创建标签分组表
db_exec("CREATE TABLE IF NOT EXISTS {$tablepre}navgcn_board_tag_group (
    id int(11) unsigned NOT NULL AUTO_INCREMENT,
    fid int(11) unsigned NOT NULL DEFAULT 0 COMMENT '版块ID',
    name varchar(64) NOT NULL DEFAULT '' COMMENT '分组名称',
    sort int(11) unsigned NOT NULL DEFAULT 0 COMMENT '排序权重',
    select_mode tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '选择模式：0单选，1多选',
    enabled tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '是否启用',
    forced tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '是否强制（发帖必选）',
    create_time int(11) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY fid (fid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版块标签分组表'");

// 创建标签项表
db_exec("CREATE TABLE IF NOT EXISTS {$tablepre}navgcn_board_tag_item (
    id int(11) unsigned NOT NULL AUTO_INCREMENT,
    group_id int(11) unsigned NOT NULL DEFAULT 0 COMMENT '分组ID',
    name varchar(64) NOT NULL DEFAULT '' COMMENT '标签名称',
    icon varchar(64) NOT NULL DEFAULT '' COMMENT 'Tabler图标类名',
    sort int(11) unsigned NOT NULL DEFAULT 0 COMMENT '排序权重',
    enabled tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '是否启用',
    is_default tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '是否默认选中',
    color varchar(32) NOT NULL DEFAULT '' COMMENT '标签颜色',
    create_time int(11) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY group_id (group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版块标签项表'");

// 创建帖子-标签关联表
db_exec("CREATE TABLE IF NOT EXISTS {$tablepre}navgcn_board_tag_thread (
    tag_id int(11) unsigned NOT NULL DEFAULT 0 COMMENT '标签ID',
    tid int(11) unsigned NOT NULL DEFAULT 0 COMMENT '帖子ID',
    PRIMARY KEY (tag_id, tid),
    KEY tid (tid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='帖子标签关联表'");

// 初始化默认设置
$navgcn_board_tag_settings = array(
    'max_list_display' => 3,
    'show_in_thread' => 1,
    'show_in_list' => 1,
);
setting_set('navgcn_board_tag', $navgcn_board_tag_settings);

// 清理 model.min.php 编译缓存
if (isset($conf['tmp_path']) && function_exists('xn_unlink')) {
    @xn_unlink($conf['tmp_path'].'model.min.php');
}