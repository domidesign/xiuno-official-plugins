<?php
/*
    XIUNOX 版块自定义标签插件 - 后台设置与管理
*/

!defined('DEBUG') AND exit('Access Denied');

// 权限检查
if ($gid != 1 && $gid != 2) {
    message(-1, lang('user_group_insufficient_privilege'));
}

$navgbt_action = param('navgbt_action', '');

// 处理管理操作
if (!empty($navgbt_action)) {
    CsrfService::check();

    // 全局设置
    if ($navgbt_action == 'save_settings') {
        $settings = array(
            'max_list_display' => intval(param('max_list_display', 3)),
            'show_in_thread' => intval(param('show_in_thread', 0)),
            'show_in_list' => intval(param('show_in_list', 0)),
            'config_mode' => param('config_mode', 'standalone') === 'board_edit' ? 'board_edit' : 'standalone',
        );
        $settings['max_list_display'] = max(1, min(10, $settings['max_list_display']));
        BoardTagService::saveSettings($settings);
        message(0, lang('navgcn_board_tag_operation_success'));
    }

    // 添加分组
    if ($navgbt_action == 'add_group') {
        $fid = intval(param('fid', 0));
        $name = trim(param('group_name', ''));
        $sort = intval(param('group_sort', 0));
        $selectMode = intval(param('group_select_mode', 0));
        $enabled = intval(param('group_enabled', 1));
        $forced = intval(param('group_forced', 0));
        $items = trim(param('group_items', ''));
        if (empty($name) || $fid <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $groupId = BoardTagService::createGroup($fid, $name, $sort, $selectMode, $enabled, $forced);
        if ($groupId && $items !== '') {
            $itemNames = preg_split('/[\r\n,]+/', $items);
            foreach ($itemNames as $itemName) {
                $itemName = trim($itemName);
                if ($itemName !== '') {
                    // 排序号统一交给 createItem 自动递增（max+1）。
                    // 必须传 0，绝不能传自增的 $itemSort——否则首项触发自动分配得到 1、
                    // 次项又显式传入 1，造成两项 sort 撞号（tie）从而显示乱序。
                    BoardTagService::createItem($groupId, $itemName, 0, '', 1, 0);
                }
            }
        }
        message(0, lang('navgcn_board_tag_operation_success'), array('group_id' => $groupId));
    }

    // 编辑分组
    if ($navgbt_action == 'edit_group') {
        $id = intval(param('group_id', 0));
        $name = trim(param('group_name', ''));
        $sort = intval(param('group_sort', 0));
        $selectMode = intval(param('group_select_mode', 0));
        $enabled = intval(param('group_enabled', 1));
        $forced = intval(param('group_forced', 0));
        $items = trim(param('group_items', ''));
        if (empty($name) || $id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        BoardTagService::updateGroup($id, array(
            'name' => $name,
            'sort' => $sort,
            'select_mode' => $selectMode,
            'enabled' => $enabled,
            'forced' => $forced,
        ));
        if ($items !== '') {
            $itemNames = preg_split('/[\r\n,]+/', $items);
            foreach ($itemNames as $itemName) {
                $itemName = trim($itemName);
                if ($itemName !== '') {
                    // 同上：传 0 让 createItem 自动递增，避免与自动分配撞号导致显示乱序
                    BoardTagService::createItem($id, $itemName, 0, '', 1, 0);
                }
            }
        }
        message(0, lang('navgcn_board_tag_operation_success'));
    }

    // 删除分组
    if ($navgbt_action == 'delete_group') {
        $id = intval(param('group_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        BoardTagService::deleteGroup($id);
        message(0, lang('navgcn_board_tag_operation_success'));
    }

    // 添加标签项
    if ($navgbt_action == 'add_item') {
        $groupId = intval(param('group_id', 0));
        $name = trim(param('item_name', ''));
        $sort = intval(param('item_sort', 0));
        $color = trim(param('item_color', ''));
        $enabled = intval(param('item_enabled', 1));
        $isDefault = intval(param('item_default', 0));
        if (empty($name) || $groupId <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $itemId = BoardTagService::createItem($groupId, $name, $sort, $color, $enabled, $isDefault);
        message(0, lang('navgcn_board_tag_operation_success'), array('item_id' => $itemId, 'group_id' => $groupId));
    }

    // 编辑标签项
    if ($navgbt_action == 'edit_item') {
        $id = intval(param('item_id', 0));
        $name = trim(param('item_name', ''));
        $sort = intval(param('item_sort', 0));
        $color = trim(param('item_color', ''));
        $enabled = intval(param('item_enabled', 1));
        $isDefault = intval(param('item_default', 0));
        if (empty($name) || $id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        BoardTagService::updateItem($id, array(
            'name' => $name,
            'sort' => $sort,
            'color' => $color,
            'enabled' => $enabled,
            'is_default' => $isDefault,
        ));
        message(0, lang('navgcn_board_tag_operation_success'));
    }

    // 删除标签项
    if ($navgbt_action == 'delete_item') {
        $id = intval(param('item_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        BoardTagService::deleteItem($id);
        message(0, lang('navgcn_board_tag_operation_success'));
    }

    // 分组上移
    if ($navgbt_action == 'move_group_up') {
        $id = intval(param('group_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $r = BoardTagService::moveGroupUp($id);
        message($r ? 0 : -1, $r ? lang('navgcn_board_tag_operation_success') : lang('navgcn_board_tag_already_first'));
    }

    // 分组下移
    if ($navgbt_action == 'move_group_down') {
        $id = intval(param('group_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $r = BoardTagService::moveGroupDown($id);
        message($r ? 0 : -1, $r ? lang('navgcn_board_tag_operation_success') : lang('navgcn_board_tag_already_last'));
    }

    // 标签项上移
    if ($navgbt_action == 'move_item_up') {
        $id = intval(param('item_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $r = BoardTagService::moveItemUp($id);
        message($r ? 0 : -1, $r ? lang('navgcn_board_tag_operation_success') : lang('navgcn_board_tag_already_first'));
    }

    // 标签项下移
    if ($navgbt_action == 'move_item_down') {
        $id = intval(param('item_id', 0));
        if ($id <= 0) message(-1, lang('navgcn_board_tag_operation_failed'));
        $r = BoardTagService::moveItemDown($id);
        message($r ? 0 : -1, $r ? lang('navgcn_board_tag_operation_success') : lang('navgcn_board_tag_already_last'));
    }

    message(-1, lang('navgcn_board_tag_operation_failed'));
}

// 防止浏览器/代理缓存设置页 HTML，避免「保存后刷新显示旧配置」的错觉
// 与核心 admin/route/setting.php 及 navgcn_survey 修复保持一致
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// 加载设置页数据
$settings = BoardTagService::getSettings();
$csrf_token = CsrfService::generate();

// 获取所有版块列表（排除分区）
$forumlist_data = forum_list_cache();
$navgbt_board_tags = array();
foreach ($forumlist_data as $forum) {
    if ($forum['type'] == 1) continue;
    $navgbt_board_tags[$forum['fid']] = BoardTagService::getGroups($forum['fid']);
}
$selected_fid = intval(param('fid', 0));

// 如果选中了版块，获取其标签配置
$groups = array();
$tagConfig = array();
if ($selected_fid > 0) {
    $groups = BoardTagService::getGroups($selected_fid);
    $tagConfig = BoardTagService::getBoardTagConfig($selected_fid);
}

// 计算「下一个排序号」：分组取当前版块现有最大 sort + 1；标签项按各自分组取最大 sort + 1。
// 用于新建弹窗预填排序框，免去用户手写，并保证新建即按创建顺序递增（避免与自动分配撞号）。
$navgbt_next_group_sort = 1;
foreach ($groups as $g) {
    $navgbt_next_group_sort = max($navgbt_next_group_sort, intval($g['sort']) + 1);
}
$navgbt_next_item_sort = array();
foreach ($navgbt_board_tags as $fid => $gs) {
    foreach ($gs as $g) {
        $gid = intval($g['id']);
        $items = BoardTagService::getItemsByGroup($gid);
        $next = 1;
        foreach ($items as $it) {
            $next = max($next, intval($it['sort']) + 1);
        }
        $navgbt_next_item_sort[$gid] = $next;
    }
}

// 颜色选项
$navgbt_color_options = array(
    '' => '默认',
    'primary' => '蓝色',
    'secondary' => '灰色',
    'success' => '绿色',
    'danger' => '红色',
    'warning' => '黄色',
    'info' => '青色',
    'dark' => '深色',
    'indigo' => '靛青',
    'purple' => '紫色',
    'pink' => '粉色',
    'teal' => '青绿',
    'orange' => '橙色',
);

include _include(APP_PATH.'plugin/navgcn_board_tag/view/htm/setting.htm');