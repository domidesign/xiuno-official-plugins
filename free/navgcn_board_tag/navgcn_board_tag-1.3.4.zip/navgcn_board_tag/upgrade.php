<?php
/*
    XIUNOX 版块自定义标签插件 - 升级脚本（幂等）
*/
!defined('DEBUG') AND exit('Forbidden');

global $db;
$tablepre = $db->tablepre;

// v1.0.0 → v1.1.0：表前缀从 navg_board_tag 迁移到 navgcn_board_tag
// 保留 db_sql_find（系统表查询）
$oldTables = db_sql_find("SHOW TABLES LIKE '{$tablepre}navg_board_tag_%'");
if (!empty($oldTables)) {
    foreach ($oldTables as $row) {
        $oldName = current($row);
        $newName = str_replace('navg_board_tag_', 'navgcn_board_tag_', $oldName);
        // 仅在新表不存在时重命名
        $newExists = db_sql_find_one("SHOW TABLES LIKE '{$newName}'");
        if (empty($newExists)) {
            db_exec("RENAME TABLE `{$oldName}` TO `{$newName}`");
        }
    }
}

// 迁移设置键
$oldSettings = setting_get('navg_board_tag');
if (!empty($oldSettings)) {
    setting_set('navgcn_board_tag', $oldSettings);
    setting_delete('navg_board_tag');
}

// v1.0.0 → v1.1.0：新增 enabled/forced/color/is_default 字段
$cols = db_sql_find("SHOW COLUMNS FROM {$tablepre}navgcn_board_tag_group");
if ($cols) {
    $col_names = array();
    foreach ($cols as $col) { $col_names[$col['Field']] = 1; }
    if (!isset($col_names['enabled'])) {
        db_exec("ALTER TABLE {$tablepre}navgcn_board_tag_group ADD COLUMN enabled tinyint(1) unsigned NOT NULL DEFAULT 1 AFTER select_mode");
    }
    if (!isset($col_names['forced'])) {
        db_exec("ALTER TABLE {$tablepre}navgcn_board_tag_group ADD COLUMN forced tinyint(1) unsigned NOT NULL DEFAULT 0 AFTER enabled");
    }
}

$cols = db_sql_find("SHOW COLUMNS FROM {$tablepre}navgcn_board_tag_item");
if ($cols) {
    $col_names = array();
    foreach ($cols as $col) { $col_names[$col['Field']] = 1; }
    if (!isset($col_names['enabled'])) {
        db_exec("ALTER TABLE {$tablepre}navgcn_board_tag_item ADD COLUMN enabled tinyint(1) unsigned NOT NULL DEFAULT 1 AFTER sort");
    }
    if (!isset($col_names['is_default'])) {
        db_exec("ALTER TABLE {$tablepre}navgcn_board_tag_item ADD COLUMN is_default tinyint(1) unsigned NOT NULL DEFAULT 0 AFTER enabled");
    }
    if (!isset($col_names['color'])) {
        db_exec("ALTER TABLE {$tablepre}navgcn_board_tag_item ADD COLUMN color varchar(32) NOT NULL DEFAULT '' AFTER is_default");
    }
}

// 清理 tmp 缓存
plugin_clear_tmp_dir();

// v1.2.0 → v1.3.0：修复 sort=0 的历史数据，自动按创建时间编号
// v1.3.1 → v1.3.2：彻底重排 sort，按 (sort, id) 顺序统一编号为 1,2,3…
// 既修复 sort=0，也消除「批量建标签时前两项撞号」等造成的重复值/空隙，
// 同时保留用户原有的相对顺序（按 sort 升序排列后再顺编）。
// 分组排序重排（按 fid 分组、组内按 sort,id 升序顺编）
$allGroups = db_sql_find("SELECT id, fid, sort FROM {$tablepre}navgcn_board_tag_group ORDER BY fid ASC, sort ASC, id ASC");
if (!empty($allGroups)) {
    $fidLast = null;
    $sort = 0;
    foreach ($allGroups as $g) {
        $fid = (int)$g['fid'];
        if ($fid !== $fidLast) { $fidLast = $fid; $sort = 0; }
        $sort++;
        db_exec("UPDATE {$tablepre}navgcn_board_tag_group SET sort = {$sort} WHERE id = " . (int)$g['id']);
    }
}

// 标签项排序重排（按 group_id 分组、组内按 sort,id 升序顺编）
$allItems = db_sql_find("SELECT id, group_id, sort FROM {$tablepre}navgcn_board_tag_item ORDER BY group_id ASC, sort ASC, id ASC");
if (!empty($allItems)) {
    $gidLast = null;
    $sort = 0;
    foreach ($allItems as $it) {
        $gid = (int)$it['group_id'];
        if ($gid !== $gidLast) { $gidLast = $gid; $sort = 0; }
        $sort++;
        db_exec("UPDATE {$tablepre}navgcn_board_tag_item SET sort = {$sort} WHERE id = " . (int)$it['id']);
    }
}

// 清理缓存
if (class_exists('CacheHelper', false)) {
    CacheHelper::deleteByPrefix(CacheHelper::pluginKey('board_tags_', 'navgcn_board_tag'));
}