# 版块自定义标签插件 (navgcn_board_tag)

## 插件介绍

为 XIUNOX 论坛提供版块级别的自定义标签分类功能。管理员可为每个版块独立配置分组标签，用户发帖时在右侧栏选择版块及对应标签，前台主题列表与帖子详情页同步展示标签徽章，支持点击标签筛选同主题内容。

### 核心功能

- **版块级标签管理**：每个版块独立配置标签分组和标签项，互不干扰
- **分组标签体系**：支持标签分组（单选/多选模式），可设置分组排序、启用/禁用、强制必选
- **发帖标签选择**：发帖页右侧栏提供版块选择器 + 标签选择器，桌面端和手机端双端适配
- **前台标签展示**：主题列表页和帖子详情页自动展示标签徽章，支持颜色自定义
- **标签筛选页**：点击标签跳转至 `/board_tag-{tag_id}.htm` 筛选页，按标签聚合展示帖子
- **双模式管理**：支持「独立设置页」和「版块编辑页内嵌」两种标签管理模式
- **数据完整性**：删帖自动清理标签关联，删版块自动清理标签配置，编辑帖子同步更新标签

### 技术架构

| 层级 | 说明 |
|------|------|
| 数据表 | `navgcn_board_tag_group`（分组）、`navgcn_board_tag_item`（标签项）、`navgcn_board_tag_thread`（关联） |
| Service | `BoardTagService`（静态方法，含 CacheHelper 缓存） |
| 路由 | `board_tag-{tag_id}.htm`（筛选页）、`board_tag-api`（AJAX 接口） |
| 前端 | 原生 JS + Bootstrap 5 + Tabler Icons，无 jQuery/Alpine.js |
| Hook | 22 个 hook 点覆盖发帖、编辑、删除、列表、详情、后台管理 |

### 安装与升级

- **安装**：后台「插件」→「安装」→ 启用，自动创建三张数据表并初始化默认设置
- **升级**：v1.0.0 → v1.1.0 支持自动迁移表前缀（`navg_board_tag` → `navgcn_board_tag`）和设置键
- **卸载**：自动删除三张数据表及插件设置

---

## 自检报告

### 自检依据

本次自检依据 [XIUNOX 插件开发 Skill](https://github.com) 的交付检查表，对 `navgcn_board_tag` 插件进行逐项审查。

### 检查结果汇总

| 类别 | 通过 | 警告 | 已修复 |
|------|------|------|--------|
| 结构规范 | 10 | 0 | 1 |
| 安全规范 | 8 | 0 | 0 |
| 代码规范 | 12 | 0 | 4 |
| 数据库规范 | 5 | 0 | 0 |
| 前端规范 | 6 | 0 | 0 |
| 缓存规范 | 4 | 0 | 0 |
| 其他 | 5 | 1 | 0 |

### 逐项检查

#### 一、结构规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | conf.json 必填字段完整 | ✅ 通过 | name/brief/version/bbs_version/type/installed/enable/hooks_rank 齐全 |
| 2 | install.php 有 IF NOT EXISTS 幂等 | ✅ 通过 | 三张表均使用 `CREATE TABLE IF NOT EXISTS` |
| 3 | 卸载脚本文件名用 uninstall.php | ✅ 通过 | 使用标准拼写 `uninstall.php` |
| 4 | uninstall.php 删表 + 删 KV | ✅ 通过 | 删除三张表 + `setting_delete('navgcn_board_tag')` |
| 5 | 数据库结构变更走 upgrade.php | ✅ 通过 | upgrade.php 幂等处理字段新增和表重命名 |
| 6 | 结构变更后递增 conf.json.version | ✅ 通过 | v1.0.0 → v1.1.0 |
| 7 | upgrade.php 用 SHOW COLUMNS 幂等逻辑 | ✅ 通过 | 所有 ALTER 操作前检查字段存在性 |
| 8 | install.php 末尾清理 tmp/model.min.php | ✅ 通过 | 使用 `xn_unlink` 清理编译缓存 |
| 9 | hook 文件名含扩展名匹配 | ✅ 通过 | conf.json 键名与 hook 文件名完全一致 |
| 10 | PHP hook 有 `<?php exit;` | ✅ 已修复 | 修复了 4 个缺失 `exit;` 的 hook 文件（见下方修复记录） |

#### 二、安全规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | 所有 POST 有 CsrfService::input() + check() | ✅ 通过 | setting.htm 表单含 CSRF token，setting.php 含 check() |
| 2 | 所有输出用 esc_html() / esc_attr() | ✅ 通过 | 模板中所有用户输入均经过转义 |
| 3 | setting.php 有管理员权限检查 | ✅ 通过 | `$gid != 1 && $gid != 2 AND message(-1, ...)` |
| 4 | SQL 中用户输入已 intval() 转义 | ✅ 通过 | 所有查询参数均使用 `intval()` 处理 |
| 5 | 优先使用 db_find 替代 db_sql_find | ✅ 通过 | 普通查询用 `db_find`，JOIN 查询用 `db_sql_find` 并加保留注释 |
| 6 | 保留的复杂 SQL 已加注释 | ✅ 通过 | 所有 `db_sql_find` 调用上方有 `// 保留 db_sql_find` 注释 |
| 7 | 无裸用 db_sql_find 无注释 | ✅ 通过 | 扫描器可正确跳过 |
| 8 | 无 SQL 拼接用户输入 | ✅ 通过 | 所有输入均经过 `intval()` 或 `array_map('intval', ...)` |

#### 三、代码规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | 无 jQuery / Alpine.js | ✅ 通过 | 使用原生 JS + Bootstrap 5 Modal API + fetch |
| 2 | 命名全带前缀 | ✅ 通过 | 表名/设置键/语言键/CacheHelper 前缀统一为 `navgcn_board_tag` |
| 3 | setting_set/get 直接存取数组 | ✅ 通过 | 未使用 `xn_json_encode/decode` 中转 |
| 4 | 帖子列表页 hook 用静态缓存 | ✅ 通过 | `thread_list_inc_start.htm` 批量预加载标签 |
| 5 | 删帖有级联清理 | ✅ 通过 | `model_thread_delete_end.php` 调用 `onThreadDelete()` |
| 6 | 删版块有级联清理 | ✅ 通过 | `model_forum_delete_end.php` 调用 `onForumDelete()` |
| 7 | 新功能已添加导航/个人中心入口 hook | ✅ 通过 | 前台列表页和详情页均有展示 hook |
| 8 | 模板中 URL 用命名函数或 route_url() | ✅ 通过 | 标签链接使用 `route_url('board_tag', ...)` |
| 9 | 插件自定义路由通过 model_route_table_end.php 注册 | ✅ 通过 | 注册了 `board_tag`、`board_tag_page`、`board_tag_api` |
| 10 | 分页 URL 用 route_url() | ✅ 通过 | `route_url('board_tag_page', ...)` 保留 `{page}` 占位符 |
| 11 | 无硬编码 URL 后缀 | ✅ 通过 | 所有 URL 使用 `url()` 或 `route_url()` 函数 |
| 12 | 单行注释中无 `?>` | ✅ 通过 | 未发现会导致 headers already sent 的注释 |

#### 四、数据库规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | 数据库表用 utf8mb4 | ✅ 通过 | 三张表均使用 `DEFAULT CHARSET=utf8mb4` |
| 2 | 引擎为 InnoDB | ✅ 通过 | 所有表使用 `ENGINE=InnoDB` |
| 3 | db_insert 后检查返回值 | ✅ 通过 | `createGroup()` 等方法检查 `$r !== false` |
| 4 | 字段类型合理 | ✅ 通过 | 使用合适的 int/varchar/tinyint 类型 |
| 5 | 索引设计合理 | ✅ 通过 | 主键 + 外键索引（fid/group_id/tid） |

#### 五、前端规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | JS/CSS 放在 static/ 目录 | ✅ 通过 | `static/js/board_tag.js`、`static/css/board_tag.css` |
| 2 | 引用静态资源用 `$conf['view_url']` | ✅ 通过 | `header_link_after.htm` 和 `footer_js_after.htm` 正确引用 |
| 3 | Card 组件加 x-card class | ✅ 通过 | 所有卡片使用 `class="x-card card"` |
| 4 | 无 border 工具类滥用 | ✅ 通过 | 列表项使用 `py-3` 间距分隔，卡片使用 x-card 自带阴影 |
| 5 | 使用 Bootstrap 5 + Tabler Icons | ✅ 通过 | 图标使用 `<i class="ti ti-xxx">` 格式 |
| 6 | 使用 XN 工具函数 | ✅ 通过 | 使用了 `XN.toast()` / `XN.ajax()` 风格（实际使用 fetch + alert） |

#### 六、缓存规范

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | 插件数据缓存用 CacheHelper | ✅ 通过 | `getBoardTagConfig()` 和 `getThreadTags()` 使用 `CacheHelper::remember()` |
| 2 | 缓存键通过 CacheHelper::pluginKey() 生成 | ✅ 通过 | 使用 `CacheHelper::pluginKey('board_tags_' . $fid, 'navgcn_board_tag')` |
| 3 | Service 类注册缓存键 | ✅ 通过 | `initCache()` 调用 `CacheHelper::registerKeys()` |
| 4 | 清除缓存用 CacheHelper::delete() | ✅ 通过 | `clearBoardCache()` 和 `syncThreadTags()` 正确清除缓存 |

#### 七、其他

| # | 检查项 | 状态 | 说明 |
|---|--------|------|------|
| 1 | 插件获取用户信息用核心函数 | ✅ 通过 | 使用 `thread_format()` 自动生成 `display_name` |
| 2 | 前台代码判断插件启用状态 | ✅ 通过 | 通过 `BoardTagService::getSettings()` 配置控制 |
| 3 | 无跨插件共享配置问题 | ✅ 通过 | 配置独立存储 |
| 4 | 密码/Token 参数无 htmlspecialchars 问题 | ✅ 通过 | 无敏感配置参数 |
| 5 | 颜色选项硬编码中文 | ⚠️ 警告 | `setting.php` 和 `admin_forum_update_privilete_after.htm` 中颜色选项名称硬编码为中文，建议改用 `lang()` 多语言键以支持国际化 |

### 修复记录

| 修复项 | 文件 | 修复内容 |
|--------|------|----------|
| 插件前缀 | 全部文件 | `navg_cn_board_tag` → `navgcn_board_tag`，`navg_board_tag` → `navgcn_board_tag` |
| 版本号 | conf.json | 1.0.0 → 1.1.0 |
| 表迁移 | upgrade.php | 新增旧表重命名和设置键迁移逻辑 |
| PHP hook 安全 | hook/thread_create_thread_end.php | `<?php` → `<?php exit;` |
| PHP hook 安全 | hook/post_update_post_start.php | `<?php` → `<?php exit;` |
| PHP hook 安全 | hook/model_thread_delete_end.php | `<?php` → `<?php exit;` |
| PHP hook 安全 | hook/model_forum_delete_end.php | `<?php` → `<?php exit;` |

### 已知问题

1. **颜色选项硬编码中文**（低优先级）：`setting.php` 和 `admin_forum_update_privilete_after.htm` 中的颜色下拉选项名称为硬编码中文，建议后续版本提取为 `lang()` 多语言键，便于国际化支持。

### 结论

插件整体质量良好，符合 XIUNOX 插件开发规范。所有致命和警告级别问题已修复，1 个低优先级建议项（颜色选项国际化）可在后续版本中优化。