<?php
/*
    XIUNOX 版块自定义标签插件 - 前台路由
    board_tag-{tag_id}.htm → 标签筛选页
    board_tag-api → API接口
*/

!defined('DEBUG') AND exit('Access Denied');

$action = param(1, 'list');

// API 接口：获取版块标签配置
if ($action == 'api') {
    $apiAction = param('action', '');
    if ($apiAction == 'config') {
        $fid = intval(param('fid', 0));
        if ($fid <= 0) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('code' => -1, 'message' => 'Invalid fid'), JSON_UNESCAPED_UNICODE);
            exit;
        }
        $config = BoardTagService::getBoardTagConfig($fid);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('code' => 0, 'data' => $config), JSON_UNESCAPED_UNICODE);
        exit;
    }
    http_404();
}

// 标签筛选页
$tagId = intval(param(1, 0));
$page = param(2, 1);

if ($tagId <= 0) {
    http_404();
}

$tag = BoardTagService::getItemById($tagId);
if (empty($tag)) {
    error_page(404, '标签不存在');
}

$pagesize = 20;
$result = BoardTagService::getThreadsByTagId($tagId, $page, $pagesize);
$threadlist = $result['list'];
$total = $result['total'];

// 格式化帖子
if (!empty($threadlist)) {
    foreach ($threadlist as &$t) {
        thread_format($t);
    }
    unset($t);
    thread_list_access_filter($threadlist, $gid);
    if ($gid > 2) {
        $threadlist = array_filter($threadlist, function($t) use ($uid) {
            return !isset($t['audit_status']) || $t['audit_status'] == 1 || $t['uid'] == $uid;
        });
    } elseif ($gid == 0) {
        $threadlist = array_filter($threadlist, function($t) {
            return !isset($t['audit_status']) || $t['audit_status'] == 1;
        });
    }
}

$pagination = pagination(route_url('board_tag_page', array('tag_id' => $tagId)), $total, $page, $pagesize);

// 批量加载帖子的所有标签
$navgbt_tag_map = array();
if (!empty($threadlist)) {
    $navgbt_all_tids = array();
    foreach ($threadlist as $_tt) {
        if (isset($_tt['tid'])) $navgbt_all_tids[] = $_tt['tid'];
    }
    if (!empty($navgbt_all_tids)) {
        $navgbt_tag_map = BoardTagService::getThreadTagsBatch($navgbt_all_tids);
    }
}

$header['title'] = '#' . $tag['name'] . ' - ' . $conf['sitename'];
$header['keywords'] = $tag['name'];
$header['description'] = $tag['name'] . ' - 标签筛选';

include _include(APP_PATH.'plugin/navgcn_board_tag/view/htm/tag_list.htm');