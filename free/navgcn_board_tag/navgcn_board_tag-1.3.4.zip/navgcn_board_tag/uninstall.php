<?php
/*
    XIUNOX 版块自定义标签插件 - 卸载脚本
*/
!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;

db_exec("DROP TABLE IF EXISTS {$tablepre}navgcn_board_tag_thread");
db_exec("DROP TABLE IF EXISTS {$tablepre}navgcn_board_tag_item");
db_exec("DROP TABLE IF EXISTS {$tablepre}navgcn_board_tag_group");

setting_delete('navgcn_board_tag');