<?php
// XIUNOX 版块自定义标签插件 - 路由表注册
$routes['board_tag']       = 'board_tag-{tag_id}';
$routes['board_tag_page']  = 'board_tag-{tag_id}-{page}';
$routes['board_tag_api']   = 'board_tag-api';