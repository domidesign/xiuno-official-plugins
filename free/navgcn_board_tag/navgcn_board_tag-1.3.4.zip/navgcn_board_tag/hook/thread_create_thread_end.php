<?php exit;
// XIUNOX 版块自定义标签插件 - 发帖后同步标签关联
if (!empty($tid) && !empty($fid)) {
    // PC端和手机端都可能提交，优先取PC端的，fallback到手机端
    $navgbt_tags_input = param('navgbt_tags', '');
    if (empty($navgbt_tags_input)) {
        $navgbt_tags_input = param('navgbt_tags_m', '');
    }
    if (!empty($navgbt_tags_input)) {
        $navgbt_tag_ids = array_filter(array_map('intval', explode(',', $navgbt_tags_input)));
        if (!empty($navgbt_tag_ids)) {
            BoardTagService::syncThreadTags($tid, $fid, $navgbt_tag_ids);
        }
    }
}