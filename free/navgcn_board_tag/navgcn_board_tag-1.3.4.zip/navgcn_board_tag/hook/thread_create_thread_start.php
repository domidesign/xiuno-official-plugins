<?php exit;
// XIUNOX 版块自定义标签插件 - 发帖前强制标签校验
// 此 hook 在 thread_create_thread_start.php 处执行，位于发帖流程验证阶段

// 获取版块ID和提交的标签
$navgbt_fid = param('fid', 0);
if ($navgbt_fid > 0) {
    // 获取版块的标签配置
    $navgbt_board_config = BoardTagService::getBoardTagConfig($navgbt_fid);
    if (!empty($navgbt_board_config)) {
        // 获取用户提交的标签
        $navgbt_tags_input = param('navgbt_tags', '');
        if (empty($navgbt_tags_input)) {
            $navgbt_tags_input = param('navgbt_tags_m', '');
        }
        $navgbt_submitted_ids = array();
        if (!empty($navgbt_tags_input)) {
            $navgbt_submitted_ids = array_filter(array_map('intval', explode(',', $navgbt_tags_input)));
        }

        // 检查每个分组，如果有 forced=1 的分组，必须至少选一个标签
        foreach ($navgbt_board_config as $groupData) {
            $group = $groupData['group'];
            if (empty($group['forced'])) continue;
            if (empty($groupData['items'])) continue;

            $navgbt_group_item_ids = array();
            foreach ($groupData['items'] as $item) {
                $navgbt_group_item_ids[] = intval($item['id']);
            }

            // 检查用户是否选择了该强制分组中的任意标签
            $navgbt_has_selected = !empty(array_intersect($navgbt_submitted_ids, $navgbt_group_item_ids));
            if (!$navgbt_has_selected) {
                message(-1, lang('navgcn_board_tag_forced_required', array('group_name' => $group['name'])));
            }
        }
    }
}