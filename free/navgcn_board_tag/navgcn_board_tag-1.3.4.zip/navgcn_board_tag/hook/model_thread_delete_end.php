<?php exit;
// XIUNOX 版块自定义标签插件 - 帖子删除后清理标签关联
if (!empty($tid)) {
    BoardTagService::onThreadDelete($tid);
}