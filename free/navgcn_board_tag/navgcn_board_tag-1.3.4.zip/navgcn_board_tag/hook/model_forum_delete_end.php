<?php exit;
// XIUNOX 版块自定义标签插件 - 版块删除后清理标签配置
if (!empty($fid)) {
    BoardTagService::onForumDelete($fid);
}