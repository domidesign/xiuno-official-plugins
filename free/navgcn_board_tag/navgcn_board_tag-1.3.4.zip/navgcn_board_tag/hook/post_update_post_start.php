<?php exit;
// XIUNOX 版块自定义标签插件 - 编辑帖子时同步标签
if (!empty($isfirst) && !empty($tid) && !empty($fid)) {
    $navgbt_tags_input = param('navgbt_tags', '');
    if (empty($navgbt_tags_input)) {
        $navgbt_tags_input = param('navgbt_tags_m', '');
    }
    $navgbt_tag_ids = array();
    if (!empty($navgbt_tags_input)) {
        $navgbt_tag_ids = array_filter(array_map('intval', explode(',', $navgbt_tags_input)));
    }
    BoardTagService::syncThreadTags($tid, $fid, $navgbt_tag_ids);
}