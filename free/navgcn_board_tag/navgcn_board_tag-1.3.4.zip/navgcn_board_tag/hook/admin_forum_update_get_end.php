<?php exit;
/*
    XIUNOX 版块自定义标签插件 - 版块编辑页：加载标签数据
    仅在 config_mode === 'board_edit' 时生效
*/
// 注意：此处必须用插件专属变量名 $navgbtSettings，绝不能用通用的 $settings。
// 原因同 admin_forum_update_privilete_after.htm：hook 编译内联后与主页面同处一个 include 作用域，
// 通用 $settings 会覆盖主页面模板依赖的 $settings，导致该页其他设置项渲染丢失。
$navgbtSettings = BoardTagService::getSettings();
if (($navgbtSettings['config_mode'] ?? 'standalone') === 'board_edit') {
    $navgbt_board_groups = BoardTagService::getGroups($_fid);
    $navgbt_board_items = array();
    foreach ($navgbt_board_groups as $group) {
        $navgbt_board_items[$group['id']] = BoardTagService::getItemsByGroup($group['id']);
    }
    // 颜色选项
    $navgbt_color_options = array(
        '' => '默认',
        'primary' => '蓝色',
        'secondary' => '灰色',
        'success' => '绿色',
        'danger' => '红色',
        'warning' => '黄色',
        'info' => '青色',
        'dark' => '深色',
        'indigo' => '靛青',
        'purple' => '紫色',
        'pink' => '粉色',
        'teal' => '青绿',
        'orange' => '橙色',
    );
}