<?php exit;
APP_PATH.'plugin/navgcn_board_tag/model/BoardTagService.php',