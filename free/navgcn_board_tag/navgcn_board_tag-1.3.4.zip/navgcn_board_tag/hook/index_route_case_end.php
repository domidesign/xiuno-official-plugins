<?php
// XIUNOX 版块自定义标签插件 - 路由注册
case 'board_tag':
	include APP_PATH.'plugin/navgcn_board_tag/route/board_tag.php';
	break;