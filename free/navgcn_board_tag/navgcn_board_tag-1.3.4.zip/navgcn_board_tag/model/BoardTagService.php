<?php
/*
    XIUNOX 版块自定义标签插件 - BoardTagService 服务类
    提供标签分组/标签项的增删改查、帖子关联管理、前端数据供给
*/

!defined('DEBUG') AND exit('Forbidden');

class BoardTagService {

    private static $cacheKeys = array(
        'board_tags' => array(300, '版块标签配置'),
        'thread_tags' => array(300, '帖子标签'),
    );

    public static function initCache() {
        if (class_exists('CacheHelper', false)) {
            CacheHelper::registerKeys('navgcn_board_tag', self::$cacheKeys);
        }
    }

    // ==================== 设置 ====================

    public static function getSettings() {
        $settings = setting_get('navgcn_board_tag');
        if (empty($settings)) {
            $settings = array(
                'max_list_display' => 3,
                'show_in_thread' => 1,
                'show_in_list' => 1,
                'config_mode' => 'standalone',
            );
        }
        return $settings;
    }

    public static function saveSettings($arr) {
        return setting_set('navgcn_board_tag', $arr);
    }

    // ==================== 分组管理 ====================

    public static function getGroups($fid) {
        $fid = intval($fid);
        if ($fid <= 0) return array();
        // 增加 id 兜底：sort 相同时回退到创建顺序，杜绝撞号导致的乱序
        return db_find('navgcn_board_tag_group', array('fid' => $fid), array('sort' => 1, 'id' => 1), 1, 1000);
    }

    public static function getGroupById($id) {
        return db_find_one('navgcn_board_tag_group', array('id' => $id));
    }

    public static function createGroup($fid, $name, $sort = 0, $selectMode = 0, $enabled = 1, $forced = 0) {
        global $time;
        $fid = intval($fid);
        $name = trim($name);
        if (empty($name) || $fid <= 0) return false;

        // 自动分配排序：若未指定排序值，取当前版块最大 sort + 1
        $sort = intval($sort);
        if ($sort <= 0) {
            $maxGroup = db_find_one('navgcn_board_tag_group', array('fid' => $fid), array('sort' => -1));
            $sort = $maxGroup ? intval($maxGroup['sort']) + 1 : 1;
        }

        $arr = array(
            'fid' => $fid,
            'name' => $name,
            'sort' => $sort,
            'select_mode' => intval($selectMode) ? 1 : 0,
            'enabled' => intval($enabled) ? 1 : 0,
            'forced' => intval($forced) ? 1 : 0,
            'create_time' => $time,
        );
        $r = db_insert('navgcn_board_tag_group', $arr);
        if ($r !== false) {
            self::clearBoardCache($fid);
        }
        return $r;
    }

    public static function updateGroup($id, $arr) {
        $id = intval($id);
        $group = self::getGroupById($id);
        if (empty($group)) return false;

        $r = db_update('navgcn_board_tag_group', array('id' => $id), $arr);
        if ($r !== false) {
            self::clearBoardCache($group['fid']);
        }
        return $r;
    }

    public static function deleteGroup($id) {
        $id = intval($id);
        $group = self::getGroupById($id);
        if (empty($group)) return false;

        // 先删除该分组下的所有标签项
        $items = self::getItemsByGroup($id);
        foreach ($items as $item) {
            self::deleteItem($item['id'], false);
        }

        $r = db_delete('navgcn_board_tag_group', array('id' => $id));
        if ($r !== false) {
            self::clearBoardCache($group['fid']);
        }
        return $r;
    }

    public static function moveGroupUp($id) {
        $id = intval($id);
        $group = self::getGroupById($id);
        if (empty($group)) return false;

        $fid = intval($group['fid']);
        $currentSort = intval($group['sort']);

        // 找到上一个分组（sort 小于当前且最大的）
        $prev = db_find_one('navgcn_board_tag_group',
            array('fid' => $fid, 'sort' => array('<' => $currentSort)),
            array('sort' => -1));
        if (empty($prev)) return false;

        // 交换 sort
        db_update('navgcn_board_tag_group', array('id' => $id), array('sort' => intval($prev['sort'])));
        db_update('navgcn_board_tag_group', array('id' => $prev['id']), array('sort' => $currentSort));
        self::clearBoardCache($fid);
        return true;
    }

    public static function moveGroupDown($id) {
        $id = intval($id);
        $group = self::getGroupById($id);
        if (empty($group)) return false;

        $fid = intval($group['fid']);
        $currentSort = intval($group['sort']);

        // 找到下一个分组（sort 大于当前且最小的）
        $next = db_find_one('navgcn_board_tag_group',
            array('fid' => $fid, 'sort' => array('>' => $currentSort)),
            array('sort' => 1));
        if (empty($next)) return false;

        // 交换 sort
        db_update('navgcn_board_tag_group', array('id' => $id), array('sort' => intval($next['sort'])));
        db_update('navgcn_board_tag_group', array('id' => $next['id']), array('sort' => $currentSort));
        self::clearBoardCache($fid);
        return true;
    }

    // ==================== 标签项管理 ====================

    public static function getItemsByGroup($groupId) {
        $groupId = intval($groupId);
        if ($groupId <= 0) return array();
        // 增加 id 兜底：sort 相同时回退到创建顺序，杜绝撞号导致的乱序
        return db_find('navgcn_board_tag_item', array('group_id' => $groupId), array('sort' => 1, 'id' => 1), 1, 1000);
    }

    public static function getItemById($id) {
        return db_find_one('navgcn_board_tag_item', array('id' => $id));
    }

    public static function createItem($groupId, $name, $sort = 0, $color = '', $enabled = 1, $isDefault = 0) {
        global $time;
        $groupId = intval($groupId);
        $name = trim($name);
        if (empty($name) || $groupId <= 0) return false;

        // 自动分配排序：若未指定排序值，取当前分组最大 sort + 1
        $sort = intval($sort);
        if ($sort <= 0) {
            $maxItem = db_find_one('navgcn_board_tag_item', array('group_id' => $groupId), array('sort' => -1));
            $sort = $maxItem ? intval($maxItem['sort']) + 1 : 1;
        }

        $arr = array(
            'group_id' => $groupId,
            'name' => $name,
            'sort' => $sort,
            'color' => trim($color),
            'enabled' => intval($enabled) ? 1 : 0,
            'is_default' => intval($isDefault) ? 1 : 0,
            'create_time' => $time,
        );
        $r = db_insert('navgcn_board_tag_item', $arr);
        if ($r !== false) {
            $group = self::getGroupById($groupId);
            if (!empty($group)) {
                self::clearBoardCache($group['fid']);
            }
        }
        return $r;
    }

    public static function updateItem($id, $arr) {
        $id = intval($id);
        $item = self::getItemById($id);
        if (empty($item)) return false;

        $r = db_update('navgcn_board_tag_item', array('id' => $id), $arr);
        if ($r !== false) {
            $group = self::getGroupById($item['group_id']);
            if (!empty($group)) {
                self::clearBoardCache($group['fid']);
            }
        }
        return $r;
    }

    public static function deleteItem($id, $clearCache = true) {
        $id = intval($id);
        $item = self::getItemById($id);
        if (empty($item)) return false;

        // 删除关联
        db_delete('navgcn_board_tag_thread', array('tag_id' => $id));
        $r = db_delete('navgcn_board_tag_item', array('id' => $id));

        if ($r !== false && $clearCache) {
            $group = self::getGroupById($item['group_id']);
            if (!empty($group)) {
                self::clearBoardCache($group['fid']);
            }
        }
        return $r;
    }

    public static function moveItemUp($id) {
        $id = intval($id);
        $item = self::getItemById($id);
        if (empty($item)) return false;

        $groupId = intval($item['group_id']);
        $currentSort = intval($item['sort']);

        // 找到上一个标签项（sort 小于当前且最大的）
        $prev = db_find_one('navgcn_board_tag_item',
            array('group_id' => $groupId, 'sort' => array('<' => $currentSort)),
            array('sort' => -1));
        if (empty($prev)) return false;

        // 交换 sort
        db_update('navgcn_board_tag_item', array('id' => $id), array('sort' => intval($prev['sort'])));
        db_update('navgcn_board_tag_item', array('id' => $prev['id']), array('sort' => $currentSort));

        $group = self::getGroupById($groupId);
        if (!empty($group)) {
            self::clearBoardCache($group['fid']);
        }
        return true;
    }

    public static function moveItemDown($id) {
        $id = intval($id);
        $item = self::getItemById($id);
        if (empty($item)) return false;

        $groupId = intval($item['group_id']);
        $currentSort = intval($item['sort']);

        // 找到下一个标签项（sort 大于当前且最小的）
        $next = db_find_one('navgcn_board_tag_item',
            array('group_id' => $groupId, 'sort' => array('>' => $currentSort)),
            array('sort' => 1));
        if (empty($next)) return false;

        // 交换 sort
        db_update('navgcn_board_tag_item', array('id' => $id), array('sort' => intval($next['sort'])));
        db_update('navgcn_board_tag_item', array('id' => $next['id']), array('sort' => $currentSort));

        $group = self::getGroupById($groupId);
        if (!empty($group)) {
            self::clearBoardCache($group['fid']);
        }
        return true;
    }

    // ==================== 版块标签配置获取（前端用） ====================

    /**
     * 获取版块的完整标签配置（分组+标签项，含缓存）
     * @param int $fid 版块ID
     * @return array [['group'=>..., 'items'=>[...]], ...]
     */
    public static function getBoardTagConfig($fid) {
        $fid = intval($fid);
        if ($fid <= 0) return array();

        self::initCache();
        return CacheHelper::remember('board_tags_' . $fid, 300, function() use ($fid) {
            // 增加 id 兜底：sort 相同时回退到创建顺序，杜绝撞号导致的乱序
            $groups = db_find('navgcn_board_tag_group', array('fid' => $fid), array('sort' => 1, 'id' => 1), 1, 1000);
            if (empty($groups)) return array();

            $result = array();
            foreach ($groups as $group) {
                // 仅返回启用的分组
                if (empty($group['enabled'])) continue;
                // 增加 id 兜底
                $items = db_find('navgcn_board_tag_item', array('group_id' => $group['id']), array('sort' => 1, 'id' => 1), 1, 1000);
                // 仅返回启用的标签项
                $enabledItems = array();
                if ($items) {
                    foreach ($items as $item) {
                        if (!empty($item['enabled'])) {
                            $enabledItems[] = $item;
                        }
                    }
                }
                $result[] = array(
                    'group' => $group,
                    'items' => $enabledItems,
                );
            }
            return $result;
        }, 'navgcn_board_tag');
    }

    /**
     * 获取版块下所有标签项ID列表（用于校验）
     */
    public static function getBoardTagIds($fid) {
        $config = self::getBoardTagConfig($fid);
        $ids = array();
        foreach ($config as $groupData) {
            foreach ($groupData['items'] as $item) {
                $ids[] = intval($item['id']);
            }
        }
        return $ids;
    }

    // ==================== 帖子标签关联 ====================

    /**
     * 获取帖子关联的标签列表
     */
    public static function getThreadTags($tid) {
        $tid = intval($tid);
        if ($tid <= 0) return array();

        self::initCache();
        return CacheHelper::remember('thread_tags_' . $tid, 300, function() use ($tid) {
            global $db;
            $tablepre = $db->tablepre;
            // 联表查询获取标签详情，保留 db_sql_find
            // 排序：先按分组顺序(g.sort)，再按组内顺序(i.sort)，最后按 id 兜底
            // —— 这样前台帖子页展示的标签与后台「每个组里的标签按顺序」的层级完全一致，
            //    避免跨分组标签仅按 item.sort 全局排序导致不同组的标签交错穿插（看起来乱序）
            $sql = "SELECT i.* FROM {$tablepre}navgcn_board_tag_thread t
                    INNER JOIN {$tablepre}navgcn_board_tag_item i ON t.tag_id = i.id
                    INNER JOIN {$tablepre}navgcn_board_tag_group g ON i.group_id = g.id
                    WHERE t.tid = {$tid}
                    ORDER BY g.sort ASC, i.sort ASC, i.id ASC";
            $rows = db_sql_find($sql);
            return $rows ? $rows : array();
        }, 'navgcn_board_tag');
    }

    /**
     * 批量获取帖子标签（列表页用）
     * @param array $tids
     * @return array tid => [tag1, tag2, ...]
     */
    public static function getThreadTagsBatch($tids) {
        if (empty($tids)) return array();

        global $db;
        $tablepre = $db->tablepre;
        $tidList = implode(',', array_map('intval', $tids));
        // 联表查询，保留 db_sql_find
        $sql = "SELECT t.tid, i.* FROM {$tablepre}navgcn_board_tag_thread t
                INNER JOIN {$tablepre}navgcn_board_tag_item i ON t.tag_id = i.id
                INNER JOIN {$tablepre}navgcn_board_tag_group g ON i.group_id = g.id
                WHERE t.tid IN ({$tidList})
                ORDER BY g.sort ASC, i.sort ASC, i.id ASC";
        $rows = db_sql_find($sql);

        $result = array();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $tid = $row['tid'];
                if (!isset($result[$tid])) $result[$tid] = array();
                $result[$tid][] = $row;
            }
        }
        return $result;
    }

    /**
     * 同步帖子标签关联
     * @param int $tid
     * @param int $fid 版块ID（用于校验）
     * @param array $tagIds 标签ID数组
     */
    public static function syncThreadTags($tid, $fid, $tagIds) {
        $tid = intval($tid);
        $fid = intval($fid);
        if ($tid <= 0) return false;

        // 校验标签是否属于当前版块
        $validIds = self::getBoardTagIds($fid);
        $tagIds = array_intersect(array_map('intval', $tagIds), $validIds);

        // 获取当前关联
        $currentTags = db_find('navgcn_board_tag_thread', array('tid' => $tid), array(), 1, 100);
        $currentIds = array();
        foreach ($currentTags as $t) {
            $currentIds[] = intval($t['tag_id']);
        }

        // 需要新增的
        $toAdd = array_diff($tagIds, $currentIds);
        foreach ($toAdd as $tagId) {
            db_insert('navgcn_board_tag_thread', array('tag_id' => $tagId, 'tid' => $tid));
        }

        // 需要删除的
        $toRemove = array_diff($currentIds, $tagIds);
        foreach ($toRemove as $tagId) {
            db_delete('navgcn_board_tag_thread', array('tag_id' => $tagId, 'tid' => $tid));
        }

        // 清除帖子标签缓存
        if (class_exists('CacheHelper', false)) {
            CacheHelper::delete(CacheHelper::pluginKey('thread_tags_' . $tid, 'navgcn_board_tag'));
        }

        return true;
    }

    /**
     * 删除帖子时清理标签关联
     */
    public static function onThreadDelete($tid) {
        $tid = intval($tid);
        db_delete('navgcn_board_tag_thread', array('tid' => $tid));
        if (class_exists('CacheHelper', false)) {
            CacheHelper::delete(CacheHelper::pluginKey('thread_tags_' . $tid, 'navgcn_board_tag'));
        }
    }

    /**
     * 删除版块时清理标签配置和关联
     */
    public static function onForumDelete($fid) {
        $fid = intval($fid);
        $groups = self::getGroups($fid);
        foreach ($groups as $group) {
            $items = self::getItemsByGroup($group['id']);
            foreach ($items as $item) {
                db_delete('navgcn_board_tag_thread', array('tag_id' => $item['id']));
            }
            db_delete('navgcn_board_tag_item', array('group_id' => $group['id']));
        }
        db_delete('navgcn_board_tag_group', array('fid' => $fid));
        self::clearBoardCache($fid);
    }

    // ==================== 标签筛选页 ====================

    /**
     * 获取标签下的帖子列表
     */
    public static function getThreadsByTagId($tagId, $page = 1, $pagesize = 20) {
        global $db;
        $tablepre = $db->tablepre;
        $tagId = intval($tagId);
        $offset = ($page - 1) * $pagesize;

        // 联表查询统计总数，保留 db_sql_find
        $countSql = "SELECT COUNT(*) as cnt FROM {$tablepre}navgcn_board_tag_thread tt
                     INNER JOIN {$tablepre}thread t ON tt.tid = t.tid
                     WHERE tt.tag_id = {$tagId} AND t.is_deleted = 0";
        $countRow = db_sql_find_one($countSql);
        $total = !empty($countRow['cnt']) ? intval($countRow['cnt']) : 0;

        // 联表查询帖子，保留 db_sql_find
        $sql = "SELECT t.* FROM {$tablepre}navgcn_board_tag_thread tt
                INNER JOIN {$tablepre}thread t ON tt.tid = t.tid
                WHERE tt.tag_id = {$tagId} AND t.is_deleted = 0
                ORDER BY t.tid DESC
                LIMIT {$offset}, {$pagesize}";
        $threadlist = db_sql_find($sql);

        return array('list' => $threadlist ? $threadlist : array(), 'total' => $total);
    }

    // ==================== 缓存 ====================

    public static function clearBoardCache($fid) {
        if (class_exists('CacheHelper', false)) {
            CacheHelper::delete(CacheHelper::pluginKey('board_tags_' . intval($fid), 'navgcn_board_tag'));
        }
    }

    // ==================== 渲染 ====================

    /**
     * 渲染标签徽章HTML
     * @param array $tags 标签数组
     * @param int $maxShow 最多显示几个（列表页用，0表示全部显示）
     * @return string HTML
     */
    public static function renderBadges($tags, $maxShow = 0) {
        if (empty($tags)) return '';

        $html = '';
        $count = count($tags);
        $showTags = $maxShow > 0 ? array_slice($tags, 0, $maxShow) : $tags;

        foreach ($showTags as $tag) {
            $color = !empty($tag['color']) ? $tag['color'] : 'primary';
            $html .= '<a href="' . route_url('board_tag', array('tag_id' => $tag['id'])) . '" class="badge bg-' . esc_attr($color) . ' bg-opacity-10 text-' . esc_attr($color) . ' text-decoration-none me-1" style="font-size:0.75rem;font-weight:500;">'
                . esc_html($tag['name']) . '</a>';
        }

        if ($maxShow > 0 && $count > $maxShow) {
            $remaining = $count - $maxShow;
            $html .= '<span class="badge bg-secondary bg-opacity-10 text-secondary" style="font-size:0.75rem;">+' . $remaining . '</span>';
        }

        return $html;
    }
}