<?php
/*
    XIUNOX 版块自定义标签插件 - 版块编辑页：加载标签数据
    仅在 config_mode === 'board_edit' 时生效
*/
$settings = BoardTagService::getSettings();
if (($settings['config_mode'] ?? 'standalone') === 'board_edit') {
    $navgbt_board_groups = BoardTagService::getGroups($_fid);
    $navgbt_board_items = array();
    foreach ($navgbt_board_groups as $group) {
        $navgbt_board_items[$group['id']] = BoardTagService::getItemsByGroup($group['id']);
    }
    // 颜色选项
    $navgbt_color_options = array(
        '' => '默认',
        'primary' => '蓝色',
        'secondary' => '灰色',
        'success' => '绿色',
        'danger' => '红色',
        'warning' => '黄色',
        'info' => '青色',
        'dark' => '深色',
        'indigo' => '靛青',
        'purple' => '紫色',
        'pink' => '粉色',
        'teal' => '青绿',
        'orange' => '橙色',
    );
}