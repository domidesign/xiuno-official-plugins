/**
 * 版块自定义标签插件 - 前端交互逻辑
 * 依赖：XN (xiuno-modern.js), Bootstrap 5
 */
var BoardTag = (function() {
    var options = {};
    var selectedFid = 0;
    var selectedTags = [];
    var apiUrl = '';

    function init(opts) {
        options = opts || {};
        apiUrl = options.apiUrl || '';
        selectedFid = options.existingFid || 0;
        selectedTags = options.existingTags || [];

        // 发帖页：绑定版块选择器
        if (!options.isEdit) {
            bindBoardSelectors();
        }

        // 编辑页：直接加载标签
        if (options.isEdit && selectedFid > 0) {
            loadTags(selectedFid);
        }

        // 发帖页：如果有预设版块，加载标签
        if (!options.isEdit && selectedFid > 0) {
            highlightBoard(selectedFid);
            loadTags(selectedFid);
        }
    }

    function bindBoardSelectors() {
        document.querySelectorAll('.navgbt-board-item').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var fid = parseInt(this.getAttribute('data-fid'));
                selectBoard(fid, '.navgbt-board-item');
            });
        });

        document.querySelectorAll('.navgbt-board-item-m').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var fid = parseInt(this.getAttribute('data-fid'));
                selectBoard(fid, '.navgbt-board-item-m');
            });
        });
    }

    function selectBoard(fid, selector) {
        if (selectedFid === fid) return;
        selectedFid = fid;
        selectedTags = [];

        document.querySelectorAll(selector).forEach(function(btn) {
            var btnFid = parseInt(btn.getAttribute('data-fid'));
            btn.classList.toggle('active', btnFid === fid);
        });

        var fidSelect = document.querySelector('select[name="fid"]');
        if (fidSelect) {
            fidSelect.value = fid;
            fidSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }

        syncBoardHighlight(fid, selector);
        loadTags(fid);
    }

    function syncBoardHighlight(fid, sourceSelector) {
        var targetSelector = sourceSelector === '.navgbt-board-item' ? '.navgbt-board-item-m' : '.navgbt-board-item';
        document.querySelectorAll(targetSelector).forEach(function(btn) {
            var btnFid = parseInt(btn.getAttribute('data-fid'));
            btn.classList.toggle('active', btnFid === fid);
        });
    }

    function highlightBoard(fid) {
        document.querySelectorAll('.navgbt-board-item, .navgbt-board-item-m').forEach(function(btn) {
            var btnFid = parseInt(btn.getAttribute('data-fid'));
            if (btnFid === fid) {
                btn.classList.add('active');
            }
        });
    }

    function setStatusMessage(el, iconClass, text) {
        el.textContent = '';
        var div = document.createElement('div');
        div.className = 'text-body-secondary small py-2';
        var icon = document.createElement('i');
        icon.className = iconClass + ' me-1';
        div.appendChild(icon);
        div.appendChild(document.createTextNode(text));
        el.appendChild(div);
    }

    function loadTags(fid) {
        if (fid <= 0) {
            showPlaceholder();
            return;
        }

        var containers = ['#navgbt-tag-container', '#navgbt-tag-container-m'];
        containers.forEach(function(c) {
            var el = document.querySelector(c);
            if (el) {
                setStatusMessage(el, 'ti ti-loader', window._navgbt_loading || '加载中...');
            }
        });

        var url = apiUrl;
        var sep = url.indexOf('?') >= 0 ? '&' : '?';
        fetch(url + sep + 'action=config&fid=' + fid)
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.code === 0 && res.data && res.data.length > 0) {
                    renderTags(res.data);
                    restoreSelectedTags();
                } else {
                    showNoTags();
                }
            })
            .catch(function() {
                showNoTags();
            });
    }

    function renderTags(config) {
        var containers = document.querySelectorAll('#navgbt-tag-container, #navgbt-tag-container-m');
        containers.forEach(function(el) {
            el.textContent = '';
            config.forEach(function(groupData) {
                var group = groupData.group;
                var items = groupData.items;
                if (!items || items.length === 0) return;

                var groupDiv = document.createElement('div');
                groupDiv.className = 'navgbt-tag-group';

                var nameDiv = document.createElement('div');
                nameDiv.className = 'navgbt-tag-group-name';
                nameDiv.textContent = group.name;
                if (group.forced) {
                    var forcedSpan = document.createElement('span');
                    forcedSpan.className = 'text-danger small';
                    forcedSpan.textContent = '*必选';
                    nameDiv.appendChild(document.createTextNode(' '));
                    nameDiv.appendChild(forcedSpan);
                }
                if (group.select_mode == 1) {
                    var multiSpan = document.createElement('span');
                    multiSpan.className = 'text-info ms-1';
                    multiSpan.style.fontSize = '0.65rem';
                    multiSpan.textContent = '(多选)';
                    nameDiv.appendChild(multiSpan);
                }
                groupDiv.appendChild(nameDiv);

                var itemsDiv = document.createElement('div');
                itemsDiv.className = 'navgbt-tag-items';
                items.forEach(function(item) {
                    var btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'navgbt-tag-btn';
                    if (item.color) {
                        btn.classList.add('navgbt-tag-' + item.color);
                    }
                    btn.setAttribute('data-tag-id', item.id);
                    btn.setAttribute('data-group-id', group.id);
                    btn.setAttribute('data-select-mode', group.select_mode);
                    if (item.is_default) {
                        btn.setAttribute('data-default', '1');
                    }
                    btn.textContent = item.name;
                    itemsDiv.appendChild(btn);
                });
                groupDiv.appendChild(itemsDiv);
                el.appendChild(groupDiv);
            });
        });

        bindTagClicks();
        applyDefaultTags();
    }

    function applyDefaultTags() {
        // 自动选中标记为默认的标签（多选分组可全选，单选分组只选第一个）
        var groupDefaults = {};
        document.querySelectorAll('.navgbt-tag-btn[data-default="1"]').forEach(function(btn) {
            var tagId = parseInt(btn.getAttribute('data-tag-id'));
            var groupId = parseInt(btn.getAttribute('data-group-id'));
            var selectMode = parseInt(btn.getAttribute('data-select-mode'));
            if (selectMode === 0) {
                // 单选分组：只保留第一个默认标签
                if (!(groupId in groupDefaults)) {
                    groupDefaults[groupId] = tagId;
                }
            } else {
                // 多选分组：可全选
                if (selectedTags.indexOf(tagId) === -1) {
                    selectedTags.push(tagId);
                }
            }
        });
        // 添加单选分组的默认标签
        for (var gid in groupDefaults) {
            if (groupDefaults.hasOwnProperty(gid)) {
                if (selectedTags.indexOf(groupDefaults[gid]) === -1) {
                    selectedTags.push(groupDefaults[gid]);
                }
            }
        }
        updateTagUI();
    }

    function showPlaceholder() {
        var containers = document.querySelectorAll('#navgbt-tag-container, #navgbt-tag-container-m');
        containers.forEach(function(el) {
            setStatusMessage(el, 'ti ti-tag-plus', '选择标签 +');
        });
    }

    function showNoTags() {
        var containers = document.querySelectorAll('#navgbt-tag-container, #navgbt-tag-container-m');
        containers.forEach(function(el) {
            setStatusMessage(el, 'ti ti-info-circle', '当前版块暂未配置标签');
        });
    }

    function bindTagClicks() {
        document.querySelectorAll('.navgbt-tag-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var tagId = parseInt(this.getAttribute('data-tag-id'));
                var groupId = parseInt(this.getAttribute('data-group-id'));
                var selectMode = parseInt(this.getAttribute('data-select-mode'));

                if (selectMode === 0) {
                    toggleSingleTag(tagId, groupId);
                } else {
                    toggleMultiTag(tagId, groupId);
                }
            });
        });
    }

    function toggleSingleTag(tagId, groupId) {
        var isCurrentlySelected = selectedTags.indexOf(tagId) !== -1;

        selectedTags = selectedTags.filter(function(id) {
            var btn = document.querySelector('[data-tag-id="' + id + '"]');
            if (btn && parseInt(btn.getAttribute('data-group-id')) === groupId) {
                return false;
            }
            return true;
        });

        if (!isCurrentlySelected) {
            selectedTags.push(tagId);
        }

        updateTagUI();
    }

    function toggleMultiTag(tagId, groupId) {
        var idx = selectedTags.indexOf(tagId);
        if (idx !== -1) {
            selectedTags.splice(idx, 1);
        } else {
            selectedTags.push(tagId);
        }
        updateTagUI();
    }

    function updateTagUI() {
        document.querySelectorAll('.navgbt-tag-btn').forEach(function(btn) {
            var tid = parseInt(btn.getAttribute('data-tag-id'));
            btn.classList.toggle('active', selectedTags.indexOf(tid) !== -1);
        });

        var tagsStr = selectedTags.join(',');
        var hiddenInputs = document.querySelectorAll('#navgbt-tags-hidden, #navgbt-tags-hidden-m');
        hiddenInputs.forEach(function(el) {
            el.value = tagsStr;
        });
    }

    function restoreSelectedTags() {
        if (selectedTags.length > 0) {
            updateTagUI();
        }
    }

    return {
        init: init
    };
})();