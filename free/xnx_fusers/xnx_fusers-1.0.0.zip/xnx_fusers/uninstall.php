<?php
!defined('DEBUG') AND exit('Access Denied');
if (class_exists('CacheHelper', false)) {
    CacheHelper::pluginDeletePrefix('xnx_fusers');
}
