# xnx_fusers 版块成员展示插件

## 功能
- 在版块页面右侧栏展示关注该版块的成员（头像 + 用户名上下结构）
- 展示数量默认 12 个，超过时显示「查看全部（N）」链接
- 头像点击跳转用户主页
- 缓存机制：基于 CacheHelper::remember，TTL 300s，按 fid 分键
- 批量预加载用户信息避免 N+1（user_find_by_uids）
- 总数取自 forum.follows 字段（核心维护的关注计数）

## 文件结构
```
plugin/xnx_fusers/
├── conf.json
├── install.php / uninstall.php
├── model/
│   └── FusersService.php         # 服务类（getMembers + 缓存注册）
├── hook/
│   ├── model_inc_file.php
│   ├── forum_mod_after.htm       # 在版块页右栏版主信息卡之后注入
│   ├── lang_zh_cn_bbs.php
│   ├── lang_zh_tw_bbs.php
│   └── lang_en_us_bbs.php
└── view/htm/
    └── fusers_block.htm          # 成员区块模板
```

## 配置流程
1. 后台启用插件（无独立设置页）
2. 测试：访问任意版块页面，右栏应出现「版块成员（N）」卡片，展示关注该版块的用户头像
3. 注意：关注/取消关注后最多 5 分钟缓存延迟更新（核心无 hook 注入点，无法实时清缓存）
