<?php exit;
APP_PATH.'plugin/xnx_fusers/model/FusersService.php',
