<?php exit;
$lang['xnx_fusers_members'] = 'Forum Members';
$lang['xnx_fusers_view_all'] = 'View All';
$lang['xnx_fusers_no_members'] = 'No members yet';
