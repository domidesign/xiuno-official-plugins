<?php exit;
$lang['xnx_fusers_members'] = '本版成员';
$lang['xnx_fusers_view_all'] = '查看全部';
$lang['xnx_fusers_no_members'] = '暂无成员';
