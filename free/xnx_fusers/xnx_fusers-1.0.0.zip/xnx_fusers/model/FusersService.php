<?php
!defined('DEBUG') AND exit('Access Denied');

class FusersService {
    // 缓存键清单（后台统计面板依赖）
    private static $cacheKeys = array(
        'list_' => array(300, '版块成员列表'),
    );

    public static function init() {
        if (class_exists('CacheHelper', false)) {
            CacheHelper::registerKeys('xnx_fusers', self::$cacheKeys);
        }
    }

    // ponytail: 缓存 TTL 300s，关注/取消关注后最多 5 分钟延迟更新。
    // 核心 ForumService::followForum/unfollowForum 无 hook 注入点，无法实时清缓存。
    // 升级路径：未来在核心加 hook 后改为实时清理。
    public static function getMembers($fid, $limit = 12) {
        $fid = intval($fid);
        if ($fid <= 0) return array('list' => array(), 'total' => 0);

        return CacheHelper::remember('list_'.$fid, 300, function() use ($fid, $limit) {
            $follows = forum_follow_find_by_fid($fid, 1, $limit);
            $list = array();
            if (!empty($follows)) {
                $uids = array();
                foreach ($follows as $f) {
                    $uid = intval($f['uid']);
                    if ($uid > 0) $uids[$uid] = $uid;
                }
                if (!empty($uids)) {
                    $users_map = user_find_by_uids(implode(',', $uids));
                    foreach ($follows as $f) {
                        $uid = intval($f['uid']);
                        if (!isset($users_map[$uid])) continue;
                        $u = $users_map[$uid];
                        $list[] = array(
                            'uid' => $u['uid'],
                            'display_name' => !empty($u['display_name']) ? $u['display_name'] : $u['username'],
                            'avatar_url' => !empty($u['avatar_url']) ? $u['avatar_url'] : default_avatar_url(),
                        );
                    }
                }
            }
            $forum = forum_read($fid);
            $total = !empty($forum['follows']) ? intval($forum['follows']) : 0;
            return array('list' => $list, 'total' => $total);
        }, 'xnx_fusers');
    }
}

// 注册缓存键
FusersService::init();
