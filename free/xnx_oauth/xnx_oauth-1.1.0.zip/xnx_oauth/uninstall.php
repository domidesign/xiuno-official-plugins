<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;

// 删除 OAuth 绑定关系表
$sql = "DROP TABLE IF EXISTS `" . $tablepre . "xnx_oauth_bind`";
// DDL 建表/删表，保留 db_exec
db_exec($sql);

// 删除插件配置
setting_delete('xnx_oauth');

?>
