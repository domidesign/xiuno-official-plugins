<?php exit;
APP_PATH.'plugin/xnx_oauth/model/OAuthService.php',
