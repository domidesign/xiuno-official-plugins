<?php exit;
$routes['oauth_login'] = 'oauth-login-{provider}';
$routes['oauth_callback'] = 'oauth-callback-{provider}';
$routes['oauth_unbind'] = 'oauth-unbind-{provider}';
$routes['oauth_bind_manage'] = 'oauth-bind-manage';
