<?php exit;
case 'oauth': include APP_PATH.'plugin/xnx_oauth/route/oauth.php'; break;
