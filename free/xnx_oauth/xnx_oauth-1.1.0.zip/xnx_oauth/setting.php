<?php
!defined('DEBUG') AND exit('Access Denied');

// 后台权限校验：仅管理员组（gid=1,2）可访问
if (empty($uid) || $gid > 2) {
    message(-1, lang('oauth_admin_no_permission'));
}

// 引入 OAuthService
// ponytail: model.inc.php 的 model_inc_file.php hook 已通过 _include() 编译到 tmp/ 加载 OAuthService，
// 编译产物路径 (tmp/plugin_xnx_oauth_model_OAuthService.php) 与源文件路径不同，include_once 无法去重会触发类重声明。
// 用 class_exists 守卫：插件启用时类已存在跳过；插件禁用时（tmp 缓存不含此 hook）才 include 源文件。
if (!class_exists('OAuthService', false)) {
	include_once APP_PATH . 'plugin/xnx_oauth/model/OAuthService.php';
}

/**
 * 获取内置 provider 默认配置（QQ/GitHub/Google 平台固定的技术参数）
 * 后台对内置 provider 只展示 AppID/AppSecret 等用户必填字段，技术参数写死隐藏，
 * 提供「高级设置」折叠区供特殊需求修改。保存时若技术参数为空则用此默认值兜底。
 */
function xnx_oauth_builtin_providers() {
	return array(
		'qq' => array(
			'display_name'  => 'QQ',
			'icon'          => 'ti-brand-qq',
			'color'         => '#12B7F5',
			'authorize_url' => 'https://graph.qq.com/oauth2.0/authorize',
			'token_url'     => 'https://graph.qq.com/oauth2.0/token',
			'userinfo_url'  => 'https://graph.qq.com/user/get_user_info',
			'pre_userinfo_url' => 'https://graph.qq.com/oauth2.0/me',
			'scope'         => 'get_user_info',
			'enable_pkce'   => 0,
			'field_mapping' => array(
				'openid'   => 'openid',
				'nickname' => 'nickname',
				'avatar'   => 'figureurl_qq_2',
				'email'    => '',
				'gender'   => 'gender',
			),
		),
		'github' => array(
			'display_name'  => 'GitHub',
			'icon'          => 'ti-brand-github',
			'color'         => '#181717',
			'authorize_url' => 'https://github.com/login/oauth/authorize',
			'token_url'     => 'https://github.com/login/oauth/access_token',
			'userinfo_url'  => 'https://api.github.com/user',
			'scope'         => 'read:user,user:email',
			'enable_pkce'   => 0,
			'field_mapping' => array(
				'openid'   => 'id',
				'nickname' => 'login',
				'avatar'   => 'avatar_url',
				'email'    => 'email',
				'gender'   => '',
			),
		),
		'google' => array(
			'display_name'  => 'Google',
			'icon'          => 'ti-brand-google',
			'color'         => '#4285F4',
			'authorize_url' => 'https://accounts.google.com/o/oauth2/v2/auth',
			'token_url'     => 'https://oauth2.googleapis.com/token',
			'userinfo_url'  => 'https://www.googleapis.com/oauth2/v3/userinfo',
			'scope'         => 'openid email profile',
			'enable_pkce'   => 1,
			'field_mapping' => array(
				'openid'   => 'sub',
				'nickname' => 'name',
				'avatar'   => 'picture',
				'email'    => 'email',
				'gender'   => '',
			),
		),
		'gitee' => array(
			'display_name'  => 'Gitee',
			'icon'          => 'ti-brand-git',
			'color'         => '#c71d23',
			'authorize_url' => 'https://gitee.com/oauth/authorize',
			'token_url'     => 'https://gitee.com/oauth/token',
			'userinfo_url'  => 'https://gitee.com/api/v5/user',
			'scope'         => 'user_info emails',
			'enable_pkce'   => 0,
			'field_mapping' => array(
				'openid'   => 'id',
				'nickname' => 'name',
				'avatar'   => 'avatar_url',
				'email'    => 'email',
				'gender'   => '',
			),
		),
	);
}

/**
 * 整理单个 provider 的保存数据
 * 对内置 provider，技术参数为空时用默认值兜底（用户没展开高级设置时保留平台默认值）
 * @param string $name provider 名称
 * @param array $p 用户提交的 provider 配置
 * @return array 整理后的 provider 配置
 */
function xnx_oauth_normalize_provider($name, $p) {
	$builtins = xnx_oauth_builtin_providers();
	$builtin = isset($builtins[$name]) ? $builtins[$name] : null;

	// 技术参数：内置 provider 为空时用默认值兜底，自定义 provider 为空就是空
	$authorize_url = trim((string)array_value($p, 'authorize_url', ''));
	$token_url     = trim((string)array_value($p, 'token_url', ''));
	$userinfo_url  = trim((string)array_value($p, 'userinfo_url', ''));
	$scope         = trim((string)array_value($p, 'scope', ''));
	$field_mapping = is_array(array_value($p, 'field_mapping', array())) ? array_value($p, 'field_mapping', array()) : array();

	if ($builtin) {
		if ($authorize_url === '') $authorize_url = $builtin['authorize_url'];
		if ($token_url === '')     $token_url     = $builtin['token_url'];
		if ($userinfo_url === '')  $userinfo_url  = $builtin['userinfo_url'];
		if ($scope === '')         $scope         = $builtin['scope'];
		// 内置 provider 字段映射为空时用默认值
		$empty_mapping = empty($field_mapping) || (count($field_mapping) === 1 && empty(reset($field_mapping)));
		if ($empty_mapping) {
			$field_mapping = $builtin['field_mapping'];
		}
	}

	$normalized = array(
		'name'           => $name,
		'display_name'   => trim((string)array_value($p, 'display_name', '')),
		'icon'           => trim((string)array_value($p, 'icon', '')),
		'color'          => trim((string)array_value($p, 'color', '')),
		'authorize_url'  => $authorize_url,
		'token_url'      => $token_url,
		'userinfo_url'   => $userinfo_url,
		'scope'          => $scope,
		'appid'          => trim((string)array_value($p, 'appid', '')),
		'appkey'         => trim((string)array_value($p, 'appkey', '')),
		'enable'         => !empty($p['enable']) ? 1 : 0,
		'enable_pkce'    => !empty($p['enable_pkce']) ? 1 : 0,
		'field_mapping'  => $field_mapping,
		'is_builtin'     => $builtin ? 1 : 0,
	);

	// 内置 provider 保留 pre_userinfo_url（QQ 专用）
	if ($builtin && !empty($builtin['pre_userinfo_url'])) {
		$normalized['pre_userinfo_url'] = $builtin['pre_userinfo_url'];
	}

	return $normalized;
}

// URL 格式：plugin-setting-xnx_oauth-{sub_action}
// param(1)=setting, param(2)=xnx_oauth, param(3)=sub_action
$sub_action = param(3);
if (empty($sub_action)) {
    $sub_action = 'setting';
}

// ===== POST 请求处理（在 include header 之前，避免 message() 输出 JSON 时混入 HTML）=====
if ($method == 'POST') {
    CsrfService::check();
    $op = param('op', '');

    // ponytail: providers 是二维数组（providers[github][appid]=xxx），
    // xiuno 的 param() 内部 param_force() 对嵌套数组的处理有 bug：
    //   $defval = empty(array()) ? '' : array()[0]  →  $defval = ''
    //   遍历 $val 时 is_array($v) 为 true → $v = $defval = ''  （内层数组被替换成空字符串）
    // 导致所有 provider 字段被清空。必须直接读 $_POST 绕过 param()。
    // AppSecret 等字段可能含 & 等特殊字符，不应 htmlspecialchars 转义，直接用原始值。

    if ($sub_action == 'setting' && $op == 'save_config') {
        // 保存配置
        $enable = intval(param('enable', 0));
        $auto_merge = intval(param('auto_merge_by_email', 0));
        $providers_input = isset($_POST['providers']) ? $_POST['providers'] : array();

        // 整理 provider 配置（内置 provider 技术参数为空时用默认值兜底）
        $providers = array();
        if (is_array($providers_input)) {
            foreach ($providers_input as $name => $p) {
                $name = trim((string)$name);
                if ($name === '') continue;
                if (!is_array($p)) $p = array();
                $providers[$name] = xnx_oauth_normalize_provider($name, $p);
            }
        }

        // 代理配置（中国大陆服务器访问境外 OAuth 端点需要）
        $proxy = array(
            'proxy_host' => trim((string)param('proxy_host', '')),
            'proxy_port' => trim((string)param('proxy_port', '')),
            'proxy_type' => trim((string)param('proxy_type', 'http')),
            'proxy_user' => trim((string)param('proxy_user', '')),
            'proxy_pass' => trim((string)param('proxy_pass', '')),
        );
        // 自动注册开关
        $auto_register = intval(param('auto_register', 0));

        $setting = array(
            'enable'              => $enable,
            'auto_merge_by_email' => $auto_merge,
            'auto_register'       => $auto_register,
            'providers'           => $providers,
        );
        // 合并代理配置（保持向后兼容，旧 setting 无这些字段）
        $setting = array_merge($proxy, $setting);
        setting_set('xnx_oauth', $setting);
        message(0, lang('oauth_admin_save_ok'));

    } elseif ($sub_action == 'setting' && $op == 'save_provider') {
        // 单独保存某个 provider（不修改全局开关 / 其他 provider）
        $provider_name = trim((string)param('provider_name', ''));
        if ($provider_name === '') {
            message(-1, lang('oauth_admin_param_error'));
        }
        $p = isset($_POST['provider']) ? $_POST['provider'] : array();
        if (!is_array($p)) {
            $p = array();
        }

        // 读现有 setting，只覆盖该 provider
        $setting = setting_get('xnx_oauth');
        if (empty($setting) || !is_array($setting)) {
            $setting = array('enable' => 0, 'auto_merge_by_email' => 0, 'providers' => array());
        }
        if (empty($setting['providers']) || !is_array($setting['providers'])) {
            $setting['providers'] = array();
        }

        $setting['providers'][$provider_name] = xnx_oauth_normalize_provider($provider_name, $p);

        setting_set('xnx_oauth', $setting);
        message(0, lang('oauth_admin_provider_saved'));

    } elseif ($sub_action == 'unbind') {
        // 强制解绑
        $id = intval(param('id', 0));
        if ($id <= 0) {
            message(-1, lang('oauth_admin_param_error'));
        }

        global $db;
        $table = 'xnx_oauth_bind';
        $bind = db_find_one($table, array('id' => $id));
        if (empty($bind)) {
            message(-1, lang('oauth_admin_bind_not_found'));
        }

        $r = db_delete($table, array('id' => $id));
        if ($r === false) {
            message(-1, lang('oauth_admin_unbind_failed'));
        }

        // 记录管理员操作日志
        admin_log_create('oauth_unbind', 'oauth', $id, '强制解绑 OAuth: uid=' . $bind['uid'] . ' provider=' . $bind['provider']);
        message(0, lang('oauth_admin_unbind_ok'));

    } else {
        message(-1, lang('oauth_admin_unknown_op'));
    }
}

// ===== GET 请求处理（需要渲染页面，include header/footer）=====
include _include(ADMIN_PATH . 'view/htm/header.inc.htm');

switch ($sub_action) {

    // ===== 配置页 =====
    case 'setting':
        $setting = setting_get('xnx_oauth');
        if (empty($setting)) {
            $setting = array('enable' => 0, 'auto_merge_by_email' => 0, 'providers' => array());
        }
        if (empty($setting['providers']) || !is_array($setting['providers'])) {
            $setting['providers'] = array();
        }

        // 内置 provider 模板（技术参数写死，后台只展示 AppID/AppSecret 等必填字段）
        $builtin_providers = xnx_oauth_builtin_providers();

        // 合并内置模板和已保存配置（已保存优先）
        $merged_providers = array();
        foreach ($builtin_providers as $name => $tpl) {
            if (isset($setting['providers'][$name])) {
                $merged_providers[$name] = $setting['providers'][$name];
                // 标记为内置 provider（模板据此决定是否展示高级设置折叠区）
                $merged_providers[$name]['is_builtin'] = 1;
            } else {
                $merged_providers[$name] = array_merge($tpl, array(
                    'appid'   => '',
                    'appkey'  => '',
                    'enable'  => 0,
                    'is_builtin' => 1,
                ));
            }
        }
        // 追加自定义 provider（非内置，模板展示全部字段）
        foreach ($setting['providers'] as $name => $p) {
            if (!isset($merged_providers[$name])) {
                $merged_providers[$name] = $p;
                $merged_providers[$name]['is_builtin'] = 0;
            }
        }

        // 计算每个 provider 的回调地址，供模板展示
        // ponytail: 与 OAuthService::getRedirectUri() 返回值一致，第三方平台后台必须填写此地址
        OAuthService::init();
        $_oauth_svc = OAuthService::getInstance();
        foreach ($merged_providers as $_name => &$_p) {
            $_p['_callback_url'] = $_oauth_svc->getCallbackUrl($_name);
        }
        unset($_name, $_p);

        $active_tab = 'setting';
        include _include(APP_PATH . 'plugin/xnx_oauth/admin/view/htm/oauth_setting.htm');
        break;

    // ===== 绑定记录列表 =====
    case 'bindlist':
        $page = intval(param(4, 1));
        if ($page < 1) $page = 1;
        $pagesize = 20;
        $filter_provider = trim((string)param('provider', ''));
        $filter_uid = intval(param('uid', 0));

        global $db;
        $table = 'xnx_oauth_bind';

        $cond = array();
        if (!empty($filter_provider)) $cond['provider'] = $filter_provider;
        if ($filter_uid > 0) $cond['uid'] = $filter_uid;

        $total = db_count($table, $cond);
        $bindlist = db_find($table, $cond, array('bind_time' => -1), $page, $pagesize, 'id');

        // 附加用户信息和 IP 转换
        if ($bindlist) {
            foreach ($bindlist as &$_b) {
                $_u = user_read($_b['uid']);
                $_b['username'] = !empty($_u) ? (isset($_u['username']) ? $_u['username'] : '') : '-';
                $_b['last_login_ip_str'] = !empty($_b['last_login_ip']) ? long2ip(intval($_b['last_login_ip'])) : '-';
                $_b['bind_time_str'] = !empty($_b['bind_time']) ? date('Y-m-d H:i', $_b['bind_time']) : '-';
                $_b['last_login_time_str'] = !empty($_b['last_login_time']) ? date('Y-m-d H:i', $_b['last_login_time']) : '-';
            }
            unset($_b);
        } else {
            $bindlist = array();
        }

        // 已有 provider 列表（用于筛选下拉）
        $_filter_providers = OAuthService::getProviders();

        // 分页 URL（保留筛选参数）
        $url_params = array();
        if (!empty($filter_provider)) $url_params['provider'] = $filter_provider;
        if ($filter_uid > 0) $url_params['uid'] = $filter_uid;
        $url_params['page'] = '{page}';
        $pagination = pagination(url('plugin-setting-xnx_oauth-bindlist', $url_params), $total, $page, $pagesize);

        $active_tab = 'bindlist';
        include _include(APP_PATH . 'plugin/xnx_oauth/admin/view/htm/oauth_bindlist.htm');
        break;

    default:
        message(-1, lang('oauth_admin_unknown_action'));
        break;
}

include _include(ADMIN_PATH . 'view/htm/footer.inc.htm');
