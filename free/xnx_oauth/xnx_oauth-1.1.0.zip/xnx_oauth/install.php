<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;

// 创建 OAuth 绑定关系表（utf8mb4 支持 emoji）
$sql = "CREATE TABLE IF NOT EXISTS `" . $tablepre . "xnx_oauth_bind` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'Xiuno 用户 ID',
  `provider` varchar(20) NOT NULL DEFAULT '' COMMENT 'qq/wechat/github/google',
  `openid` varchar(100) NOT NULL DEFAULT '' COMMENT '第三方唯一标识',
  `unionid` varchar(100) NOT NULL DEFAULT '' COMMENT '多平台统一 ID',
  `nickname` varchar(50) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '本地头像路径',
  `email` varchar(100) NOT NULL DEFAULT '',
  `raw_data` text,
  `bind_time` int(11) NOT NULL DEFAULT '0',
  `last_login_time` int(11) NOT NULL DEFAULT '0',
  `last_login_ip` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider_openid` (`provider`, `openid`),
  KEY `uid` (`uid`),
  KEY `provider_unionid` (`provider`, `unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='OAuth 第三方登录绑定'";
// DDL 建表/删表，保留 db_exec
db_exec($sql);

// 设置默认配置
$default_setting = array(
    'auto_merge_by_email' => 0,
    'providers' => array(),
);
setting_set('xnx_oauth', $default_setting);

?>
