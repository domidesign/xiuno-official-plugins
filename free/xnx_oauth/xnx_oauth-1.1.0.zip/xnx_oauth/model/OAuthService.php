<?php

!defined('DEBUG') AND exit('Forbidden');

/**
 * OAuthService OAuth2.0 统一登录服务
 *
 * 提供 OAuth2.0 授权流程管理，支持 QQ/微信/GitHub/Google 等第三方登录。
 * 通过 provider 注册机制实现可扩展的第三方登录接入。
 *
 * 用法：
 * 1. 其他插件通过 OAuthService::registerProvider($config) 注册 provider
 * 2. 调用 OAuthService::init() 初始化（合并静态注册和后台配置）
 * 3. 调用 getAuthUrl() 生成授权链接，handleCallback() 处理回调
 */
class OAuthService {

    /**
     * 已注册的 provider 列表（name => config）
     * @var array
     */
    private static $providers = array();

    /**
     * 是否已初始化
     * @var bool
     */
    private static $initialized = false;

    /**
     * 单例实例（用于实例方法调用）
     * @var OAuthService|null
     */
    private static $instance = null;

    /**
     * 表前缀
     * @var string
     */
    // ponytail: db_insert/find_one/update/delete 等函数内部会自动用 $d->tablepre 拼接表名，
    // 传入的 $table 参数应为不含前缀的表名（如 'xnx_oauth_bind'），禁止手动拼 $this->tablepre 否则前缀重复。

    /**
     * 获取单例实例
     * @return OAuthService
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
    }

    // ---- Provider 注册机制 ----

    /**
     * 初始化：合并静态注册的 provider 和后台 kv 表配置的 provider
     * 静态注册优先于后台配置，同名 provider 后注册覆盖先注册并记录警告日志
     */
    public static function init() {
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;

        // 从后台 kv 表读取 provider 配置
        $setting = setting_get('xnx_oauth');
        $kv_providers = array();
        if (!empty($setting['providers']) && is_array($setting['providers'])) {
            $kv_providers = $setting['providers'];
        }

        // 先合并后台配置
        foreach ($kv_providers as $name => $config) {
            if (!isset($config['name'])) {
                $config['name'] = $name;
            }
            self::$providers[$name] = $config;
        }

        // 静态注册的 provider 已经在 registerProvider 中处理同名覆盖
        // 此处无需额外处理，registerProvider 在 init 前后调用均可
    }

    /**
     * 注册 provider（供其他插件调用）
     * 同名 provider 后注册覆盖先注册，记录 xn_log 警告
     * @param array $config provider 配置
     */
    public static function registerProvider(array $config) {
        if (empty($config['name'])) {
            xn_log('registerProvider: config.name is empty', 'oauth_error');
            return;
        }
        $name = $config['name'];
        if (isset(self::$providers[$name])) {
            xn_log('registerProvider: provider "' . $name . '" already exists, overwritten', 'oauth_error');
        }
        self::$providers[$name] = $config;
    }

    /**
     * 获取所有已注册的 provider
     * @return array
     */
    public static function getProviders() {
        if (!self::$initialized) {
            self::init();
        }
        return self::$providers;
    }

    /**
     * 获取单个 provider 配置
     * @param string $name
     * @return array|null
     */
    public static function getProvider($name) {
        if (!self::$initialized) {
            self::init();
        }
        return isset(self::$providers[$name]) ? self::$providers[$name] : null;
    }

    // ---- 授权流程 ----

    /**
     * 生成授权链接
     * @param string $provider
     * @return array ['ok'=>bool, 'url'=>string, 'message'=>string]
     */
    public function getAuthUrl($provider) {
        $config = self::getProvider($provider);
        if (empty($config)) {
            return array('ok' => false, 'message' => '未知的 provider: ' . $provider);
        }
        if (empty($config['enable'])) {
            return array('ok' => false, 'message' => '该 provider 未启用');
        }
        if (empty($config['appid']) || empty($config['authorize_url'])) {
            return array('ok' => false, 'message' => 'provider 配置不完整（缺 appid 或 authorize_url）');
        }

        // 生成 state 并存入 session
        $state = $this->generateState();
        if (!isset($_SESSION['oauth_state'])) {
            $_SESSION['oauth_state'] = array();
        }
        $_SESSION['oauth_state'][$provider] = $state;

        // 构建 redirect_uri（绝对 URL）
        $redirect_uri = $this->getRedirectUri($provider);

        // 组装请求参数
        $params = array(
            'response_type' => 'code',
            'client_id' => $config['appid'],
            'redirect_uri' => $redirect_uri,
            'state' => $state,
        );

        // scope
        if (!empty($config['scope'])) {
            $params['scope'] = $config['scope'];
        }

        // 额外参数
        if (!empty($config['extra_params']) && is_array($config['extra_params'])) {
            $params = array_merge($params, $config['extra_params']);
        }

        // PKCE 支持
        if (!empty($config['enable_pkce'])) {
            $code_verifier = $this->generateCodeVerifier();
            $code_challenge = $this->generateCodeChallenge($code_verifier);
            if (!isset($_SESSION['oauth_code_verifier'])) {
                $_SESSION['oauth_code_verifier'] = array();
            }
            $_SESSION['oauth_code_verifier'][$provider] = $code_verifier;
            $params['code_challenge'] = $code_challenge;
            $params['code_challenge_method'] = 'S256';
        }

        $auth_url = $config['authorize_url'] . '?' . http_build_query($params);
        return array('ok' => true, 'url' => $auth_url);
    }

    /**
     * 处理回调（含 state 校验、token 换取、用户信息获取、字段映射、登录或绑定）
     * @param string $provider
     * @param string $code
     * @param string $state
     * @return array ['ok'=>bool, 'action'=>string, 'uid'=>int, 'message'=>string]
     */
    public function handleCallback($provider, $code, $state) {
        try {
            $config = self::getProvider($provider);
            if (empty($config)) {
                return array('ok' => false, 'message' => '未知的 provider: ' . $provider);
            }

            // 校验 state
            $stored_state = isset($_SESSION['oauth_state'][$provider]) ? $_SESSION['oauth_state'][$provider] : '';
            if (empty($state) || !hash_equals($stored_state, $state)) {
                xn_log('handleCallback: state validation failed for provider=' . $provider, 'oauth_error');
                return array('ok' => false, 'message' => 'state 校验失败，请重试');
            }
            // 校验后立即销毁，防止重放
            unset($_SESSION['oauth_state'][$provider]);

            // 获取 PKCE code_verifier
            $code_verifier = null;
            if (!empty($config['enable_pkce'])) {
                $code_verifier = isset($_SESSION['oauth_code_verifier'][$provider]) ? $_SESSION['oauth_code_verifier'][$provider] : null;
                unset($_SESSION['oauth_code_verifier'][$provider]);
            }

            // 换取 access_token
            $token_result = $this->exchangeToken($provider, $code, $code_verifier);
            if (!$token_result['ok']) {
                xn_log('handleCallback: exchangeToken failed for provider=' . $provider . ' msg=' . $token_result['message'], 'oauth_error');
                return array('ok' => false, 'message' => $token_result['message']);
            }
            $access_token = $token_result['access_token'];

            // 获取用户信息
            $userinfo_result = $this->getUserInfo($provider, $access_token);
            if (!$userinfo_result['ok']) {
                xn_log('handleCallback: getUserInfo failed for provider=' . $provider . ' msg=' . $userinfo_result['message'], 'oauth_error');
                return array('ok' => false, 'message' => $userinfo_result['message']);
            }
            $raw_data = $userinfo_result['data'];

            // 字段映射
            $mapped = $this->mapUserInfo($provider, $raw_data);
            if (!$mapped['ok']) {
                xn_log('handleCallback: mapUserInfo failed for provider=' . $provider . ' msg=' . $mapped['message'], 'oauth_error');
                return array('ok' => false, 'message' => $mapped['message']);
            }

            // Gitee 特殊处理：/v5/user 默认不返回邮箱，需调用 /v5/emails 接口补取
            // ponytail: Gitee 把用户信息和邮箱分离到两个接口，即使申请了 emails scope，/v5/user 的 email 字段也是空的
            if ($provider === 'gitee' && empty($mapped['userInfo']['email'])) {
                $mapped['userInfo']['email'] = $this->fetchGiteeEmail($access_token);
            }

            // 登录或绑定
            return $this->loginOrBind($provider, $mapped['userInfo']);

        } catch (Exception $e) {
            xn_log('handleCallback exception: provider=' . $provider . ' msg=' . $e->getMessage(), 'oauth_error');
            return array('ok' => false, 'message' => 'OAuth 回调处理异常：' . $e->getMessage());
        }
    }

    // ---- 私有方法：授权流程内部实现 ----

    /**
     * 获取回调地址（绝对 URL）
     *
     * ponytail: 禁止用 url() 函数生成回调地址。url() 在后台上下文会强制 url_rewrite_on=0
     * 并返回 ./ 相对路径，导致两个问题：
     * 1. 后台设置页显示的回调地址与前台实际跳转回来的格式不一致（伪静态开启时）
     * 2. $site_url . url(...) 拼接出 https://xxx/admin./?... 错乱地址
     * 这里直接按真实 url_rewrite_on 拼接绝对 URL，确保与 getAuthUrl() 传给第三方的 redirect_uri 一致
     *
     * @param string $provider
     * @return string
     */
    private function getRedirectUri($provider) {
        $conf = _SERVER('conf');
        $site_url = isset($conf['url']) ? rtrim($conf['url'], '/') : '';
        if (empty($site_url)) {
            $site_url = rtrim(http_url_path(), '/');
            // ponytail: http_url_path() 基于 $_SERVER['PHP_SELF'] 推断站点路径，
            // 在 admin 上下文（PHP_SELF=/xxx/admin/index.php）会返回带 /admin 后缀的路径，
            // 导致后台设置页显示的回调地址（带 /admin）与前台 OAuth 流程实际发送的 redirect_uri（不带 /admin）不一致，
            // 第三方平台报 "redirect_uri is not associated with this application" 错误。
            // 统一剥离末尾的 /admin，保证 admin/前台调用结果一致。
            if (substr($site_url, -6) === '/admin') {
                $site_url = substr($site_url, 0, -6);
            }
        }

        // 按真实伪静态风格拼接（参考 model/misc.func.php url() 的格式映射）
        $url_rewrite_on = isset($conf['url_rewrite_on']) ? intval($conf['url_rewrite_on']) : 0;
        $base_path = isset($conf['base_path']) ? $conf['base_path'] : '';
        $route = 'oauth-callback-' . $provider;

        if ($url_rewrite_on == 0) {
            $suffix = '?' . $route . '.htm';
        } elseif ($url_rewrite_on == 1) {
            $suffix = $route . '.htm';
        } elseif ($url_rewrite_on == 2) {
            $suffix = '?' . str_replace('-', '/', $route);
        } elseif ($url_rewrite_on == 3) {
            $suffix = str_replace('-', '/', $route);
        } elseif ($url_rewrite_on == 4) {
            $suffix = $route . '.html';
        } elseif ($url_rewrite_on == 5) {
            $suffix = str_replace('-', '/', $route) . '.html';
        } else {
            $suffix = '?' . $route . '.htm';
        }

        // 拼接：site_url + base_path + / + suffix
        $path = $site_url . $base_path . '/' . ltrim($suffix, '/');
        return $path;
    }

    /**
     * 对外公开的回调地址查询（供后台设置页展示用）
     * 与 getRedirectUri 返回值一致，第三方平台后台必须填写完全相同的地址
     * @param string $provider
     * @return string
     */
    public function getCallbackUrl($provider) {
        return $this->getRedirectUri($provider);
    }

    /**
     * 换取 access_token
     * @param string $provider
     * @param string $code
     * @param string|null $codeVerifier
     * @return array ['ok'=>bool, 'access_token'=>string, 'message'=>string]
     */
    private function exchangeToken($provider, $code, $codeVerifier = null) {
        $config = self::getProvider($provider);
        if (empty($config) || empty($config['token_url'])) {
            return array('ok' => false, 'message' => 'provider token_url 未配置');
        }

        $params = array(
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->getRedirectUri($provider),
            'client_id' => $config['appid'],
        );
        if (!empty($config['appkey'])) {
            $params['client_secret'] = $config['appkey'];
        }
        if (!empty($codeVerifier)) {
            $params['code_verifier'] = $codeVerifier;
        }

        $response = $this->httpRequest($config['token_url'], 'POST', $params);
        if ($response['code'] != 200) {
            // HTTP 0 表示 curl 请求本身失败（网络不通/SSL/DNS/超时），暴露具体 curl 错误方便排查
            if ($response['code'] === 0) {
                $curl_err = !empty($response['error']) ? $response['error'] : '未知网络错误';
                return array('ok' => false, 'message' => '换取 token 失败：服务器无法访问 ' . $config['token_url'] . '（curl 错误：' . $curl_err . '）。若服务器在中国大陆，可能是网络无法直达 Google/GitHub 端点，需配置代理。');
            }
            return array('ok' => false, 'message' => '换取 token 失败，HTTP 状态码：' . $response['code']);
        }

        $body = $response['body'];
        // 尝试解析 JSON，失败则按 query string 解析（QQ 返回 query string 格式）
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            parse_str($body, $data);
        }

        if (empty($data['access_token'])) {
            $err_msg = isset($data['error_description']) ? $data['error_description'] : (isset($data['error']) ? $data['error'] : '响应中无 access_token');
            return array('ok' => false, 'message' => '换取 token 失败：' . $err_msg);
        }

        return array('ok' => true, 'access_token' => $data['access_token']);
    }

    /**
     * 获取用户信息
     * @param string $provider
     * @param string $accessToken
     * @return array ['ok'=>bool, 'data'=>array, 'message'=>string]
     */
    private function getUserInfo($provider, $accessToken) {
        $config = self::getProvider($provider);
        if (empty($config) || empty($config['userinfo_url'])) {
            return array('ok' => false, 'message' => 'provider userinfo_url 未配置');
        }

        $headers = array(
            'Authorization: Bearer ' . $accessToken,
        );

        // QQ 等平台需要先调用 pre_userinfo_url 获取 openid
        $pre_openid = '';
        if (!empty($config['pre_userinfo_url'])) {
            $pre_response = $this->httpRequest($config['pre_userinfo_url'] . '?access_token=' . urlencode($accessToken), 'GET', null, $headers);
            if ($pre_response['code'] == 200) {
                $pre_body = $pre_response['body'];
                // QQ 返回 callback( {"client_id":"...","openid":"..."} ); 格式
                $pre_data = $this->parsePreUserInfo($pre_body);
                if (!empty($pre_data['openid'])) {
                    $pre_openid = $pre_data['openid'];
                    // 将 openid 带入 userinfo 请求
                    $sep = strpos($config['userinfo_url'], '?') !== false ? '&' : '?';
                    $config['userinfo_url'] .= $sep . 'access_token=' . urlencode($accessToken) . '&oauth_consumer_key=' . urlencode($config['appid']) . '&openid=' . urlencode($pre_data['openid']);
                }
            }
        }

        $method = !empty($config['userinfo_method']) ? strtoupper($config['userinfo_method']) : 'GET';
        $response = $this->httpRequest($config['userinfo_url'], $method, null, $headers);

        if ($response['code'] != 200) {
            return array('ok' => false, 'message' => '获取用户信息失败，HTTP 状态码：' . $response['code']);
        }

        $body = $response['body'];
        // 尝试解析 JSON，失败则按 query string 解析
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            parse_str($body, $data);
        }

        if (empty($data)) {
            return array('ok' => false, 'message' => '用户信息响应解析失败');
        }

        // 注入 pre_userinfo_url 获取的 openid（如 QQ），确保 mapUserInfo 能取到
        if (!empty($pre_openid) && empty($data['openid'])) {
            $data['openid'] = $pre_openid;
        }

        return array('ok' => true, 'data' => $data);
    }

    /**
     * 解析 pre_userinfo 响应（如 QQ 的 callback( {...} ); 格式）
     * @param string $body
     * @return array
     */
    private function parsePreUserInfo($body) {
        // 处理 callback( {...} ); 格式
        $body = trim($body);
        if (preg_match('/^callback\s*\((.+)\);?\s*$/', $body, $matches)) {
            $body = $matches[1];
        }
        $data = json_decode($body, true);
        return is_array($data) ? $data : array();
    }

    /**
     * 字段映射：将原始用户信息按 field_mapping 映射为统一结构
     * @param string $provider
     * @param array $rawData
     * @return array ['ok'=>bool, 'userInfo'=>array, 'message'=>string]
     */
    private function mapUserInfo($provider, $rawData) {
        $config = self::getProvider($provider);
        if (empty($config)) {
            return array('ok' => false, 'message' => '未知的 provider');
        }

        $mapping = !empty($config['field_mapping']) ? $config['field_mapping'] : array();

        $getField = function($key) use ($rawData, $mapping) {
            if (empty($key) || !isset($mapping[$key])) {
                return '';
            }
            $source_key = $mapping[$key];
            if (empty($source_key)) {
                return '';
            }
            // 支持嵌套字段（如 a.b）
            if (strpos($source_key, '.') !== false) {
                $parts = explode('.', $source_key);
                $val = $rawData;
                foreach ($parts as $p) {
                    if (!is_array($val) || !isset($val[$p])) {
                        return '';
                    }
                    $val = $val[$p];
                }
                return $val;
            }
            return isset($rawData[$source_key]) ? $rawData[$source_key] : '';
        };

        $openid = (string)$getField('openid');
        if ($openid === '') {
            return array('ok' => false, 'message' => 'openid 字段缺失，无法映射');
        }

        $userInfo = array(
            'openid' => $openid,
            'unionid' => (string)$getField('unionid'),
            'nickname' => (string)$getField('nickname'),
            'avatar' => (string)$getField('avatar'),
            'email' => (string)$getField('email'),
            'gender' => (string)$getField('gender'),
            'raw_data' => xn_json_encode($rawData),
        );

        // Gitee 特殊处理：/v5/user 默认不返回邮箱，需调用 /v5/emails 接口获取
        // ponytail: Gitee 把用户信息和邮箱分离到两个接口，即使申请了 emails scope，/v5/user 的 email 字段也是空的
        // 实际补取逻辑在 handleCallback 中执行（mapUserInfo 无 access_token 参数）

        return array('ok' => true, 'userInfo' => $userInfo);
    }

    /**
     * 获取 Gitee 用户邮箱
     * Gitee /v5/user 不返回邮箱，需调用 /v5/emails 接口
     * @param string $accessToken
     * @return string 邮箱（获取失败返回空字符串）
     */
    private function fetchGiteeEmail($accessToken) {
        $response = $this->httpRequest('https://gitee.com/api/v5/emails', 'GET', null, array(
            'Authorization: Bearer ' . $accessToken,
        ));
        if ($response['code'] != 200) {
            return '';
        }
        $emails = json_decode($response['body'], true);
        if (!is_array($emails) || empty($emails)) {
            return '';
        }
        // 优先返回主邮箱，否则取第一个
        foreach ($emails as $item) {
            if (!empty($item['email'])) {
                // 优先返回已验证的主邮箱
                if (!empty($item['primary']) || !empty($item['is_primary'])) {
                    return $item['email'];
                }
            }
        }
        // 没有标记 primary 的，取第一个非空
        foreach ($emails as $item) {
            if (!empty($item['email'])) {
                return $item['email'];
            }
        }
        return '';
    }

    // ---- 登录或绑定 ----

    /**
     * 登录或绑定（四种分支）
     * 1. openid 已绑定 → 直接登录
     * 2. 未绑定但已登录 → 绑定到当前用户
     * 3. 未登录但邮箱匹配且开启自动合并 → 自动合并并登录
     * 4. 其他情况 → 拒绝并提示先注册/登录
     * @param string $provider
     * @param array $userInfo 已映射的用户信息
     * @return array ['ok'=>bool, 'action'=>string, 'uid'=>int, 'message'=>string]
     */
    public function loginOrBind($provider, $userInfo) {
        global $uid, $longip;

        $table = 'xnx_oauth_bind';

        // 1. 查询 openid 是否已绑定
        $bind = db_find_one($table, array('provider' => $provider, 'openid' => $userInfo['openid']));
        if ($bind) {
            // 已绑定 → 直接登录
            $_SESSION['uid'] = $bind['uid'];
            user_token_set($bind['uid']);

            $update_data = array(
                'last_login_time' => time(),
                'last_login_ip' => intval($longip),
            );
            // 更新昵称和头像（如有）
            if (!empty($userInfo['nickname'])) {
                $update_data['nickname'] = $userInfo['nickname'];
            }
            if (!empty($userInfo['avatar'])) {
                $update_data['avatar'] = $userInfo['avatar'];
            }
            db_update($table, array('id' => $bind['id']), $update_data);

            return array('ok' => true, 'action' => 'login', 'uid' => $bind['uid'], 'message' => '登录成功');
        }

        // 2. 未绑定，检查是否已登录（绑定流程）
        if (!empty($uid)) {
            // 检查当前用户是否已绑定该 provider
            $existing = db_find_one($table, array('uid' => $uid, 'provider' => $provider));
            if ($existing) {
                return array('ok' => false, 'action' => 'bind', 'message' => '您已绑定该平台账号，请先解绑后再绑定新账号');
            }
            $bind_result = $this->bindAccount($uid, $provider, $userInfo);
            if (!$bind_result['ok']) {
                return array('ok' => false, 'action' => 'bind', 'message' => $bind_result['message']);
            }
            return array('ok' => true, 'action' => 'bind', 'uid' => $uid, 'message' => '绑定成功');
        }

        // 3. 未登录，检查邮箱匹配自动合并
        $setting = setting_get('xnx_oauth');
        $auto_merge = !empty($setting['auto_merge_by_email']);
        if ($auto_merge && !empty($userInfo['email'])) {
            $user = user_read_by_email($userInfo['email']);
            if (!empty($user)) {
                $bind_result = $this->bindAccount($user['uid'], $provider, $userInfo);
                if (!$bind_result['ok']) {
                    return array('ok' => false, 'action' => 'merge', 'message' => $bind_result['message']);
                }
                $_SESSION['uid'] = $user['uid'];
                user_token_set($user['uid']);
                return array('ok' => true, 'action' => 'merge', 'uid' => $user['uid'], 'message' => '账号已自动关联并登录');
            }
        }

        // 4. 邮箱不匹配，检查是否允许自动注册
        $auto_register = !empty($setting['auto_register']);
        if ($auto_register) {
            $create_result = $this->createUserFromOAuth($provider, $userInfo);
            if (!$create_result['ok']) {
                return array('ok' => false, 'action' => 'reject', 'message' => $create_result['message']);
            }
            $new_uid = $create_result['uid'];
            $bind_result = $this->bindAccount($new_uid, $provider, $userInfo);
            if (!$bind_result['ok']) {
                return array('ok' => false, 'action' => 'reject', 'message' => $bind_result['message']);
            }
            $_SESSION['uid'] = $new_uid;
            user_token_set($new_uid);
            return array('ok' => true, 'action' => 'register', 'uid' => $new_uid, 'message' => '注册并登录成功');
        }

        // 5. 不允许自动注册，拒绝
        return array('ok' => false, 'action' => 'reject', 'message' => '请先注册或登录 Xiuno 账号后再绑定第三方登录');
    }

    /**
     * 根据第三方返回信息创建新 Xiuno 账号
     * 用户名策略：优先用 nickname，冲突时加 provider 前缀+随机后缀
     * 邮箱策略：第三方返回且未被占用则用，否则留空
     * 密码：随机强密码（用户可通过找回密码修改）
     * @param string $provider
     * @param array $userInfo 已映射的用户信息
     * @return array ['ok'=>bool, 'uid'=>int, 'message'=>string]
     */
    private function createUserFromOAuth($provider, $userInfo) {
        global $longip, $time;
        $time = time();

        // 生成唯一用户名
        $base_name = !empty($userInfo['nickname']) ? $userInfo['nickname'] : $provider . '_' . substr($userInfo['openid'], -8);
        // 清理用户名中的非法字符（Xiuno 用户名限制字母数字下划线中文）
        $base_name = preg_replace('/[^\p{Han}a-zA-Z0-9_]/u', '', $base_name);
        if (empty($base_name)) {
            $base_name = $provider . '_' . substr($userInfo['openid'], -8);
        }
        $base_name = mb_substr($base_name, 0, 20, 'UTF-8');

        $username = $base_name;
        $suffix = 0;
        while (user_read_by_username($username)) {
            $suffix++;
            // 截断 base_name 为 suffix 留空间，避免超长
            $cut = mb_substr($base_name, 0, 20 - strlen((string)$suffix) - 1, 'UTF-8');
            $username = $cut . '_' . $suffix;
            if ($suffix > 999) {
                return array('ok' => false, 'message' => '用户名生成失败，请手动注册后绑定');
            }
        }

        // 邮箱：第三方返回且未被占用则用；否则生成唯一占位邮箱（email 字段有唯一索引，空值会冲突）
        $email = '';
        if (!empty($userInfo['email'])) {
            $existing = user_read_by_email($userInfo['email']);
            if (empty($existing)) {
                $email = $userInfo['email'];
            }
        }
        if (empty($email)) {
            // 用 openid 生成唯一占位邮箱，用户可在个人中心修改
            $email = 'oauth_' . substr(md5($provider . '_' . $userInfo['openid']), 0, 16) . '@placeholder.local';
        }

        // 随机强密码（16位，用户可通过找回密码修改）
        $password = substr(bin2hex(random_bytes(8)), 0, 16);

        $gid = 101; // 普通用户组
        $_user = array(
            'username'   => $username,
            'nickname'   => $username,
            'email'      => $email,
            'password'   => '',
            'salt'       => '',
            'gid'        => $gid,
            'create_ip'  => $longip,
            'create_date'=> $time,
            'logins'     => 1,
            'login_date' => $time,
            'login_ip'   => $longip,
        );
        if (function_exists('db_check_column_exists') && db_check_column_exists('user', 'password_hash')) {
            $_user['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $uid = user_create($_user);
        if ($uid === FALSE) {
            return array('ok' => false, 'message' => '账号创建失败，请稍后重试或手动注册');
        }

        return array('ok' => true, 'uid' => $uid);
    }

    /**
     * 绑定账号
     * @param int $uid
     * @param string $provider
     * @param array $userInfo 已映射的用户信息
     * @return array ['ok'=>bool, 'bind_id'=>int, 'message'=>string]
     */
    public function bindAccount($uid, $provider, $userInfo) {
        global $longip;
        $uid = intval($uid);
        if ($uid <= 0) {
            return array('ok' => false, 'message' => '无效的用户 ID');
        }

        $table = 'xnx_oauth_bind';

        // 检查是否已绑定
        $existing = db_find_one($table, array('uid' => $uid, 'provider' => $provider));
        if ($existing) {
            return array('ok' => false, 'message' => '该账号已绑定此平台');
        }

        // 检查 openid 是否已被其他用户绑定
        $existing_bind = db_find_one($table, array('provider' => $provider, 'openid' => $userInfo['openid']));
        if ($existing_bind && $existing_bind['uid'] != $uid) {
            return array('ok' => false, 'message' => '该第三方账号已被其他用户绑定');
        }

        $now = time();
        $insert_data = array(
            'uid' => $uid,
            'provider' => $provider,
            'openid' => $userInfo['openid'],
            'unionid' => !empty($userInfo['unionid']) ? $userInfo['unionid'] : '',
            'nickname' => !empty($userInfo['nickname']) ? $userInfo['nickname'] : '',
            'avatar' => '',
            'email' => !empty($userInfo['email']) ? $userInfo['email'] : '',
            'raw_data' => !empty($userInfo['raw_data']) ? $userInfo['raw_data'] : '',
            'bind_time' => $now,
            'last_login_time' => $now,
            'last_login_ip' => intval($longip),
        );

        $bind_id = db_insert($table, $insert_data);
        if (!$bind_id) {
            xn_log('bindAccount: db_insert failed for uid=' . $uid . ' provider=' . $provider, 'oauth_error');
            return array('ok' => false, 'message' => '绑定失败，数据库写入错误');
        }

        // 下载头像（仅当用户当前无自定义头像）
        if (!empty($userInfo['avatar'])) {
            $this->downloadAvatar($userInfo['avatar'], $uid);
        }

        return array('ok' => true, 'bind_id' => $bind_id, 'message' => '绑定成功');
    }

    /**
     * 解绑账号
     * @param int $uid
     * @param string $provider
     * @return array ['ok'=>bool, 'message'=>string]
     */
    public function unbindAccount($uid, $provider) {
        $uid = intval($uid);
        if ($uid <= 0) {
            return array('ok' => false, 'message' => '无效的用户 ID');
        }

        $table = 'xnx_oauth_bind';

        // 检查绑定是否存在
        $bind = db_find_one($table, array('uid' => $uid, 'provider' => $provider));
        if (empty($bind)) {
            return array('ok' => false, 'message' => '未找到该平台的绑定记录');
        }

        // 检查用户是否有其他登录方式
        if (!$this->hasOtherLoginMethod($uid, $provider)) {
            return array('ok' => false, 'message' => '解绑失败：您没有其他可用的登录方式，请先设置密码或绑定其他平台');
        }

        $r = db_delete($table, array('id' => $bind['id']));
        if ($r === false) {
            return array('ok' => false, 'message' => '解绑失败，数据库错误');
        }

        return array('ok' => true, 'message' => '解绑成功');
    }

    /**
     * 获取用户所有绑定
     * @param int $uid
     * @return array
     */
    public function getUserBinds($uid) {
        $uid = intval($uid);
        if ($uid <= 0) {
            return array();
        }
        $table = 'xnx_oauth_bind';
        $list = db_find($table, array('uid' => $uid), array('bind_time' => -1), 1, 100, 'id');
        return $list ? $list : array();
    }

    /**
     * 检查用户是否有其他登录方式
     * @param int $uid
     * @param string $excludeProvider 排除的 provider
     * @return bool
     */
    public function hasOtherLoginMethod($uid, $excludeProvider = '') {
        $uid = intval($uid);
        if ($uid <= 0) {
            return false;
        }

        // 检查用户是否有密码
        $user = user_read($uid);
        if (empty($user)) {
            return false;
        }
        if (!empty($user['password']) || !empty($user['password_hash'])) {
            return true;
        }

        // 检查是否有其他 OAuth 绑定
        $table = 'xnx_oauth_bind';
        $cond = array('uid' => $uid);
        if (!empty($excludeProvider)) {
            $cond['provider'] = array('!=' => $excludeProvider);
        }
        $count = db_count($table, $cond);
        return $count > 0;
    }

    // ---- 头像下载 ----

    /**
     * 下载头像到本地
     * 仅当用户当前无自定义头像时下载，保存到 upload/avatar/{dir}/{uid}.png
     * 使用临时文件 + rename 实现原子写入
     * @param string $url 头像 URL
     * @param int $uid 用户 ID
     * @return bool 是否下载成功
     */
    private function downloadAvatar($url, $uid) {
        $uid = intval($uid);
        if ($uid <= 0 || empty($url)) {
            return false;
        }

        // 检查用户当前是否有自定义头像
        $user = user_read($uid);
        if (empty($user)) {
            return false;
        }
        // avatar > 0 表示已有自定义头像，跳过下载
        if (!empty($user['avatar']) && intval($user['avatar']) > 0) {
            return false;
        }

        $conf = _SERVER('conf');
        $upload_path = isset($conf['upload_path']) ? $conf['upload_path'] : APP_PATH . 'upload/';

        // 头像目录：upload/avatar/{前3位}/{uid}.png
        $dir = substr(sprintf("%09d", $uid), 0, 3);
        $avatar_dir = $upload_path . 'avatar/' . $dir . '/';
        if (!is_dir($avatar_dir)) {
            if (!@mkdir($avatar_dir, 0755, true)) {
                xn_log('downloadAvatar: mkdir failed for dir=' . $avatar_dir, 'oauth_error');
                return false;
            }
        }

        // 下载头像
        $response = $this->httpRequest($url, 'GET');
        if ($response['code'] != 200 || empty($response['body'])) {
            xn_log('downloadAvatar: download failed url=' . $url . ' code=' . $response['code'], 'oauth_error');
            return false;
        }

        $image_data = $response['body'];

        // 验证是否为有效图片
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_buffer($finfo, $image_data);
        finfo_close($finfo);
        if (strpos($mime, 'image/') !== 0) {
            xn_log('downloadAvatar: invalid image mime=' . $mime, 'oauth_error');
            return false;
        }

        // 原子写入：先写临时文件，再 rename
        $final_path = $avatar_dir . $uid . '.png';
        $tmp_path = $avatar_dir . $uid . '.png.tmp.' . bin2hex(random_bytes(4));

        if (file_put_contents($tmp_path, $image_data) === false) {
            xn_log('downloadAvatar: write tmp file failed path=' . $tmp_path, 'oauth_error');
            return false;
        }

        if (!@rename($tmp_path, $final_path)) {
            @unlink($tmp_path);
            xn_log('downloadAvatar: rename failed from=' . $tmp_path . ' to=' . $final_path, 'oauth_error');
            return false;
        }

        // 更新用户 avatar 字段为当前时间戳（用于缓存刷新）
        user_update($uid, array('avatar' => time()));

        return true;
    }

    // ---- HTTP 请求 ----

    /**
     * HTTP 请求（curl）
     * @param string $url
     * @param string $method GET|POST
     * @param array|string|null $data
     * @param array $headers
     * @return array ['code'=>int, 'body'=>string, 'header'=>string]
     */
    private function httpRequest($url, $method = 'GET', $data = null, $headers = array()) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

        // SSL 安全验证（防中间人攻击）
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

        // 代理支持（中国大陆服务器访问 Google/GitHub 等境外 OAuth 端点需要）
        $setting = setting_get('xnx_oauth');
        if (!empty($setting['proxy_host'])) {
            $proxy = $setting['proxy_host'];
            if (!empty($setting['proxy_port'])) {
                $proxy .= ':' . $setting['proxy_port'];
            }
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            if (!empty($setting['proxy_type']) && $setting['proxy_type'] === 'socks5') {
                curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
            }
            if (!empty($setting['proxy_user'])) {
                $proxy_auth = $setting['proxy_user'];
                if (!empty($setting['proxy_pass'])) {
                    $proxy_auth .= ':' . $setting['proxy_pass'];
                }
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy_auth);
            }
        }

        $method = strtoupper($method);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if (!empty($data)) {
                if (is_array($data)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                } else {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                }
            }
        }

        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        // 跟随重定向（最多 3 次）
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            // PHP 8.0+ curl 句柄自动释放，curl_close() 在 8.5 已废弃
            if (PHP_VERSION_ID < 80000) curl_close($ch);
            xn_log('httpRequest: curl error url=' . $url . ' err=' . $error, 'oauth_error');
            return array('code' => 0, 'body' => '', 'header' => '', 'error' => $error);
        }

        // PHP 8.0+ curl 句柄自动释放，curl_close() 在 8.5 已废弃
        if (PHP_VERSION_ID < 80000) curl_close($ch);

        $header = substr($response, 0, $header_size);
        $body = substr($response, $header_size);

        return array('code' => $http_code, 'body' => $body, 'header' => $header);
    }

    // ---- 安全工具方法 ----

    /**
     * 生成随机 state（32 字符 hex）
     * @return string
     */
    private function generateState() {
        return bin2hex(random_bytes(16));
    }

    /**
     * 生成 PKCE code_verifier（64 字符 hex）
     * @return string
     */
    private function generateCodeVerifier() {
        return bin2hex(random_bytes(32));
    }

    /**
     * 计算 PKCE code_challenge (S256)
     * @param string $verifier
     * @return string
     */
    private function generateCodeChallenge($verifier) {
        return rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
    }
}
