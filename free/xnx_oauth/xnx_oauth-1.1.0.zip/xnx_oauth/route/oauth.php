<?php
!defined('DEBUG') AND exit('Forbidden');

/**
 * OAuth2.0 路由处理
 *
 * URL 格式：oauth-{action}-{provider}
 *   param(0) = 'oauth'
 *   param(1) = action（login / callback / unbind）
 *   param(2) = provider（qq / wechat / github / google ...）
 */

// 初始化 OAuthService（触发 provider 收集）
OAuthService::init();

$action = param(1);
$provider = param(2);

// 全局开关检查（回调必须放行，用户可能在禁用前已发起授权）
$setting = setting_get('xnx_oauth');
if (empty($setting['enable']) && $action != 'callback') {
	message(-1, 'OAuth 登录功能已关闭');
}

$oauth = OAuthService::getInstance();

switch ($action) {

	case 'login':
		// 检查 provider 是否已注册并启用
		$providerConfig = OAuthService::getProvider($provider);
		if (!$providerConfig) {
			http_response_code(404);
			xn_log('Unknown oauth provider: ' . $provider, 'oauth_error');
			message(-1, '未知的 OAuth 平台: ' . esc_html($provider));
		}
		if (empty($providerConfig['enable'])) {
			message(-1, '该 OAuth 平台未启用');
		}
		if (empty($providerConfig['appid']) || empty($providerConfig['appkey'])) {
			message(-1, '该 OAuth 平台未配置 AppID/AppSecret');
		}

		// 生成授权链接并跳转
		$result = $oauth->getAuthUrl($provider);
		if (empty($result['ok'])) {
			xn_log('OAuth login: getAuthUrl failed provider=' . $provider . ' msg=' . (isset($result['message']) ? $result['message'] : ''), 'oauth_error');
			message(-1, $result['message'] ?: '生成授权链接失败');
		}
		header('Location: ' . $result['url']);
		exit;
		break;

	case 'callback':
		$code = param('code');
		$state = param('state');

		// 检查 provider 是否已注册
		$providerConfig = OAuthService::getProvider($provider);
		if (!$providerConfig) {
			http_response_code(404);
			xn_log('Unknown oauth provider: ' . $provider, 'oauth_error');
			message(-1, '未知的 OAuth 平台: ' . esc_html($provider));
		}

		if (empty($code)) {
			// 第三方取消授权或出错
			$error = param('error');
			$errorDesc = param('error_description');
			xn_log('OAuth callback error: ' . $provider . ' ' . $error . ' ' . $errorDesc, 'oauth_error');
			message(-1, '授权失败：' . ($errorDesc ?: $error ?: '未知错误'));
		}

		if (empty($state)) {
			message(-1, '缺少 state 参数');
		}

		try {
			$result = $oauth->handleCallback($provider, $code, $state);
			if (!empty($result['ok'])) {
				// 成功：跳转个人中心
				$action_type = isset($result['action']) ? $result['action'] : '';
				$redirect = url('my');
				// 提示信息根据 action_type
				$msg_map = array(
					'login' => '登录成功',
					'bind'  => '绑定成功',
					'merge' => '账号已关联并登录',
				);
				$msg = isset($msg_map[$action_type]) ? $msg_map[$action_type] : '操作成功';
				message(0, $msg, array('redirect_url' => $redirect));
			} else {
				// 失败：根据 action 类型决定跳转
				$action_type = isset($result['action']) ? $result['action'] : '';
				if ($action_type === 'reject') {
					// 邮箱不匹配等情况，跳转登录页
					message(-1, $result['message'], array('redirect_url' => url('user-login')));
				} else {
					message(-1, $result['message']);
				}
			}
		} catch (Exception $e) {
			xn_log('OAuth callback exception: ' . $e->getMessage(), 'oauth_error');
			message(-1, '授权回调处理异常：' . $e->getMessage());
		}
		break;

	case 'bind':
		// 个人中心 OAuth 绑定管理页面
		// ponytail: URL 为 oauth-bind-manage，Xiuno 按 - 分隔后 param(1)='bind', param(2)='manage'
		if (param(2) !== 'manage') {
			http_response_code(404);
			message(-1, '页面不存在');
		}
		global $uid, $user, $header;
		if (!$uid) {
			message(-1, lang('please_login'), array('redirect_url' => url('user-login')));
		}

		// 整理绑定状态：遍历所有 provider，标注每个是否已绑定
		// 过滤规则：未启用或配置不完整的 provider 不展示（但已绑定的保留，方便用户解绑）
		$_oauth_providers = OAuthService::getProviders();
		$_user_binds = $oauth->getUserBinds($uid);
		$_user_bind_providers = array();
		foreach ($_user_binds as $_bind) {
			$_user_bind_providers[$_bind['provider']] = $_bind;
		}
		$bind_status = array();
		foreach ($_oauth_providers as $_name => $_config) {
			$_is_bind = isset($_user_bind_providers[$_name]);
			$_available = !empty($_config['enable']) && !empty($_config['appid']) && !empty($_config['appkey']);
			// 未启用且未绑定的 provider 直接跳过不展示
			if (!$_is_bind && !$_available) {
				continue;
			}
			$bind_status[$_name] = array(
				'config' => $_config,
				'binded' => $_is_bind,
				'bind_info' => $_is_bind ? $_user_bind_providers[$_name] : null,
				'available' => $_available,
			);
		}

		$header['title'] = lang('oauth_bind_manage');
		$header['mobile_title'] = lang('oauth_bind_manage');

		// 标记当前 tab，用于侧栏高亮
		$active_tab = 'oauth';

		include _include(APP_PATH.'plugin/xnx_oauth/view/htm/my_oauth.htm');
		break;

	case 'unbind':
		global $uid;
		if (!$uid) {
			message(-1, '请先登录', array('redirect_url' => url('user-login')));
		}
		if ($method != 'POST') {
			message(-1, '请求方法错误');
		}
		CsrfService::check();

		$providerConfig = OAuthService::getProvider($provider);
		if (!$providerConfig) {
			http_response_code(404);
			xn_log('Unknown oauth provider: ' . $provider, 'oauth_error');
			message(-1, '未知的 OAuth 平台: ' . esc_html($provider));
		}

		try {
			$result = $oauth->unbindAccount($uid, $provider);
			if (!empty($result['ok'])) {
				message(0, '解绑成功', array('redirect_url' => url('oauth-bind-manage')));
			} else {
				message(-1, $result['message'] ?: '解绑失败，请先绑定其他登录方式');
			}
		} catch (Exception $e) {
			xn_log('OAuth unbind exception: ' . $e->getMessage(), 'oauth_error');
			message(-1, '解绑异常：' . $e->getMessage());
		}
		break;

	default:
		// 未知 action
		http_response_code(404);
		xn_log('Unknown oauth action: ' . $action, 'oauth_error');
		message(-1, '页面不存在');
		break;
}
