<?php
!defined('DEBUG') AND exit('Access Denied');
global $conf;

setting_set('xnx_webp', array(
    'enabled' => 1,
    'quality' => 80,
    'max_width' => 1920,
    'max_height' => 1920,
    'convert_gif' => 0,
    'min_size_kb' => 100,
));
