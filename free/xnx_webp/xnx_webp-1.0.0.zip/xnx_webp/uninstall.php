<?php
!defined('DEBUG') AND exit('Access Denied');
setting_delete('xnx_webp');
