<?php
!defined('DEBUG') AND exit('Access Denied');
$gid != 1 && $gid != 2 AND message(-1, lang('admin_no_privilege'));

if (!class_exists('WebpService', false)) {
    include_once APP_PATH . 'plugin/xnx_webp/model/WebpService.php';
}

if ($method == 'POST' && !empty($_POST)) {
    CsrfService::check();
    $settings = array(
        'enabled' => intval(param('enabled', 0)),
        'quality' => max(1, min(100, intval(param('quality', 80)))),
        'max_width' => max(0, intval(param('max_width', 1920))),
        'max_height' => max(0, intval(param('max_height', 1920))),
        'convert_gif' => intval(param('convert_gif', 0)),
        'min_size_kb' => max(0, intval(param('min_size_kb', 100))),
    );
    WebpService::saveSettings($settings);
    message(0, lang('save_successfully'));
}

$settings = WebpService::getSettings();
$engine = WebpService::getEngine();
include _include(APP_PATH . 'plugin/xnx_webp/view/htm/setting.htm');
