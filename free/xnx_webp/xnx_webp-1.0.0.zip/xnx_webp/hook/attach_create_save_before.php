<?php exit;
// ponytail: hook 内联到 route/attach.php 顶层作用域，禁止 return；仅处理 FormData 模式
if (!empty($is_formdata) && !empty($filetype) && $filetype == 'image' && !empty($tmp_name) && is_file($tmp_name)) {
    if (!class_exists('WebpService', false)) {
        include_once APP_PATH . 'plugin/xnx_webp/model/WebpService.php';
    }
    if (class_exists('WebpService', false)) {
        $result = WebpService::convert($tmp_name, $name, $size);
        if (!empty($result) && !empty($result['path']) && is_file($result['path'])) {
            // 把转换后的 webp 内容写回 $_FILES['file']['tmp_name']
            // move_uploaded_file 会把这个文件移到 $tmpfile
            $webpContent = file_get_contents($result['path']);
            if ($webpContent !== false && file_put_contents($tmp_name, $webpContent) !== false) {
                // 修改局部变量（hook 内联，直接赋值即可影响后续代码）
                $name = preg_replace('/\.(jpe?g|png|gif|bmp)$/i', '.webp', $name);
                $ext = 'webp';
                $size = $result['filesize'];
                $tmpname = bin2hex(random_bytes(16)) . '.webp';
                $tmpfile = $conf['upload_path'] . 'tmp/' . $tmpname;
                $tmpurl = $conf['upload_url'] . 'tmp/' . $tmpname;
            }
            // 清理 WebpService 生成的临时文件
            @unlink($result['path']);
        }
    }
}
