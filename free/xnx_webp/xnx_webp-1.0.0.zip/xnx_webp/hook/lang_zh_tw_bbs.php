<?php
$lang['xnx_webp_name'] = 'WebP 壓縮';
$lang['xnx_webp_brief'] = '上傳圖片時自動轉換為 WebP 格式，顯著減小圖片體積';
$lang['xnx_webp_enabled'] = '啟用 WebP 轉換';
$lang['xnx_webp_quality'] = '壓縮質量';
$lang['xnx_webp_max_width'] = '最大寬度';
$lang['xnx_webp_max_height'] = '最大高度';
$lang['xnx_webp_convert_gif'] = '轉換 GIF 動圖';
$lang['xnx_webp_min_size'] = '最小檔案大小';
$lang['xnx_webp_engine'] = '伺服器支援';
$lang['xnx_webp_engine_imagick'] = 'Imagick（推薦）';
$lang['xnx_webp_engine_gd'] = 'GD 擴充套件';
$lang['xnx_webp_engine_none'] = '不支援';
$lang['xnx_webp_engine_none_warning'] = '伺服器未安裝 Imagick 或 GD 擴充套件，無法轉換 WebP，請先在伺服器安裝相關擴充套件';
$lang['xnx_webp_save'] = '儲存設定';
