<?php
$lang['xnx_webp_name'] = 'WebP Compression';
$lang['xnx_webp_brief'] = 'Automatically convert uploaded images to WebP format to significantly reduce file size';
$lang['xnx_webp_enabled'] = 'Enable WebP Conversion';
$lang['xnx_webp_quality'] = 'Compression Quality';
$lang['xnx_webp_max_width'] = 'Max Width';
$lang['xnx_webp_max_height'] = 'Max Height';
$lang['xnx_webp_convert_gif'] = 'Convert GIF Animations';
$lang['xnx_webp_min_size'] = 'Minimum File Size';
$lang['xnx_webp_engine'] = 'Server Support';
$lang['xnx_webp_engine_imagick'] = 'Imagick (Recommended)';
$lang['xnx_webp_engine_gd'] = 'GD Extension';
$lang['xnx_webp_engine_none'] = 'Not Supported';
$lang['xnx_webp_engine_none_warning'] = 'Neither Imagick nor GD extension is installed on the server. WebP conversion is not available. Please install the required extensions first.';
$lang['xnx_webp_save'] = 'Save Settings';
