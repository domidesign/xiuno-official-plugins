<?php
$lang['xnx_webp_name'] = 'WebP 压缩';
$lang['xnx_webp_brief'] = '上传图片时自动转换为 WebP 格式，显著减小图片体积';
$lang['xnx_webp_enabled'] = '启用 WebP 转换';
$lang['xnx_webp_quality'] = '压缩质量';
$lang['xnx_webp_max_width'] = '最大宽度';
$lang['xnx_webp_max_height'] = '最大高度';
$lang['xnx_webp_convert_gif'] = '转换 GIF 动图';
$lang['xnx_webp_min_size'] = '最小文件大小';
$lang['xnx_webp_engine'] = '服务器支持';
$lang['xnx_webp_engine_imagick'] = 'Imagick（推荐）';
$lang['xnx_webp_engine_gd'] = 'GD 扩展';
$lang['xnx_webp_engine_none'] = '不支持';
$lang['xnx_webp_engine_none_warning'] = '服务器未安装 Imagick 或 GD 扩展，无法转换 WebP，请先在服务器安装相关扩展';
$lang['xnx_webp_save'] = '保存设置';
