<?php
!defined('DEBUG') AND exit('Access Denied');

class WebpService {
    private static $defaults = array(
        'enabled' => 1,
        'quality' => 80,
        'max_width' => 1920,
        'max_height' => 1920,
        'convert_gif' => 0,
        'min_size_kb' => 100,
    );

    public static function getSettings() {
        $s = setting_get('xnx_webp');
        if (!is_array($s)) $s = array();
        return array_merge(self::$defaults, $s);
    }

    public static function saveSettings($arr) {
        setting_set('xnx_webp', $arr);
    }

    public static function isSupported() {
        return class_exists('Imagick', false) || function_exists('imagewebp');
    }

    public static function getEngine() {
        if (class_exists('Imagick', false)) return 'imagick';
        if (function_exists('imagewebp')) return 'gd';
        return null;
    }

    public static function convert($tmp_name, $origName, $filesize) {
        $settings = self::getSettings();
        if (empty($settings['enabled'])) return false;
        if (!self::isSupported()) return false;

        // 检测图片类型
        $imginfo = @getimagesize($tmp_name);
        if (!$imginfo) return false;
        $mime = $imginfo['mime'];
        $srcW = $imginfo[0];
        $srcH = $imginfo[1];

        // GIF 默认跳过
        if ($mime === 'image/gif' && empty($settings['convert_gif'])) return false;
        // 已是 webp 跳过
        if ($mime === 'image/webp') return false;

        // 小文件跳过
        $minSize = intval($settings['min_size_kb']) * 1024;
        if ($filesize < $minSize) return false;

        $quality = max(1, min(100, intval($settings['quality'])));
        $maxW = intval($settings['max_width']);
        $maxH = intval($settings['max_height']);

        // 计算缩放后尺寸
        $dstW = $srcW;
        $dstH = $srcH;
        if ($maxW > 0 && $maxH > 0 && ($srcW > $maxW || $srcH > $maxH)) {
            $ratio = min($maxW / $srcW, $maxH / $srcH);
            $dstW = intval($srcW * $ratio);
            $dstH = intval($srcH * $ratio);
        }

        $engine = self::getEngine();
        $tempPath = tempnam(sys_get_temp_dir(), 'webp_');

        try {
            if ($engine === 'imagick') {
                $imagick = new Imagick($tmp_name);
                if ($dstW !== $srcW || $dstH !== $srcH) {
                    $imagick->thumbnailImage($dstW, $dstH, true);
                }
                $imagick->setImageFormat('webp');
                $imagick->setImageCompressionQuality($quality);
                // PNG/BMP 保留透明
                if ($mime === 'image/png' || $mime === 'image/bmp') {
                    $imagick->setImageAlphaChannel(Imagick::ALPHACHANNEL_ACTIVATE);
                }
                $imagick->writeImage($tempPath);
                $imagick->clear();
                $imagick->destroy();
            } else {
                // GD
                switch ($mime) {
                    case 'image/jpeg': $srcImg = imagecreatefromjpeg($tmp_name); break;
                    case 'image/png':  $srcImg = imagecreatefrompng($tmp_name);  break;
                    case 'image/gif':  $srcImg = imagecreatefromgif($tmp_name);  break;
                    case 'image/webp': $srcImg = @imagecreatefromwebp($tmp_name); break;
                    case 'image/bmp':  $srcImg = function_exists('imagecreatefrombmp') ? imagecreatefrombmp($tmp_name) : false; break;
                    default: $srcImg = false;
                }
                if (!$srcImg) {
                    @unlink($tempPath);
                    return false;
                }
                $dstImg = imagecreatetruecolor($dstW, $dstH);
                // PNG/GIF/BMP 保留透明通道
                if ($mime === 'image/png' || $mime === 'image/gif' || $mime === 'image/bmp') {
                    imagealphablending($dstImg, false);
                    imagesavealpha($dstImg, true);
                    $transparent = imagecolorallocatealpha($dstImg, 0, 0, 0, 127);
                    imagefilledrectangle($dstImg, 0, 0, $dstW, $dstH, $transparent);
                }
                imagecopyresampled($dstImg, $srcImg, 0, 0, 0, 0, $dstW, $dstH, $srcW, $srcH);
                $result = imagewebp($dstImg, $tempPath, $quality);
                if (PHP_VERSION_ID < 80000) {
                    imagedestroy($srcImg);
                    imagedestroy($dstImg);
                }
                if (!$result) {
                    @unlink($tempPath);
                    return false;
                }
            }

            $newSize = filesize($tempPath);
            if (!$newSize) {
                @unlink($tempPath);
                return false;
            }
            return array(
                'path' => $tempPath,
                'filesize' => $newSize,
                'width' => $dstW,
                'height' => $dstH,
            );
        } catch (Exception $e) {
            xn_log('WebpService convert failed: ' . $e->getMessage() . ' file=' . $origName, 'php_error');
            @unlink($tempPath);
            return false;
        }
    }
}
