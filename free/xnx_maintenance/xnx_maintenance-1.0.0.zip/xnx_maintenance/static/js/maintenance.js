/*!
 * maintenance.js - 站点维护页面倒计时脚本
 * 原生 JS 实现，无 jQuery 依赖
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        var countdownEl = document.getElementById('maintenance-countdown');
        if (!countdownEl) return;

        var recoverAt = parseInt(countdownEl.getAttribute('data-recover-at'), 10) || 0;
        // 未设置恢复时间时，HTML 已显示「恢复时间待定」，无需 JS 处理
        if (recoverAt <= 0) return;

        var daysEl = document.getElementById('countdown-days');
        var hoursEl = document.getElementById('countdown-hours');
        var minutesEl = document.getElementById('countdown-minutes');
        var secondsEl = document.getElementById('countdown-seconds');

        function pad(n) {
            return String(n).padStart(2, '0');
        }

        function update() {
            var now = Math.floor(Date.now() / 1000);
            var remaining = recoverAt - now;

            if (remaining <= 0) {
                // 倒计时已过期，显示「恢复时间已到」文案
                var pendingText = countdownEl.getAttribute('data-pending-text') || '恢复时间已到，正在紧急修复中…';
                countdownEl.replaceChildren();
                var pendingDiv = document.createElement('div');
                pendingDiv.className = 'maintenance-recover-pending';
                pendingDiv.textContent = pendingText;
                countdownEl.appendChild(pendingDiv);
                clearInterval(timer);
                return;
            }

            var days = Math.floor(remaining / 86400);
            var hours = Math.floor((remaining % 86400) / 3600);
            var minutes = Math.floor((remaining % 3600) / 60);
            var seconds = remaining % 60;

            if (daysEl) daysEl.textContent = pad(days);
            if (hoursEl) hoursEl.textContent = pad(hours);
            if (minutesEl) minutesEl.textContent = pad(minutes);
            if (secondsEl) secondsEl.textContent = pad(seconds);
        }

        update();
        var timer = setInterval(update, 1000);
    });
})();
