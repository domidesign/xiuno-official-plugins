# xnx_maintenance 开发日志

## 2026-06-29
- 创建插件骨架（conf.json/install/uninstall）[新功能]
- 实现 MaintenanceService 业务类（getSettings/saveSettings/isEnabled/isWhitelisted/shouldBlock/shouldBlockApi/renderPage）[新功能]
- 实现 hook model_check_runlevel_start 拦截 runlevel=0 和插件开关触发的维护模式[新功能]
- 实现 hook index_inc_route_before 拦截 API 请求（可配置开关）[新功能]
- 实现后台 setting.php 含 CSRF/权限检查/IP/邮箱/主题色验证[新功能]
- 实现语言包 hook lang_zh_cn_bbs 补齐默认标题/描述/提示文案[语言包不同步]

- 修复管理员前端空白：renderPage 加 ob_start 输出缓冲保护 + is_file 模板检查 + 降级纯文本输出 [边界未校验]
- 修复 isWhitelisted 未放行 gid=2 副管理员 [权限遗漏]
- 修复 setting.php gid_whitelist 参数非数组时类型错误 [类型误用]
- 添加 xn_log 调试日志排查设置保存失败问题 [调试]
- 优化后台设置页 UI：左右两栏 tab 布局 + form-switch 开关 + placeholder 默认值提示 [UI优化]
- 内置维护标题/描述/原因预设值（站点维护中/我们正在升级站点/系统维护升级）[默认值缺失]
- API 拦截 hook 也放行 gid=2 副管理员 [权限遗漏]

- **修复前台空白致命 bug**：hook index_inc_route_before 编译后在 index.inc.php 顶层作用域，`return` 会终止整个页面渲染，改为 if/elseif 结构避免 return [作用域误用]
- 修复 defaults() 方法 private 导致 setting.htm 编译后调用报错 [访问权限]

## 本次学到的教训
- hook model_check_runlevel_start 在 $gid==1 检查之前执行，可直接用 $gid 判断白名单
- API 路由在 index_inc_route_before 之后提前分发，必须用此 hook 拦截 API
- renderPage 直接 include 模板时需加 ob_start 保护，否则 headers already sent 会导致白屏
- checkbox 未勾选时 param() 可能返回空字符串而非空数组，需 is_array 检查
- **hook 编译后如果处于文件顶层作用域（如 index.inc.php），禁止使用 return 语句——return 会终止整个文件执行导致白屏！必须用 if/else 结构代替**
- defaults() 等被 htm 模板调用的 Service 方法必须为 public，否则编译后全局作用域调用会 fatal error
