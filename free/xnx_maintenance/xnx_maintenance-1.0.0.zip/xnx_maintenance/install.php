<?php
!defined('DEBUG') AND exit('Access Denied');

// 写入默认设置
$defaults = array(
    'enabled'        => 0,
    'title'          => '站点维护中',
    'description'    => '我们正在升级站点，请稍后访问',
    'reason'         => '系统维护升级',
    'recover_at'     => 0,
    'ip_whitelist'   => '',
    'gid_whitelist'  => array(1),
    'contact_email'  => '',
    'theme_mode'     => 'dark',
    'theme_color'    => '#0d6efd',
    'custom_css'     => '',
    'block_api'      => 0,
);

setting_set('xnx_maintenance', $defaults);
