<?php exit;
// xnx_maintenance: 维护模式拦截
// ponytail: 禁止使用 return; — hook 内联编译到 check_runlevel() 函数中，
// return 会终止整个 check_runlevel() 导致原函数的 runlevel 检查（switch case 0-4）被跳过，
// 进而导致插件启用后即使维护模式关闭，runlevel=1/2/3/4 的拦截也全部失效
// 详见 2026-07-18 同类问题全量扫描
if (class_exists('MaintenanceService')) {
    $mt_ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $mt_gid = intval($gid);

    // gid=1,2 管理员永远放行（让原函数的 if($gid == 1) return 处理）
    $mt_is_admin = ($mt_gid === 1 || $mt_gid === 2);

    if (!$mt_is_admin) {
        $mt_s = MaintenanceService::getSettings();
        $mt_enabled = !empty($mt_s['enabled']);
        $mt_runlevel = isset($conf['runlevel']) ? intval($conf['runlevel']) : 5;
        $mt_is_enabled = $mt_enabled || ($mt_runlevel === 0);
        $mt_is_whitelisted = MaintenanceService::isWhitelisted($mt_ip, $mt_gid);
        $mt_should_block = $mt_is_enabled && !$mt_is_whitelisted;

        // ponytail: 只在需要拦截时才打日志，避免每个请求都写一条 debug_error 日志
        if ($mt_should_block && !defined('SKIP_ROUTE')) {
            // 排除登录/退出/注册/找回密码
            $mt_p0 = param(0);
            $mt_p1 = param(1);
            $mt_allowed_routes = array(
                'login', 'logout', 'create', 'sendinitpw', 'resetpw', 'resetpw_sendcode', 'resetpw_complete', 'synlogin'
            );
            $mt_is_allowed = ($mt_p0 == 'user' && in_array($mt_p1, $mt_allowed_routes));

            if (!$mt_is_allowed) {
                xn_log("xnx_maintenance: rendering maintenance page (gid=$mt_gid, ip=$mt_ip)", 'debug_error');

                // 输出维护页
                try {
                    MaintenanceService::renderPage();
                } catch (\Throwable $e) {
                    xn_log('xnx_maintenance renderPage error: ' . $e->getMessage(), 'error');
                    // 降级输出
                    http_response_code(503);
                    echo '<html><body><h1>站点维护中</h1><p>我们正在升级站点，请稍后访问</p></body></html>';
                }
                // exit 是终止性操作的正当用途：维护页输出后必须终止请求
                // 否则原 check_runlevel() 函数会继续执行 runlevel 检查并 message() 重复输出
                exit;
            }
        }
    }
}
