<?php exit;
APP_PATH.'plugin/xnx_maintenance/model/MaintenanceService.php',
