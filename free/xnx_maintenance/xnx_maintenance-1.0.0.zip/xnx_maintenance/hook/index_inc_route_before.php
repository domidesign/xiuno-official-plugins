<?php exit;
// xnx_maintenance: API 拦截
// 注意：此 hook 在 index.inc.php 顶层作用域，禁止使用 return（会终止整个页面渲染）
// ponytail: exit 是终止性操作的正当用途：API 503 响应输出后必须终止请求，
// 否则后续 index.inc.php 会继续渲染 HTML 页面破坏 JSON 响应。已用 if 块包裹整个逻辑，
// 不触发拦截时 hook 无任何副作用，原宿主流程不受影响
if (!class_exists('MaintenanceService')) {
    // 类不存在，跳过
} elseif (MaintenanceService::shouldBlockApi()) {
    // 判断是否为 API 请求
    $mt_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $mt_is_api = (strpos($mt_uri, '/api/v1/') === 0) || (function_exists('param') && param(0) === 'api');
    if ($mt_is_api) {
        // 排除管理员 Bearer token（简化：检查 session uid）
        $mt_session_uid = isset($_SESSION['uid']) ? intval($_SESSION['uid']) : 0;
        $mt_is_admin = false;
        if ($mt_session_uid > 0) {
            $mt_user = user_read($mt_session_uid);
            if (!empty($mt_user) && (intval($mt_user['gid']) === 1 || intval($mt_user['gid']) === 2)) {
                $mt_is_admin = true;
            }
        }
        if (!$mt_is_admin) {
            // 返回 503 JSON
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            header('Retry-After: 3600');
            echo json_encode(array('code' => -1, 'message' => lang('xnx_maintenance_default_title')), JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
}
