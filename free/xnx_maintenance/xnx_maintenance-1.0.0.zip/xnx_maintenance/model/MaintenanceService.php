<?php
!defined('DEBUG') AND exit('Access Denied');

class MaintenanceService {

    private static $settings = null;

    // 默认设置
    public static function defaults() {
        return array(
            'enabled'        => 0,
            'title'          => '站点维护中',
            'description'    => '我们正在升级站点，请稍后访问',
            'reason'         => '系统维护升级',
            'recover_at'     => 0,
            'ip_whitelist'   => '',
            'gid_whitelist'  => array(1),
            'contact_email'  => '',
            'theme_mode'     => 'dark',
            'theme_color'    => '#0d6efd',
            'custom_css'     => '',
            'block_api'      => 0,
        );
    }

    // 获取设置（带默认值合并，gid_whitelist 始终包含 1）
    public static function getSettings() {
        if (self::$settings !== null) {
            return self::$settings;
        }
        $saved = setting_get('xnx_maintenance');
        if (!is_array($saved)) {
            $saved = array();
        }
        $merged = array_merge(self::defaults(), $saved);

        // 确保 gid_whitelist 是数组且包含 1
        if (!is_array($merged['gid_whitelist'])) {
            $merged['gid_whitelist'] = array();
        }
        $merged['gid_whitelist'] = array_map('intval', $merged['gid_whitelist']);
        if (!in_array(1, $merged['gid_whitelist'], true)) {
            array_unshift($merged['gid_whitelist'], 1);
        }

        // 确保 ip_whitelist 是字符串
        if (!is_string($merged['ip_whitelist'])) {
            $merged['ip_whitelist'] = '';
        }

        // 确保 recover_at 是整数
        $merged['recover_at'] = intval($merged['recover_at']);

        self::$settings = $merged;
        return self::$settings;
    }

    // 保存设置
    public static function saveSettings($arr) {
        if (!is_array($arr)) {
            $arr = array();
        }
        // 合并默认值，避免字段缺失
        $merged = array_merge(self::defaults(), $arr);
        // 确保 gid_whitelist 始终包含 1
        if (!is_array($merged['gid_whitelist'])) {
            $merged['gid_whitelist'] = array(1);
        }
        $merged['gid_whitelist'] = array_map('intval', $merged['gid_whitelist']);
        if (!in_array(1, $merged['gid_whitelist'], true)) {
            array_unshift($merged['gid_whitelist'], 1);
        }
        $result = setting_set('xnx_maintenance', $merged);
        // 刷新静态缓存
        self::$settings = $merged;
    }

    // 判断维护模式是否生效：插件 enabled=1 OR 系统 runlevel=0
    public static function isEnabled() {
        $s = self::getSettings();
        global $conf;
        return !empty($s['enabled']) || (isset($conf['runlevel']) && $conf['runlevel'] == 0);
    }

    // 判断是否在白名单：gid=1,2 管理员永远放行；gid 在 gid_whitelist 放行；IP 精确匹配放行
    public static function isWhitelisted($ip, $gid) {
        $gid = intval($gid);
        // gid=1 管理员永远放行
        if ($gid === 1) {
            return true;
        }
        // gid=2 副管理员也放行
        if ($gid === 2) {
            return true;
        }
        $s = self::getSettings();
        // gid 在 gid_whitelist 放行
        if (is_array($s['gid_whitelist']) && in_array($gid, $s['gid_whitelist'], true)) {
            return true;
        }
        // IP 精确匹配放行
        if (!empty($ip) && is_string($s['ip_whitelist'])) {
            $ip_list = preg_split('/\r\n|\r|\n/', $s['ip_whitelist']);
            foreach ($ip_list as $line) {
                $line = trim($line);
                if ($line !== '' && $line === $ip) {
                    return true;
                }
            }
        }
        return false;
    }

    // 判断是否应该拦截前台：isEnabled && !isWhitelisted
    public static function shouldBlock() {
        global $gid;
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        return self::isEnabled() && !self::isWhitelisted($ip, $gid);
    }

    // 判断是否应该拦截 API：shouldBlock && block_api=1
    public static function shouldBlockApi() {
        $s = self::getSettings();
        return self::shouldBlock() && !empty($s['block_api']);
    }

    // 渲染维护页面并 exit
    public static function renderPage() {
        global $conf;

        xn_log('xnx_maintenance renderPage: start', 'debug_error');

        // 输出缓冲保护，防止 headers already sent
        ob_start();

        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        header('Retry-After: 3600');

        $settings = self::getSettings();

        // 准备模板变量
        $mt_settings       = $settings;
        $mt_sitename       = !empty($settings['site_name']) ? $settings['site_name'] : (isset($conf['sitename']) ? $conf['sitename'] : '');
        $mt_logo           = isset($conf['logo']) ? $conf['logo'] : '';
        $mt_title          = !empty($settings['title']) ? $settings['title'] : lang('xnx_maintenance_default_title');
        $mt_description    = !empty($settings['description']) ? $settings['description'] : lang('xnx_maintenance_default_desc');
        $mt_reason         = $settings['reason'];
        $mt_recover_at     = intval($settings['recover_at']);
        $mt_contact_email  = $settings['contact_email'];
        $mt_theme_mode     = $settings['theme_mode'];
        $mt_theme_color    = $settings['theme_color'];
        $mt_custom_css     = $settings['custom_css'];
        $mt_css_url        = (isset($conf['view_url']) ? $conf['view_url'] : '') . '../plugin/xnx_maintenance/static/css/maintenance.css';
        $mt_js_url         = (isset($conf['view_url']) ? $conf['view_url'] : '') . '../plugin/xnx_maintenance/static/js/maintenance.js';

        // 尝试 include 模板
        $template_path = APP_PATH . 'plugin/xnx_maintenance/view/htm/maintenance.htm';
        xn_log('xnx_maintenance renderPage: template_path=' . $template_path . ', exists=' . intval(is_file($template_path)), 'debug_error');
        if (is_file($template_path)) {
            include $template_path;
            xn_log('xnx_maintenance renderPage: template included OK', 'debug_error');
        } else {
            // 模板文件不存在时的降级输出
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . esc_html($mt_title) . '</title></head><body style="display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;font-family:sans-serif;background:#1a1a2e;color:#e9ecef"><div style="text-align:center"><h1>' . esc_html($mt_title) . '</h1><p>' . esc_html($mt_description) . '</p></div></body></html>';
        }

        ob_end_flush();
        exit;
    }
}
