<?php
!defined('DEBUG') AND exit('Access Denied');
$gid != 1 && $gid != 2 AND message(-1, lang('xnx_maintenance_no_permission'));

if ($method == 'POST') {
    CsrfService::check();

    // 收集并验证表单数据
    $enabled = intval(param('enabled', 0));
    $title = trim(param('title', ''));
    $description = trim(param('description', ''));
    $reason = trim(param('reason', ''));

    // recover_at: datetime-local 格式 'Y-m-d\TH:i'，用 strtotime 解析
    $recover_at_str = trim(param('recover_at', ''));
    $recover_at = 0;
    if (!empty($recover_at_str)) {
        $ts = strtotime($recover_at_str);
        $recover_at = $ts > 0 ? $ts : 0;
    }

    // IP 白名单：每行一个，trim，filter_var 验证
    $ip_text = trim(param('ip_whitelist', ''));
    $ip_lines = empty($ip_text) ? array() : explode("\n", $ip_text);
    $valid_ips = array();
    foreach ($ip_lines as $ip_line) {
        $ip = trim($ip_line);
        if (!empty($ip) && filter_var($ip, FILTER_VALIDATE_IP)) {
            $valid_ips[] = $ip;
        }
    }
    $ip_whitelist = implode("\n", $valid_ips);

    // gid_whitelist: 多选 checkbox，name="gid_whitelist[]"，gid=1,2 强制包含
    $gid_input = param('gid_whitelist', array());
    if (!is_array($gid_input)) {
        $gid_input = empty($gid_input) ? array() : array(intval($gid_input));
    }
    $gid_whitelist = array(1, 2); // gid=1,2 始终包含
    foreach ($gid_input as $g) {
        $g = intval($g);
        if ($g > 0 && !in_array($g, $gid_whitelist)) {
            $gid_whitelist[] = $g;
        }
    }

    // 邮箱
    $contact_email = trim(param('contact_email', ''));
    if (!empty($contact_email) && !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
        $contact_email = '';
    }

    // 主题模式
    $theme_mode = param('theme_mode', 'dark');
    if (!in_array($theme_mode, array('dark', 'light'))) {
        $theme_mode = 'dark';
    }

    // 主题色：正则验证
    $theme_color = trim(param('theme_color', '#0d6efd'));
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $theme_color)) {
        $theme_color = '#0d6efd';
    }

    // 自定义 CSS（关闭 htmlspecialchars，CSS 中的 > < & 不应被转义）
    $custom_css = trim(param('custom_css', '', FALSE));

    // API 拦截
    $block_api = intval(param('block_api', 0));

    $settings = array(
        'enabled'        => $enabled,
        'title'          => $title,
        'description'    => $description,
        'reason'         => $reason,
        'recover_at'     => $recover_at,
        'ip_whitelist'   => $ip_whitelist,
        'gid_whitelist'  => $gid_whitelist,
        'contact_email'  => $contact_email,
        'theme_mode'     => $theme_mode,
        'theme_color'    => $theme_color,
        'custom_css'     => $custom_css,
        'block_api'      => $block_api,
    );

    MaintenanceService::saveSettings($settings);
    xn_log('xnx_maintenance setting POST: enabled=' . $enabled . ', gid_whitelist=' . implode(',', $gid_whitelist), 'debug_error');
    message(0, lang('xnx_maintenance_save_ok'), array('redirect_url' => admin_plugin_setting_url('xnx_maintenance')));
}

// GET 展示设置页
$settings = MaintenanceService::getSettings();
$grouplist = group_list_cache();

// recover_at 格式化为 datetime-local 格式
$recover_at_display = '';
if (!empty($settings['recover_at'])) {
    $recover_at_display = date('Y-m-d\TH:i', intval($settings['recover_at']));
}

include _include(APP_PATH . 'plugin/xnx_maintenance/setting.htm');
